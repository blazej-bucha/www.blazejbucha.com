/* Function prototypes */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <libgen.h>
/* ------------------------------------------------------------------------- */






void mkdir_recursive(char *path, mode_t mode)
/*
 * DESCRIPTION: Creates recursively "path" with folder permissions specified by 
 * "mode".
 *
 * */
{
    /* Get a copy of "path" */
    char *path_copy = strdup(path);


    /* Get a subdirectory name in "path_copy" */
    char *subpath = dirname(path_copy);


    /* Applied this function recursively until we get to the deepest directory 
     * in "path" */
    if (strlen(subpath) > 1)
        mkdir_recursive(subpath, mode);


    /* Check if current path that is held in "path" exists.  If yes, continue 
     * deeper inside the original "path".  If not, create it. */
    struct stat sb;
    if (!(stat(path, &sb) == 0 && S_ISDIR(sb.st_mode)))
    {
        /* "path" does not exist, so create it */
        int err = mkdir(path, mode);


        if (err != 0)
        {
            printf("[mkdir_recursive.c says:] Failed when "
                   "creating the \"%s\" directory.  Terminating the code "
                   "execution.\n", path);
            exit(EXIT_FAILURE);
        }
    }


    free(path_copy);
}
