/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
void *arr_calloc(size_t, size_t);

void sh_coeffs_init_dp(double ***, double ***, unsigned int);
void sh_coeffs_free_dp(double **, double **);
/* ------------------------------------------------------------------------- */






void sh_surf_analysis_point_dp(double *lat, size_t nlat, size_t nlon,
                               double *w, double *f, unsigned int nmax_signal,
                               unsigned int nmax_sha, double **cnm,
                               double **snm)
/*
 * ==========================================================================
 *
 * DESCRIPTION: This function computes spherical harmonic coefficients of a
 *              signal "f" via the exact FFT-based Gauss--Legendre quadrature
 *              (Sneeuw, 1994) up to degree "nmax_sha". The signal must be
 *              sampled at the nodes of the Gauss--Legendre quadrature (see the
 *              "gl_grd_dp.c" function) and possess harmonics up to degree
 *              "nmax_signal >= nmax_sha" (see below).
 *
 *              The function is written in double precision.
 *
 *              Importantly, the function allows to compute spherical
 *              harmonic coefficients even for a smaller maximum degree than 
 *              that of the input signal, that is, for "nmax_sha <= 
 *              nmax_signal". In that case, however, the input signal must be 
 *              sampled correspondingly to its maximum harmonic degree 
 *              "nmax_signal", that is, at the grid obtained using the 
 *              "nmax_signal" value as the input to the "gl_grd_dp.c" 
 *              function. If this condition is met, the resulting coefficients 
 *              up to degree "nmax_sha" are computed exactly without any 
 *              approximation errors (neglecting numerical
 *              errors, etc.).
 *
 *              The loop over latitudes is parallelized using OpenMP.
 *
 *              The 4*pi fully-normalized associated Legendre functions
 *              (e.g., Heiskannen and Moritz, 1967) are evaluated by the
 *              numerically stable algorithm by Fukushima (2012). The algorithm
 *              can be used up to ultra-high harmonic degrees (say, tens of
 *              thousands or even well beyond).
 *
 *              As the main input, the signal to be analysed is represented
 *              by an array as one of the input variables (see the variable "f"
 *              below). Importantly, the whole array is stored in RAM during 
 *              the entire harmonic analysis. The same holds for the output 
 *              spherical harmonic coefficients. Ultra-high-degree analysis may 
 *              therefore require tens of GBs of RAM.
 *
 *              The function exploits the symmetry property of Legendre
 *              functions with respect to the equator, thereby improving its
 *              performance, especially for ultra-high-degree harmonic
 *              analysis. For further details on the symmetric grid, see
 *              "sh_surf_synthesis_point_dp.c". However, unlike 
 *              "sh_surf_synthesis_point_dp.c", this function always takes 
 *              advantage of the symmetry, as the Gauss--Legendre grid is 
 *              always symmetric and no other grid is currently supported in 
 *              this function.
 *
 *
 * INPUTS: "lat"         -- Pointer to an array of latitudes of the 
 *                          Gauss--Legendre grid in radians.
 *
 *                          A vector of the dimension (nmax_signal + 1), where
 *                          "nmax_signal" is the maximum degree present in the
 *                          signal (see above and the "gl_grd_dp.c"
 *                          function).
 *
 *         "nlat"        -- Number of latitudes in a single meridian
 *                          ("nlat = nmax_signal + 1").
 *
 *         "nlon"        -- Number of longitudes in a single latitude parallel
 *                          ("nlon = 2 * nmax_signal + 2").
 *
 *         "w"           -- Pointer to an array of weights due to the 
 *                          Gauss--Legendre quadrature.
 *
 *                          A vector of the dimension (nmax_signal + 1). See
 *                          above and the "gl_grd_dp.c" function.
 *
 *         "f"           -- Pointer to an array of the input signal i) given at 
 *                          the nodes of the Gauss--Legendre quadrature for 
 *                          "nmax_signal" and ii) containing harmonics up to 
 *                          degree "nmax_signal".
 *
 *                          Using the traditional row-major order of matrix 
 *                          elements in C, the array to which "f" points can be 
 *                          depicted as a matrix of the dimensions (nmax_signal 
 *                          + 1, 2 * nmax_signal + 2), sampled as follows:
 *
 *                 [(lat[0],lon[0])          ...         (lat[0],lon[nlon - 1]]
 *                 [      .                  .                  .             ]
 *                 [      .                   .                 .             ]
 *                 [      .                    .                .             ]
 *                 [(lat[nlat - 1],lon[0])   ...  (lat[nlat - 1],lon[nlon - 1]]
 *
 *                          where "lat" and "lon" are vectors generated by
 *                          the "gl_grd_dp.c" function.
 *
 *                          This means that, for instance, the value of "f" for 
 *                          "lat[i]" and "lon[j]" can be found as follows:
 *
 *                          "f[i * nlon + j]"
 *
 *                          See above and also the 
 *                          "sh_surf_synthesis_point_dp.c" function.
 *
 *         "nmax_signal" -- Maximum harmonic degree present in the signal
 *                          (here, the variable "f" above).
 *
 *         "nmax_sha"    -- Maximum harmonic degree of the output spherical
 *                          harmonic coefficients. This value cannot be larger
 *                          than "nmax_signal". Note that if
 *                          "nmax_sha < nmax_signal", the output coefficients
 *                          are still computed exactly, because the matrix
 *                          "f" is sampled correctly according to the
 *                          maximum degree that is present in the signal, here
 *                          "nmax_signal".
 *
 *
 * OUTPUTS: "cnm"       -- Double pointer to a 2D array with the output "Cnm" 
 *                         spherical harmonic coefficients. The first dimension 
 *                         is related to harmonic orders and the second one to 
 *                         harmonic degrees. Importantly, the number of columns 
 *                         varies for each row as follows:
 *
 *
 *                         Order 0: "cnm[0]" has "nmax + 1" columns for degrees 
 *                         "0, 1, ..., nmax" (respectively),
 *
 *                         Order 1: "cnm[1]" has "nmax" columns for degrees "1, 
 *                         2, ..., nmax" (respectively),
 *
 *                         Order 2: "cnm[2]" has "nmax - 1" columns for degrees 
 *                         "2, 3, ..., nmax" (respectively),
 *
 *                         .
 *                         .
 *                         .
 *
 *                         Order "nmax": "cnm[nmax]" has "1" column for degree 
 *                         "nmax".
 *
 *
 *                         This means that "cnm" is *not* a 2D rectangular 
 *                         array. It should be allocated by 
 *                         "sh_coeffs_init_dp.c" and deallocated by 
 *                         "sh_coeffs_free_dp.c".
 *
 *                         The harmonic coefficient "Cnm" of degree "n" and 
 *                         order "m" can therefore be accessed as follows:
 *
 *                         cnm[m][n - m]
 *
 *         "snm"       -- The same as "cnm" above, but with the "Snm" 
 *                        coefficients.
 *
 *
 * REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
 *                least-squares and numerical quadrature methods in historical
 *                perspective. Geophysical Journal International 118:707--716
 *
 *             Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
 *                Freeman and Company, San Francisco, 364 pp
 *
 *             Fukushima, T. (2012) Numerical computation of spherical
 *                harmonics of arbitrary degree and order by extending exponent
 *                of floating point numbers. Journal of Geodesy 86:271--285.
 *
 *
 * Contact: blazej.bucha@stuba.sk
 *
 *
 * Please use the following reference when using this function:
 *
 *          Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
 *             spectral gravity forward modelling up to the full gravity
 *             tensor. Journal of Geodesy 93:1707--1737
 *
 *
 * ========================================================================= */
{

    /* Some constants needed to compute Legendre functions */
    /* --------------------------------------------------------------------- */
    const int IND = 960;
    const double BIG = pow(2.0, IND);
    const double BIGI = pow(2.0, -IND);
    const double BIGS = pow(2.0, IND / 2.0);
    const double BIGSI = pow(2.0, -IND / 2.0);
    const double ROOT3 = 1.7320508075688772935;
    /* --------------------------------------------------------------------- */






    /* Check whether the number of latitudes is even or odd */
    /* --------------------------------------------------------------------- */
    int even;
    size_t nlatdo;
    if ((nlat % 2) == 0)
    {
        even = 1; /* The number of latitudes is an even number. The grid does
                   * not contain the zero latitude */
        nlatdo = nlat / 2;
    }
    else
    {
        even = 0; /* The number of latitudes is an odd number. The grid could
                   * possibly contain the zero latitude */
        nlatdo = (nlat + 1) / 2;
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute Legendre functions 
     * */
    /* --------------------------------------------------------------------- */
    double wlf;
    double *r = (double *)arr_calloc(2 * nmax_sha + 4, sizeof(double));
    double *ri = (double *)arr_calloc(2 * nmax_sha + 4, sizeof(double));

    r[0]  = 0.0;
    ri[0] = 0.0;
    for (unsigned int m = 1; m <= (2 * nmax_sha + 3); m++)
    {
        wlf = sqrt((double)m);
        r[m] = wlf;
        ri[m] = 1.0 / wlf;
    }


    /* Computation of the "dn" coefficients for Legendre recurrence relations 
     * */
    double *dn = (double *)arr_calloc(nmax_sha + 1, sizeof(double));

    dn[0] = 0.0;
    for (unsigned int n = 1; n <= nmax_sha; n++)
    {
        dn[n] = r[2 * n + 3] * ri[2 * n + 2];
    }


    /* Computation of the "en" and "fn" coefficients for Legendre recurrence 
     * relations */
    double *en = (double *)arr_calloc(nmax_sha + 1, sizeof(double));
    double *fn = (double *)arr_calloc(nmax_sha + 1, sizeof(double));

    en[0] = 0.0; en[1] = 0.0;
    fn[0] = 0.0; fn[1] = 0.0;
    for (unsigned int n = 2; n <= nmax_sha; n++)
    {
        en[n] = r[2 * n + 1] * r[2 * n - 1] / (double)n;
        fn[n] = (double)(n - 1) * r[2 * n + 1] / ((double)n * r[2 * n - 3]); 
    }
    /* --------------------------------------------------------------------- */






    /* Auxiliary variable entering the computation of the lumped coefficients 
     * */
    /* --------------------------------------------------------------------- */
    double c = M_PI * 2.0 / (double)(2 * (nmax_signal + 1));
    /* --------------------------------------------------------------------- */






    /* Initialize all elements of the output coefficients to zero */
    /* --------------------------------------------------------------------- */
    for (unsigned int n = 0; n <= nmax_sha; n++)
    {
        for (unsigned int m = 0; m <= n; m++)
        {
            cnm[m][n - m] = 0.0;
            snm[m][n - m] = 0.0;
        }
    }
    /* --------------------------------------------------------------------- */






    /* Create a plan for FFT */
    /* --------------------------------------------------------------------- */
    double *ftmp_in        = (double *)fftw_malloc(nlon * sizeof(double));
    fftw_complex *ftmp_out = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) 
                                                         * (nlon / 2 + 1));

    fftw_plan plan = fftw_plan_dft_r2c_1d(nlon, ftmp_in, ftmp_out,
                                          FFTW_ESTIMATE);

    fftw_free(ftmp_in); fftw_free(ftmp_out);
    /* --------------------------------------------------------------------- */






    /* Loop over latitudes */
    /* --------------------------------------------------------------------- */
    size_t imax = nlatdo + even - 1;

    #pragma omp parallel default(none) \
    shared(cnm, snm, f, lat, nlat, nlon, w, nlatdo, imax, c, nmax_sha) \
    shared(dn, en, fn, r, ri, plan) private(wlf)
    {

        /* Initialization of the private copies of "cnm" and "snm" arrays that 
         * will store the individuals contributions computed by each CPU in 
         * case of parallel computation via OpenMP.
         * 
         * If parallel computation is not employed, "cnm_priv" and "snm_priv" 
         * are rather useless and increase RAM requirements. To fix this, one 
         * can 1) remove the declarations of "cnm_priv" and "snm_priv" that 
         * follow right after this comment, 2) delete the code block related to 
         * "#pragma omp critical" (see below), 3) delete the "free" commands 
         * related to "cnm_priv" and "snm_priv", and 4) rename all the 
         * remaining occurrences of "cnm_priv" and "snm_priv" by "cnm" and 
         * "snm", respectively. This, however, is possible only in case of 
         * serial computation without OpenMP. */
        /* ................................................................. */
        double **cnm_priv, **snm_priv;
        sh_coeffs_init_dp(&cnm_priv, &snm_priv, nmax_sha);
        /* ................................................................. */


        double *ftmp_in        = (double *)fftw_malloc(nlon * sizeof(double));
        fftw_complex *ftmp_out = (fftw_complex *)fftw_malloc(
                                 sizeof(fftw_complex) * (nlon / 2 + 1));

        double pnm0, pnm1, pnm2;
        int ix, iy, iz, ixy;
        int   *ips = (int *)arr_calloc(nmax_sha + 1, sizeof(int));
        double *ps = (double *)arr_calloc(nmax_sha, sizeof(double));
        double *am = (double *)arr_calloc(nmax_sha + 1, sizeof(double));
        double *bm = (double *)arr_calloc(nmax_sha, sizeof(double));
        double t, u, x, y, z;

        double *a  = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *b  = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *a2 = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *b2 = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double alcm, a2lcm, blcm, b2lcm;

        double cw, csatmp, csbtmp;

        wlf = 0.0;



        #pragma omp for
        for (size_t i = 0; i < nlatdo; i++)
        {

            /* Lumped coefficients for the southern hemisphere (including the 
             * equator) */
            /* ------------------------------------------------------------- */
            for (size_t j = 0; j < nlon; j++)
            {
                ftmp_in[j] = f[i * nlon + j];
            }
            fftw_execute_dft_r2c(plan, ftmp_in, ftmp_out);

            cw = c * w[i];
            for (size_t j = 0; j < (nlon / 2 + 1); j++)
            {
                a[j]  =  cw * ftmp_out[j][0]; 
                b[j]  = -cw * ftmp_out[j][1]; 
            }
            /* ------------------------------------------------------------- */


            /* Lumped coefficients for the northern hemisphere */
            /* ------------------------------------------------------------- */
            if (i < imax)
            {
                for (size_t j = 0; j < nlon; j++)
                {
                    ftmp_in[j] = f[(nlat - i - 1) * nlon + j];
                }
                fftw_execute_dft_r2c(plan, ftmp_in, ftmp_out);

                cw = c * w[nlat - i - 1];
                for (size_t j = 0; j < (nlon / 2 + 1); j++)
                {
                    a2[j]  =  cw * ftmp_out[j][0]; 
                    b2[j]  = -cw * ftmp_out[j][1]; 
                }
            }
            /* ------------------------------------------------------------- */


            /* Some pre-computations for Legendre functions */
            /* ------------------------------------------------------------- */
            t  = sin(lat[i]);
            u  = cos(lat[i]);
            x  = ROOT3 * u;
            ix = 0;

             ps[0] = x;
            ips[0] = ix;


            for (unsigned n = 1; n < nmax_sha; n++)
            {
                x = (dn[n] * u) * x;
                y = fabs(x);

                if (y >= BIGS)
                {
                     x *= BIGI;
                    ix += 1;
                }
                else if (y < BIGSI)
                {
                     x *= BIG;
                    ix -= 1;
                }

                 ps[n] = x;
                ips[n] = ix;
            }
            /* ------------------------------------------------------------- */






            /* Loop over harmonic orders */
            /* ------------------------------------------------------------- */
            for (unsigned int m = 0; m <= nmax_sha; m++)
            {
                
                /* Computation of "am" and "bm" coefficients for Legendre 
                 * recurrence relations */
                /* --------------------------------------------------------- */
                am[m] = r[2 * m + 3];
                for (unsigned int n = (m + 2); n <= nmax_sha; n++)
                {
                    wlf       = r[2 * n + 1] * ri[n - m] * ri[n + m];
                    am[n - 1] = r[2 * n - 1] * wlf;
                    bm[n - 1] = r[n - m - 1] * r[n + m - 1] * ri[2 * n - 3] 
                                * wlf;
                }
                /* --------------------------------------------------------- */


                /* Some useful substitutions */
                /* --------------------------------------------------------- */
                alcm  =  a[m];
                a2lcm = a2[m];
                blcm  =  b[m];
                b2lcm = b2[m];
                /* --------------------------------------------------------- */


                /* Computation of spherical harmonic coefficients */
                if (m == 0)
                {
                    /* Zonal harmonics */
                    /* ----------------------------------------------------- */

                    /* P00 */
                    pnm0 = 1.0;
                    csatmp = pnm0 * alcm;

                    if (i < imax)
                    {
                        csatmp += pnm0 * a2lcm;
                    }
                    cnm_priv[0][0] += csatmp; /* C00 */


                    /* P10 */
                    if (nmax_sha >= 1)
                    {
                        pnm1   = ROOT3 * t;
                        csatmp = pnm1 * alcm;

                        if (i < imax)
                        {
                            csatmp -= pnm1 * a2lcm;
                        }
                        cnm_priv[0][1] += csatmp; /* C10 */

                    }


                    /* P20, P30, ..., Pnmax,0 */
                    if (nmax_sha >= 2)
                    {
                        for (unsigned int n = 2; n <= nmax_sha; n++)
                        {
                            pnm2   = en[n] * t * pnm1 - fn[n] * pnm0;
                            csatmp = pnm2 * alcm;

                            if (i < imax)
                            {
                                if ((n % 2) == 0)
                                {
                                    csatmp += pnm2 * a2lcm;
                                }
                                else
                                {
                                    csatmp -= pnm2 * a2lcm;
                                }

                            }
                            cnm_priv[0][n] += csatmp; /* C20, C30, ...,
                                                       * Cnmax,0 */

                            pnm0 = pnm1;
                            pnm1 = pnm2;
                        }
                    }
                    /* ----------------------------------------------------- */
                }
                else /* Non-zonal harmonics */
                {

                    /* Sectorial harmonics */
                    /* ----------------------------------------------------- */
                     x =  ps[m - 1];
                    ix = ips[m - 1];

                    /* Pmm */
                    if (ix == 0)
                    {
                        pnm0 = x;
                    }
                    else if (ix < -1)
                    {
                        pnm0 = 0.0;
                    }
                    else if (ix < 0)
                    {
                        pnm0 = x * BIGI;
                    }
                    else
                    {
                        pnm0 = x * BIG;
                    }

                    csatmp = pnm0 * alcm;
                    csbtmp = pnm0 * blcm;

                    if (i < imax)
                    {
                        csatmp += pnm0 * a2lcm;
                        csbtmp += pnm0 * b2lcm;
                    }

                    cnm_priv[m][0] += csatmp; /* Cmm */
                    snm_priv[m][0] += csbtmp; /* Smm */
                    /* ----------------------------------------------------- */


                    /* Tesseral harmonics */
                    /* ----------------------------------------------------- */
                    if (m < nmax_sha)
                    {
                         y =  x;
                        iy = ix;
                         x = (am[m] * t) * y;
                        ix = iy;

                        wlf = fabs(x);
                        if (wlf >= BIGS)
                        {
                             x *= BIGI;
                            ix += 1;
                        }
                        else if (wlf < BIGSI)
                        {
                             x *= BIG;
                            ix -= 1;
                        }

                        /* Pm+1,m */
                        if (ix == 0)
                        {
                            pnm1 = x;
                        }
                        else if (ix < -1)
                        {
                            pnm1 = 0.0;
                        }
                        else if (ix < 0)
                        {
                            pnm1 = x * BIGI;
                        }
                        else
                        {
                            pnm1 = x * BIG;
                        }

                        csatmp = pnm1 * alcm;
                        csbtmp = pnm1 * blcm;

                        if (i < imax)
                        {
                            csatmp -= pnm1 * a2lcm;
                            csbtmp -= pnm1 * b2lcm;
                        }

                        cnm_priv[m][1] += csatmp; /* Cm+1,m */
                        snm_priv[m][1] += csbtmp; /* Sm+1,m */


                        /* Loop over degrees */
                        /* ------------------------------------------------- */
                        for (unsigned int n = (m + 2); n <= nmax_sha; n++)
                        {
                            ixy = ix - iy;

                            if (ixy == 0)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] * y;
                                iz = ix;
                            }
                            else if (ixy == 1)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] 
                                                           * (y * BIGI);
                                iz = ix;
                            }
                            else if (ixy == -1)
                            {
                                 z = (am[n - 1] * t) * (x * BIGI) \
                                     - bm[n - 1] * y;
                                iz = iy;
                            }
                            else if (ixy > 1)
                            {
                                 z = (am[n - 1] * t) * x;
                                iz = ix;
                            }
                            else
                            {
                                 z = -bm[n - 1] * y;
                                iz = iy;
                            }

                            wlf = fabs(z);
                            if (wlf >= BIGS)
                            {
                                 z *= BIGI;
                                iz += 1;
                            }
                            else if (wlf < BIGSI)
                            {
                                 z *= BIG;
                                iz -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz == 0)
                            {
                                pnm2 = z;
                            }
                            else if (iz < -1)
                            {
                                pnm2 = 0.0;
                            }
                            else if (iz < 0)
                            {
                                pnm2 = z * BIGI;
                            }
                            else
                            {
                                pnm2 = z * BIG;
                            }

                            csatmp = pnm2 * alcm;
                            csbtmp = pnm2 * blcm;

                            if (i < imax)
                            {
                                if (((n + m) % 2) == 0)
                                {
                                    csatmp += pnm2 * a2lcm;
                                    csbtmp += pnm2 * b2lcm;
                                }
                                else
                                {
                                    csatmp -= pnm2 * a2lcm;
                                    csbtmp -= pnm2 * b2lcm;
                                }
                            }

                            cnm_priv[m][n - m] += csatmp; /* Cm+2,m, Cm+3,m,
                                                           * ..., Cnmax,m */
                            snm_priv[m][n - m] += csbtmp; /* Sm+2,m, Sm+3,m,
                                                           * ..., Snmax,m */

                             y =  x;
                            iy = ix;
                             x =  z;
                            ix = iz;

                        } /* End of the loop over harmonic degrees */
                        /* ------------------------------------------------- */


                    } /* End of computation of tesseral harmonics */
                    /* ----------------------------------------------------- */


                } /* End of computation of spherical harmonic coefficients */
                /* --------------------------------------------------------- */


            } /* End of the loop over harmonic orders */
            /* ------------------------------------------------------------- */


        } /* End of the loop over latitude parallels */
        /* ----------------------------------------------------------------- */


        fftw_free(ftmp_in); fftw_free(ftmp_out);
        free(ips); free(ps); free(am); free(bm); free(a); free(b);
        free(a2); free(b2);


        /* Now let's add together the individual contributions to "cnm" and 
         * "snm" that are stored in each copy of "cnm_priv" and "snm_priv" in 
         * case of parallel computation via OpenMP */
        #pragma omp critical
        {
            for (unsigned int m = 0; m <= nmax_sha; m++)
            {
                for (unsigned int n = m; n <= nmax_sha; n++)
                {
                    cnm[m][n - m] += cnm_priv[m][n - m];
                    snm[m][n - m] += snm_priv[m][n - m];
                }
            }
        }


        sh_coeffs_free_dp(cnm_priv, snm_priv);

    } /* End of "#pragma omp parallel" */
    /* --------------------------------------------------------------------- */






    /* Freeing up the heap memory */
    /* --------------------------------------------------------------------- */
    free(r); free(ri); free(dn); free(en); free(fn);
    fftw_destroy_plan(plan);
    /* --------------------------------------------------------------------- */






    /* Multiplication of the "cnm" and "snm" arrays by the factor of "1 / (4 * 
     * pi)" */ 
    /* --------------------------------------------------------------------- */
    double c2 = 1.0 / (4.0 * M_PI);
    for (unsigned int m = 0; m <= nmax_sha; m++)
    {
        for (unsigned int n = m; n <= nmax_sha; n++)
        {
            cnm[m][n - m] *= c2;
            snm[m][n - m] *= c2;
        }
    }
    /* --------------------------------------------------------------------- */






    return;

}
