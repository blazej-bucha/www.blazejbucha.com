/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <dirent.h>
#include <errno.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
void mkdir_recursive(char *, mode_t);
/* ------------------------------------------------------------------------- */






FILE *fopen_create_path(char *file, char *mode)
/*
 * DESCRIPTION: Opens the stream for "file" with a given "mode" (e.g., "w", 
 * "wb", etc.).  If the path inside "file" (if any) does not exist, it will be 
 * created.
 * 
 * The function is useful when creating new files in directories that do not 
 * yet exist.
 *
 * Upon successful completion, the function returns a pointer to the stream and 
 * creates the path to "file" if needed.  Otherwise, it terminates the code 
 * execution.
 *
 * */
{
    /* Check if the directory in "file" (if any) exists.  If not, create one */
    /* --------------------------------------------------------------------- */
    /* Get the directory in "file" if any */
    char *dir = strdup(file);
    dirname(dir);


    /* If "dir" and "file" are not the same (could be if "file" contains only a 
     * file name) and the only character of "dir" is not '.', than it needs to 
     * be checked whether "dir" has to be created or not */
    if ((strcmp(dir, file) != 0) && !(dir[0] == '.' && strlen(dir) == 1))
    {
        DIR *chck_dir = opendir(dir);
        if (chck_dir)
        {
            /* The directory already exists, so close it */
            closedir(chck_dir);
        }
        else
        {
            /* The directory does not exist or could not be open.  Let's make 
             * an attempt to create it */
            printf("[sh_coeffs_write_mtx_txt_dp.c says:] The \"%s\" directory "
                   "not found, so creating it...\n", dir);
            mkdir_recursive(dir, 0755);
        }
    }

    free(dir);
    /* --------------------------------------------------------------------- */


    /* Now open the stream for "file" */
    /* --------------------------------------------------------------------- */
    FILE *fptr = fopen(file, mode);
    if (fptr == NULL)
    {
        printf("[fopen_create_path.c says:] The \"%s\" file "
               "could not be created.  Terminating the code execution.\n",
               file);
        exit(EXIT_FAILURE);
    }
    /* --------------------------------------------------------------------- */


    return fptr;
}
