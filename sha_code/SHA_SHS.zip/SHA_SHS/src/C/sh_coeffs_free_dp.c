/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






void sh_coeffs_free_dp(double **cnm, double **snm)
/*
 * DESCRIPTION: Deallocates 2D arrays of spherical harmonic coefficients "cnm" 
 * and "snm" that were initialized via "sh_coeffs_init_dp.c".
 *
 * The function is written in double precision.
 *
 *
 * EXAMPLE CALL: Assuming "cnm" and "snm" were initialized using 
 * "sh_coeffs_init_dp.c", the arrays can be deallocated as follows:
 *
 *      sh_coeffs_free_dp(cnm, snm);
 *
 *
 * NOTE: The usual deallocation
 *
 *      free(cnm), free(snm);
 *
 * will *not* deallocate the memory and will lead to memory leaks.
 *
 * */
{
    /* Deallocate the memory associated with the numerical values of spherical 
     * harmonic coefficients */
    free(cnm[0]), free(snm[0]);


    /* Deallocate the memory associated with the pointer arrays "cnm" and "snm" 
     * */
    free(cnm), free(snm);


    return;
}

