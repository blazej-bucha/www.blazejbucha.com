/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






void *arr_malloc(size_t size)
/* 
 * Allocates an 1D array of "size" bytes that is contiguous in memory and 
 * checks whether the allocation was successful.
 *
 * */ 
{

    void *vec = malloc(size);
    if (vec == NULL)
    {
        printf("[arr_malloc.c says:] \"malloc\" failed. "
        "Terminating the code.\n");

        exit(EXIT_FAILURE);
    }


    /* Return the pointer to the allocated vector "vec" */
    return vec;
}
