/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
/* ------------------------------------------------------------------------- */






double arr_min_dp(double *a, size_t na)
/* 
 * Returns the minimum value of an one-dimensional "double" array "a" of size 
 * "na".
 *
 * The function is written in double precision.
 * 
 * */
{

    double mv = a[0]; /* Initialization of the minimum value */
    double ai; /* The "i"th element of "a" */

    for (size_t i = 1; i < na; i++)
    {
        ai = a[i];
        if (ai < mv) mv = ai;
    }

    return mv;
}
