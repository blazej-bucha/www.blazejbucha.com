/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
FILE *fopen_create_path(char *, char *);
/* ------------------------------------------------------------------------- */






void sh_coeffs_write_mtx_txt_qp(char *file, __float128 **cnm, __float128 **snm,
                                unsigned int nmax, char *format)
/*
 * DESCRIPTION: Writes spherical harmonic coefficients up to degree "nmax" from 
 * __float128 precision arrays "cnm" and "snm" (created by "sh_coeffs_init_qp.c") 
 * to a text "file" using the specified "format".
 *
 * The output "file" has the following structure:
 *
 *    C_{00}       S_{11}       S_{21}       S_{31}      ...  S_{nmax,1}
 *    C_{10}       C_{11}       S_{22}       S_{32}      ...  S_{nmax,2}
 *    C_{20}       C_{21}       C_{22}       S_{33}      ...  S_{nmax,3}
 *    C_{30}       C_{31}       C_{32}       C_{33}      ...  S_{nmax,4}
 *    .                                                  .    .
 *    .                                                   .   .
 *    .                                                    .  .
 *    C_{nmax,0}   C_{nmax,1}   C_{nmax,2}   C_{nmax,3}  ...  C_{nmax,nmax}
 *
 * where "C_{n,m}" and "S_{n,m}" are spherical harmonic coefficients of degree 
 * "n" and order "m".  It must hold that the "cnm" and "snm" arrays store 
 * spherical harmonic coefficients up to degree "nmax2 >= nmax".  That is, from 
 * all coefficients in "cnm" and "snm" up to degree "nmax2", properly written
 * can be any subset up to degree "nmax <= nmax2".
 *
 * The function is written in quadruple precision.
 *
 * */
{
    /* Open a buffer for the output "file".  If "file" does not exist, create 
     * it.  No check on whether "fptr" is null is needed, as this is done by 
     * "fopen_create_path.c". */
    FILE *fptr = fopen_create_path(file, "w");


    /* A particular coefficient to be written to the text file, either "cnm" or 
     * "snm" */
    __float128 coeff;


    /* Variable to check whether "fprintf" was successful */
    int err;


    /* Loop over the rows of the output matrix */
    for(unsigned int r = 0; r <= nmax; r++)
    {
        /* Loop over the columns of the output matrix */
        for(unsigned int c = 0; c <= nmax; c++) 
        {
            if (r >= c)
                coeff = cnm[c][r - c];
            else
                coeff = snm[r + 1][c - r - 1];


            err = fprintf(fptr, format, coeff);
            if (err < 1)
            {
                printf("[sh_coeffs_write_mtx_txt_qp.c says:] Error "
                       "encountered when writing to \"%s\" (matrix row %u, "
                       "column %u).  Terminating the code execution.\n",
                       file, r + 1, c + 1);
                exit(EXIT_FAILURE);
            }
        }


        fprintf(fptr, "\n");
        if (err < 1)
        {
            printf("[sh_coeffs_write_mtx_txt_qp.c says:] Error "
                   "encountered when writing the new line character to \"%s\" "
                   "(matrix row %u).  Terminating the code execution.\n",
                   file, r + 1);
            exit(EXIT_FAILURE);
        }
    }


    err = fclose(fptr);
    if (err != 0)
    {
        printf("[sh_coeffs_write_mtx_txt_qp.c says:] Error encountered when "
               "closing the stream for \"%s\".  Terminating the code "
               "execution.\n", file);
        exit(EXIT_FAILURE);
    }


    return;
}
