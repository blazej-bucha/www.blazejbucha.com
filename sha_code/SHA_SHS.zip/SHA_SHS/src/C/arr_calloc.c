/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






void *arr_calloc(size_t n, size_t size)
/* 
 * Allocates an 1D numerical array of "n" elements of "size" bytes (double, 
 * float, long double, __float128, etc.) that is contiguous in memory, checks
 * whether the allocation was successful, and fills each array element with a 
 * zero.
 *
 * */ 
{

    void *vec = calloc(n, size);
    if (vec == NULL)
    {
        printf("[arr_calloc.c says:] \"calloc\" failed. "
        "Terminating the code.\n");

        exit(EXIT_FAILURE);
    }


    /* Return the pointer to the allocated vector "vec" */
    return vec;
}
