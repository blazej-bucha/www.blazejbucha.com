/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






void sh_coeffs_read_bin_dp(char *file, double **cnm, double **snm,
                           unsigned int nmax)
/*
 * DESCRIPTION: Reads spherical harmonic coefficients up to degree "nmax" from 
 * a binary "file" (created by "sh_coeffs_write_bin_dp.c") to double precision 
 * arrays "cnm" and "snm" (created by "sh_coeffs_init_dp.c").
 *
 * The input "file" is a binary representation of the spherical harmonic 
 * coefficients in the following order:
 *
 * C_{0,0} C_{1,0} C_{2,0} ... C_{nmax,0} C_{1,1} C_{2,1} ... C_{nmax,1} \
 * C_{2,2} C_{3,2} ... C_{nmax,nmax} S_{0,0} S_{1,0} S_{2,0} ... S_{nmax,0} \
 * S_{1,1} S_{2,1} ... S_{nmax,1} S_{2,2} S_{3,2}... S_{nmax,nmax}
 *
 * where "C_{n,m}" and "S_{n,m}" are spherical harmonic coefficients of degree 
 * "n" and order "m".  It must hold that "nmax <= nmax2".  That is, from all 
 * coefficients in "file" up to degree "nmax2", properly loaded can be any 
 * subset up to degree "nmax <= nmax2".  For each coefficient, "sizeof(double)" 
 * bytes are reserved.
 *
 * The function is written in double precision.
 *
 * */
{
    /* Open a buffer for the input "file" */
    FILE *fptr = fopen(file, "rb");
    if (fptr == NULL)
    {
        printf("[sh_coeffs_read_bin_dp.c says:] The \"%s\" file not "
               "found.  Terminating the code execution.\n", file);

        exit(EXIT_FAILURE);
    }


    /* Variable to check whether "fwrite" was successful */
    int err;


    /* Read the "cnm" coefficients */
    /* ===================================================================== */
    /* Loop over the harmonic orders */
    for(unsigned int m = 0; m <= nmax; m++)
    {
        err = fread(cnm[m], sizeof(double), nmax + 1 - m, fptr);
        if (err < 1)
        {
            printf("[sh_coeffs_read_dp.c says:] Error "
                   "encountered when reading from \"%s\" (C coefficient of "
                   "harmonic order %u).  "
                   "Terminating the code execution.\n", file, m);
            exit(EXIT_FAILURE);
        }
    }
    /* ===================================================================== */


    /* Read the "snm" coefficients */
    /* ===================================================================== */
    /* Loop over the harmonic orders */
    for(unsigned int m = 0; m <= nmax; m++)
    {
        err = fread(snm[m], sizeof(double), nmax + 1 - m, fptr);
        if (err < 1)
        {
            printf("[sh_coeffs_read_bin_dp.c says:] Error "
                   "encountered when reading from \"%s\" (S coefficient of "
                   "harmonic order %u).  "
                   "Terminating the code execution.\n", file, m);
            exit(EXIT_FAILURE);
        }
    }
    /* ===================================================================== */



    err = fclose(fptr);
    if (err != 0)
    {
        printf("[sh_coeffs_read_bin_dp.c says:] Error encountered when "
               "closing the stream for \"%s\".  Terminating the code "
               "execution.\n", file);
        exit(EXIT_FAILURE);
    }


    return;
}
