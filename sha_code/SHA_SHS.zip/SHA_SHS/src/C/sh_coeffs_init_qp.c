/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






/* Header files */
/* ------------------------------------------------------------------------- */
void *arr_malloc(size_t);
void *arr_calloc(size_t, size_t);
/* ------------------------------------------------------------------------- */






void sh_coeffs_init_qp(__float128 ***cnm, __float128 ***snm, unsigned int nmax)
/*
 * DESCRIPTION: Allocates and initializes 2D arrays "cnm" and "snm" to store 
 * spherical harmonic coefficients up to degree "nmax".  The first dimension of 
 * the two arrays is related to harmonic orders and the second one to harmonic 
 * degrees.  Importantly, the number of columns varies for each row as follows:
 *
 *      Order 0: "cnm[0]" has "nmax + 1" columns for degrees "0, 1, ..., nmax" 
 *      (respectively),
 *
 *      Order 1: "cnm[1]" has "nmax" columns for degrees "1, 2, ..., nmax" 
 *      (respectively),
 *
 *      Order 2: "cnm[2]" has "nmax - 1" columns for degrees "2, 3, ..., nmax" 
 *      (respectively),
 *
 *      .
 *      .
 *      .
 *
 *      Order "nmax": "cnm[nmax]" has "1" column for degree 
 *      "nmax".
 *
 * The same scheme applies to "snm", too.  Therefore, "cnm" and "snm" are *not* 
 * 2D rectangular arrays!  Harmonic coefficients of degree "n" and order "m" 
 * can be accessed as follows:
 *
 *      cnm[m][n - m]
 *      snm[m][n - m]
 * 
 * All coefficients are initialized to zero.  If any allocation fails, the 
 * program execution is terminated.
 *
 * The coefficients (elements) in "cnm" and "snm" are stored in two blocks of 
 * memory, each being *contiguous*.  For fast sequential access, the loop over 
 * harmonic orders should always be the outer one, in which the 
 * degree-dependent loop is nested, such as:
 *
 *      for (unsigned int m = 0; m <= nmax; m++)
 *      {
 *          for (unsigned int n = m; n <= nmax; n++)
 *          {
 *              cnm[m][n - m];
 *              snm[m][n - m];
 *          }
 *      }
 *
 * The function is written in quadruple precision.
 *
 *
 * EXAMPLE CALL: Two arrays of spherical harmonic coefficients, "cnm" and 
 * "snm", can be initialized up to maximum harmonic degree "100" as follows:
 *
 *      __float128 **cnm, **snm;
 *      sh_coeffs_init_qp(&cnm, &snm, 100);
 *
 *
 * NOTE: The arrays "cnm" and "snm" created by this function must be 
 * deallocated by calling:
 *
 *      sh_coeffs_free_qp(cnm, snm);
 *
 * The usual deallocation
 *
 *      free(cnm), free(snm);
 *
 * will *not* deallocate the memory and will lead to memory leaks.
 *
 * */
{
    /* Get the size of the first dimension of the output "cnm" and "snm" arrays 
     * (number of harmonic orders) */
    size_t nmax1 = (size_t)(nmax + 1);


    /* Allocate the output "cnm" and "snm" arrays */
    /* --------------------------------------------------------------------- */
    *cnm = (__float128 **)arr_malloc(nmax1 * sizeof(__float128 *));
    *snm = (__float128 **)arr_malloc(nmax1 * sizeof(__float128 *));
    /* --------------------------------------------------------------------- */


    /* Allocate two blocks of memory that will store the spherical harmonic 
     * coefficients and initialize them to zeros */
    /* --------------------------------------------------------------------- */
    /* Get the total number of coefficients to be stored in "cnm" and "snm".  
     * Note that the "S_{n,0}" coefficients, which do not exist, will be stored 
     * in "snm" as zeros. */
    size_t len = (nmax1 + 1) * nmax1 / 2;


    (*cnm)[0] = arr_calloc(len, sizeof(__float128));
    (*snm)[0] = arr_calloc(len, sizeof(__float128));
    /* --------------------------------------------------------------------- */


    /* Set "cnm[m]" and "snm[m]" to point to "C_{m,m}" and "S_{m,m}" */
    /* --------------------------------------------------------------------- */
    size_t ptr_m = 0;


    for (size_t m = 0; m < nmax1; m++)
    {
        /* Now set "cnm[m]" and "snm[m]" to point to "C_{m,m}" and "S_{m,m}" */
        (*cnm)[m] = (*cnm)[0] + ptr_m;
        (*snm)[m] = (*snm)[0] + ptr_m;


        ptr_m += nmax1 - m;
    }
    /* --------------------------------------------------------------------- */
}
