/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <math.h>
/* ------------------------------------------------------------------------- */






void gl_grd_qp(unsigned int nmax, __float128 *lat, __float128 *lon, __float128 *w)
/*
 * ============================================================================
 *
 * DESCRIPTION: This function generates latitudes, longitudes and weights of
 *              the grid nodes required by the Gauss--Legendre quadrature
 *              (e.g., Sneeuw, 1994) for a specified maximum harmonic degree.
 *
 *              Note that the grid is non-equiangular in terms of latitudes.
 *              The step in the longitudinal direction is, however, constant.
 *
 *              The function is written in quadruple precision.
 *
 *
 * INPUTS:   "nmax" -- Maximum spherical harmonic degree of the signal that
 *                     is to be harmonically analysed
 *
 *
 * OUTPUTS:  "lat" -- Pointer to an array of spherical latitudes in radians.
 *                    Dimension (nmax + 1).
 *
 *           "lon" -- Pointer to an array of longitudes in radians.
 *                    Dimension (2 * nmax + 2).
 *
 *           "w"   -- Pointer to an array of weights given by the 
 *                    Gauss--Legendre quadrature (dimensionless).
 *                    Dimension (nmax + 1).
 *
 *
 * This function is based on the MATLAB "legzo.m" function
 * (https://github.com/Pazus/Legendre-Gauss-Quadrature/blob/master/legzo.m)
 * published by Pazus (https://github.com/Pazus). Minor modifications were
 * introduced, such that it now yields spherical latitudes and longitudes
 * as the output coordinates.
 *
 *
 * REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
 *                least-squares and numerical quadrature methods in historical
 *                perspective. Geophysical Journal International 118:707--716
 *
 * ========================================================================= */
{

    unsigned int nmax1 = nmax + 1;

    /* Note that "m" is rounded to the greatest integer less than or equal to 
     * "(nmax1 + 1) / 2". */
    unsigned int m = (nmax1 + 1) / 2; 


    __float128 c = (__float128)nmax1 + 0.5q;

    
    /* Computation of the latitudes and weights */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel default(none) shared(lat, w, nmax1, m, c)
    {
    __float128 z, z1, p1, p2, p3, pp;


    #pragma omp for
    for (unsigned int i = 0; i < m; i++) 
    {
        z = cosq(M_PIq * ((__float128)(i + 1) - 0.25q) / c); 
        z1 = z + 1.0q;


        while (fabsq(z - z1) > FLT128_EPSILON)
        {
            p1 = 1.0q;
            p2 = 0.0q;


            for (unsigned int j = 1; j <= nmax1; j++)
            {
                p3 = p2;
                p2 = p1;
                p1 = ((__float128)(2 * j - 1) * z * p2 - (__float128)(j - 1) * p3)
                     / (__float128)j;
            }


            pp = (__float128)nmax1 * (z * p1 - p2) / (z * z - 1.0q);
            z1 = z;
            z  = z1 - p1 / pp;
        }


        lat[nmax1 - 1 - i] = asinq(z);
        lat[i] = -lat[nmax1 - 1 - i];


        w[nmax1 - 1 - i] = 2.0q / ((1.0q - z * z) * pp * pp);
        w[i] = w[nmax1 - 1 - i];
    }
    }
    /* --------------------------------------------------------------------- */


    /* Computation of the longitudes */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel for default(none) shared(lon, nmax1)
    for (unsigned int i = 0; i < (2 * nmax1); i++)
        lon[i] = M_PIq / (__float128)nmax1 * (__float128)(i);
    /* --------------------------------------------------------------------- */


    return;
}
