/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
/* ------------------------------------------------------------------------- */






__float128 arr_min_qp(__float128 *a, size_t na)
/* 
 * Returns the minimum value of an one-dimensional "__float128" array "a" of size 
 * "na".
 *
 * The function is written in quadruple precision.
 * 
 * */
{

    __float128 mv = a[0]; /* Initialization of the minimum value */
    __float128 ai; /* The "i"th element of "a" */

    for (size_t i = 1; i < na; i++)
    {
        ai = a[i];
        if (ai < mv) mv = ai;
    }

    return mv;
}
