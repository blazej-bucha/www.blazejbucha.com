/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
double arr_min_dp(double *, size_t);
void *arr_calloc(size_t, size_t);

void sh_coeffs_init_dp(double ***, double ***, unsigned int);
void sh_coeffs_free_dp(double **, double **);
/* ------------------------------------------------------------------------- */






void sh_surf_analysis_mean_dp(double *lat1, double *lat2, size_t nlat,
                              double *lon1, double *lon2, size_t nlon,
                              double *f, unsigned int nmax, double **cnm,
                              double **snm)
/*
 * ==========================================================================
 *
 * DESCRIPTION: This function computes spherical harmonic coefficients up to 
 *              degree "nmax" by harmonically analysing a global grid of 
 *              block-mean values of a signal "f".
 *
 *              The function is written in double precision.
 *
 *              The loop over latitudes is parallelized using OpenMP.
 *
 *              The 4*pi fully-normalized associated Legendre functions
 *              (e.g., Heiskannen and Moritz, 1967) are evaluated by the
 *              numerically stable algorithm by Fukushima (2012). The algorithm
 *              can be used up to ultra-high harmonic degrees (say, tens of
 *              thousands or even well beyond).
 *
 *              As the main input, the signal to be analysed is represented
 *              by an array of block-mean values as one of the input variables 
 *              (see the variable "f" below). Importantly, the whole array is 
 *              stored in RAM during the entire harmonic analysis. The same 
 *              holds for the output spherical harmonic            
 *              coefficients. Ultra-high-degree analysis may therefore require 
 *              tens of GBs of RAM.
 *
 *              If possible, the function exploits the symmetry property of 
 *              Legendre functions and their integrals with respect to the 
 *              equator, thereby improving its performance, especially for 
 *              ultra-high-degree harmonic analysis. For further details the 
 *              symmetric grid, see "sh_surf_synthesis_mean_dp.c".
 *
 *
 * INPUTS: "lat1"        -- Pointer to an array defining the minimum latitudes 
 *                          of the grid cells in radians (latitudes over a 
 *                          single meridian).
 *
 *         "lat2"        -- Pointer to an array defining the maximum latitudes 
 *                          of the grid cells in radians (latitudes over a 
 *                          single meridian).
 *
 *         "nlat"        -- Number of latitudes in the "lat1" and "lat2" 
 *                          arrays.
 *
 *         "lon1"        -- Pointer to an array defining the minimum longitudes
 *                          of the grid cells in radians (longitudes over a 
 *                          single parallel).
 *
 *         "lon2"        -- Pointer to an array defining the maximum longitudes
 *                          of the grid cells in radians (longitudes over a 
 *                          single parallel).
 *
 *         "nlon"        -- Number of longitudes in the "lon1" and "lon2" 
 *                          arrays.
 *
 *         "f"           -- Pointer to an array of the input signal of 
 *                          block-mean values.
 *
 *                          Using the traditional row-major order of matrix 
 *                          elements in C, the array to which "f" points can be 
 *                          depicted as a matrix of the dimensions (nlat, 
 *                          nlon), sampled as follows:
 *
 *  [(lat[0,0],lon[0,0])           ...       (lat[0,0],lon[nlon - 1,nlon - 1]]
 *  [      .                       .                           .             ]
 *  [      .                        .                          .             ]
 *  [      .                         .                         .             ]
 *  [(lat[nlat-1,nlat-1],lon[0,0]) ... (lat[nlat-1,nlat-1],lon[nlon-1,nlon-1]]
 *
 *                          where "lat[i,i]" represents the cell with the 
 *                          minimum latitude "lat1[i]" and maximum latitude 
 *                          "lat2[i]", and "lon[j,j]" stands for the cell with 
 *                          the minimum longitude "lon1[j]" and maximum 
 *                          longitude "lon2[j]".
 *
 *                          This means that, for instance, the value of "f" for 
 *                          "lat1[i]", "lat2[i]", "lon1[j]" and "lon2[j]" can 
 *                          be found as follows:
 *
 *                          "f[i * nlon + j]"
 *
 *         "nmax"        -- Maximum harmonic degree of the output spherical
 *                          harmonic coefficients.
 *
 *
 * OUTPUTS: "cnm"       -- Double pointer to a 2D array with the output "Cnm" 
 *                         spherical harmonic coefficients. The first dimension 
 *                         is related to harmonic orders and the second one to 
 *                         harmonic degrees. Importantly, the number of columns 
 *                         varies for each row as follows:
 *
 *
 *                         Order 0: "cnm[0]" has "nmax + 1" columns for degrees 
 *                         "0, 1, ..., nmax" (respectively),
 *
 *                         Order 1: "cnm[1]" has "nmax" columns for degrees "1, 
 *                         2, ..., nmax" (respectively),
 *
 *                         Order 2: "cnm[2]" has "nmax - 1" columns for degrees 
 *                         "2, 3, ..., nmax" (respectively),
 *
 *                         .
 *                         .
 *                         .
 *
 *                         Order "nmax": "cnm[nmax]" has "1" column for degree 
 *                         "nmax".
 *
 *
 *                         This means that "cnm" is *not* a 2D rectangular 
 *                         array. It should be allocated by 
 *                         "sh_coeffs_init_dp.c" and deallocated by 
 *                         "sh_coeffs_free_dp.c".
 *
 *                         The harmonic coefficient "Cnm" of degree "n" and 
 *                         order "m" can therefore be accessed as follows:
 *
 *                         cnm[m][n - m]
 *
 *         "snm"       -- The same as "cnm" above, but with the "Snm" 
 *                        coefficients.
 *
 *
 * REFERENCES: Colombo, O. L. (1981) Numerical methods for harmonic analysis on 
 *                the sphere. Reports of the Department of Geodetic Science, 
 *                Report No. 310, 140 pp
 *
 *             Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
 *                Freeman and Company, San Francisco, 364 pp
 *            
 *             Jekeli, C., Lee, J. K., Kwon, J. H. (2007) On the computation
 *                and approximation of ultra-high-degree spherical harmonic 
 *                series. Journal of Geodesy 81:603--615
 *
 *             Fukushima, T. (2012) Numerical computation of spherical
 *                harmonics of arbitrary degree and order by extending exponent
 *                of floating point numbers. Journal of Geodesy 86:271--285.
 *
 *             Balmino, Vales, Bonvalot, Briais, 2012. Spherical harmonic
 *                 modelling to ultra-high degree of Bouguer and isostatic
 *                 anomalies. Journal of Geodesy 86:499–520,
 *                 doi: 10.1007/s00190-011-0533-4
 *
 *            Fukushima, T. (2014) Numerical computation of spherical harmonics
 *                of arbitrary degree and order by extending exponent of
 *                floating point numbers: III integral. Computers & Geosciences
 *                63:17--21
 *
 *
 * Contact: blazej.bucha@stuba.sk
 *
 *
 * Please use the following reference when using this function:
 *
 *          Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
 *             spectral gravity forward modelling up to the full gravity
 *             tensor. Journal of Geodesy 93:1707--1737
 *
 *
 * ========================================================================= */
{

    /* Some useful constants */
    /* --------------------------------------------------------------------- */
    /* Threshold to judge whether two double numbers are equal (can be changed 
     * as needed) */
    const double THRESHOLD = 10000.0 * __DBL_EPSILON__;


    /* Some constants to compute associated Legendre functions using the 
     * extended-range arithmetic approach */
    const int IND = 960;
    const double BIG = pow(2.0, IND);
    const double BIGI = pow(2.0, -IND);
    const double BIGS = pow(2.0, IND / 2.0);
    const double BIGSI = pow(2.0, -IND / 2.0);
    const double ROOT3 = 1.7320508075688772935;
    /* --------------------------------------------------------------------- */






    /* Check the latitudes of the computational grid */
    /* --------------------------------------------------------------------- */
    /* Check whether the number of latitudes in "lat1" and "lat2" is even or 
     * odd */
    /* ..................................................................... */
    int even;
    if ((nlat % 2) == 0)
    {
        even = 1; /* The number of cells in the latitudinal direction is an
                   * even number */
    }
    else
    {
        even = 0; /* The number of cells in the latitudinal direction is an
                   * odd number */
    }
    /* ..................................................................... */


    /* Determine whether the latitudes are symmetric with respect to the
     * equator */
    /* ..................................................................... */
    int symm; /* If the grid is symmetric with respect to the equator, then
               * "symm = 1", otherwise "symm = 0". If "symm == 1", the function 
               * automatically exploits the symmetry property of Legendre 
               * functions in order to accelerate the computation */
    if (nlat == 1)
    {
        symm = 0; /* If there is only one cell in the latitudinal direction 
                   * within the grid, the grid is automatically considered as 
                   * not symmetric */
    }
    else
    {
        symm = 1; /* If there is more than one cell in the latitudinal 
                   * direction in the grid, let's start by assuming that the 
                   * grid is symmetric with respect to the equator and check 
                   * whether this is indeed true */

    }


    for (size_t i = 0; i < nlat; i++)
    {
        if (fabs(lat1[i] + lat2[nlat - i - 1]) > THRESHOLD)
        {
            symm = 0; /* The grid is not symmetric */

            break; /* Exiting the loop with the final decision: the grid is not
                    * symmetric with respect to the equator ("symm = 0") */
        }
    }
    /* ..................................................................... */


    /* Finally, if the grid is symmetric, we modify the number of latitudes 
     * "nlat" to be equal to the number of latitudes on one hemisphere only 
     * (including the equator if present). This is because the time-consuming 
     * "for loop" over evaluation points now needs to run for one hemisphere 
     * only, while the results for the other hemisphere are obtained by 
     * exploiting the symmetry property of Legendre functions. This reduces the 
     * number of Legendre functions that need to be evaluated by a factor of 
     * ~2, so saves some computational time */
    /* ..................................................................... */
    size_t nlatdo;
    if (symm == 1)
    {
        if (even == 1)
        {
            nlatdo = nlat / 2;
        }
        else
        {
            nlatdo = (nlat + 1) / 2;
        }
    }
    else
    {
        nlatdo = nlat;
    }
    /* ..................................................................... */
    /* --------------------------------------------------------------------- */
    





    /* Check the longitudes of the computational grid */
    /* --------------------------------------------------------------------- */
    /* Check whether the first elements of "lon1" and "lon2" are the smallest 
     * one. Otherwise, the execution of the code is terminated. */
    double lon0 = lon1[0];
    if (fabs(lon0 - arr_min_dp(lon1, nlon)) > THRESHOLD)
    {
        printf("\n[sh_surf_analysis_mean_dp.c says:] The first element of the "
               "longitude vector \"lon1\" has to be the smallest one. "
               "Terminating the code.\n");
        exit(EXIT_FAILURE);
    }
    lon0 = lon2[0];
    if (fabs(lon0 - arr_min_dp(lon2, nlon)) > THRESHOLD)
    {
        printf("\n[sh_surf_analysis_mean_dp.c says:] The first element of the "
               "longitude vector \"lon2\" has to be the smallest one. "
               "Terminating the code.\n");
        exit(EXIT_FAILURE);
    }


    /* Useful substitution. The variable "lon" represents the mean longitude of 
     * the grid cells. */
    double *lon = (double *)arr_calloc(nlon, sizeof(double));
    for (size_t j = 0; j < nlon; j++)
    {
        lon[j] =(lon1[j] + lon2[j]) / 2.0; 
    }


    /* Get the origin of the longitude "lon" array (will be necessary later for 
     * the PSLR algorithm) */
    lon0 = lon[0];

    
    /* Get the lon step of the grid (will be necessary later for the PSLR 
     * algorithm) */
    double dlon;
    if (nlon > 1)
    {
        if (fabs((lon1[1] - lon1[0]) - (lon2[1] - lon2[0])) > THRESHOLD)
        {
             printf("\n[sh_surf_analysis_mean_dp.c says:] The difference "
                    "\"lon1[1] - lon1[0]\" has to be equal to "
                    "\"lon2[1] - lon2[0]\". Terminating the code.\n");
             exit(EXIT_FAILURE);
        }
        dlon = lon1[1] - lon1[0];
    }
    else
    {
        dlon = 0.0;
    }


    /* Check whether the longitude step is constant for the entire "lon1" and 
     * "lon2" vectors. Otherwise, the execution of the code is terminated. */
    double dlonchck;
    for (size_t j = 1; j < nlon; j++)
    {
        dlonchck = lon1[j] - lon1[j - 1];
        if (fabs(dlon - dlonchck) > THRESHOLD)
        {
            printf("\n[sh_surf_analysis_mean_dp.c says:] The longitudinal "
                   "step of \"lon1\" has to be constant. "
                   "Terminating the code.\n");
            exit(EXIT_FAILURE);
        }


        dlonchck = lon2[j] - lon2[j - 1];
        if (fabs(dlon - dlonchck) > THRESHOLD)
        {
            printf("\n[sh_surf_analysis_mean_dp.c says:] The longitudinal "
                   "step of \"lon2\" has to be constant. "
                   "Terminating the code.\n");
            exit(EXIT_FAILURE);
        }
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute Legendre 
     * functions. */
    /* --------------------------------------------------------------------- */
    double w;
    double *r = (double *)arr_calloc(2 * nmax + 4, sizeof(double));
    double *ri = (double *)arr_calloc(2 * nmax + 4, sizeof(double));

    r[0]  = 0.0;
    ri[0] = 0.0;
    for (unsigned int m = 1; m <= (2 * nmax + 3); m++)
    {
        w = sqrt((double)m);
        r[m] = w;
        ri[m] = 1.0 / w;
    }


    /* Coefficients "dn" for recurrence relations to compute fully-normalized 
     * Legendre functions */
    double *dn = (double *)arr_calloc(nmax + 1, sizeof(double));
    dn[0] = 0.0;
    for (unsigned int n = 1; n <= nmax; n++)
    {
        dn[n] = r[2 * n + 3] * ri[2 * n + 2];
    }


    /* Coefficients "en" and "fn" for recurrence relations to compute 
     * *un-normalized* Legendre polynomials. (Note that to compute integrals of 
     * fully-normalized Legendre polynomials, we need un-normalized Legendre 
     * polynomials; see, e.g., Eq. B.24 of Jekeli et al. 2007) */
    double *en = (double *)arr_calloc(nmax + 2, sizeof(double));
    double *fn = (double *)arr_calloc(nmax + 2, sizeof(double));

    for (unsigned int n = 2; n < nmax + 2; n++)
    {
        en[n] = (double)(2 * n - 1) / (double)n;
        fn[n] = (double)(n - 1) / (double)n;
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute integrals of 
     * fully-normalized Legendre functions */
    /* --------------------------------------------------------------------- */
    /* Computation of "gn" coefficients */
    double *gn = (double *)arr_calloc(nmax + 1, sizeof(double));
    for (unsigned int n = 3; n < (nmax + 1); n++)
    {
        gn[n] = 1.0 / (double)(2 * n + 2) * r[n] * r[2 * n + 1]
              * r[2 * n - 1] * ri[n - 1];
    }


    /* Computation of "hn" coefficients */
    double *hn = (double *)arr_calloc(nmax + 1, sizeof(double));
    for (unsigned int n = 0; n < (nmax + 1); n++)
    {
        hn[n] = (double)(n - 2) / (double)(n + 1);
    }
    /* --------------------------------------------------------------------- */






    /* Initialize all elements of the output coefficients to zero */
    /* --------------------------------------------------------------------- */
    for (unsigned int n = 0; n <= nmax; n++)
    {
        for (unsigned int m = 0; m <= n; m++)
        {
            cnm[m][n - m] = 0.0;
            snm[m][n - m] = 0.0;
        }
    }
    /* --------------------------------------------------------------------- */






    /* Create a plan for FFT */
    /* --------------------------------------------------------------------- */
    double *ftmp_in        = (double *)fftw_malloc(nlon * sizeof(double));
    fftw_complex *ftmp_out = (fftw_complex *)fftw_malloc(sizeof(fftw_complex) 
                                                         * (nlon / 2 + 1));

    fftw_plan plan = fftw_plan_dft_r2c_1d(nlon, ftmp_in, ftmp_out,
                                          FFTW_ESTIMATE);

    fftw_free(ftmp_in); fftw_free(ftmp_out);
    /* --------------------------------------------------------------------- */






    /* Loop over latitudes */
    /* --------------------------------------------------------------------- */
    size_t imax = nlatdo + even - 1;

    #pragma omp parallel default(none) \
    shared(cnm, snm, f, lat1, lat2, nlat, lon1, lon2, nlon, w, nlatdo, imax) \
    shared(dlon, nmax, dn, en, fn, gn, hn, r, ri, even, symm, plan)
    {

        /* Initialization of the private copies of "cnm" and "snm" arrays that 
         * will store the individuals contributions computed by each CPU in 
         * case of parallel computation via OpenMP.
         * 
         * If parallel computation is not employed, "cnm_priv" and "snm_priv" 
         * are rather useless and increase RAM requirements. To fix this, one 
         * can 1) remove the declarations of "cnm_priv" and "snm_priv" that 
         * follow right after this comment, 2) delete the code block related to 
         * "#pragma omp critical" (see below), 3) delete the "free" commands 
         * related to "cnm_priv" and "snm_priv", and 4) rename all the 
         * remaining occurrences of "cnm_priv" and "snm_priv" by "cnm" and 
         * "snm", respectively. This, however, is possible only in case of 
         * serial computation without OpenMP. */
        /* ................................................................. */
        double **cnm_priv, **snm_priv;
        sh_coeffs_init_dp(&cnm_priv, &snm_priv, nmax);
        /* ................................................................. */


        double *ftmp_in        = (double *)fftw_malloc(nlon * sizeof(double));
        fftw_complex *ftmp_out = (fftw_complex *)fftw_malloc(
                                 sizeof(fftw_complex) * (nlon / 2 + 1));

        double lat1i, lat2i;
        double t1, u1, x1, y1, z1;
        double t2, u2, x2, y2, z2;
        int ix1, iy1, iz1, ixy1;
        int ix2, iy2, iz2, ixy2;
        double pnm0_lat1i, pnm1_lat1i, pnm2_lat1i;
        double pnm0_lat2i, pnm1_lat2i, pnm2_lat2i;

        int   *ips1 = (int *)arr_calloc(nmax + 1, sizeof(int));
        int   *ips2 = (int *)arr_calloc(nmax + 1, sizeof(int));
        double *ps1 = (double *)arr_calloc(nmax, sizeof(double));
        double *ps2 = (double *)arr_calloc(nmax, sizeof(double));
        double *a   = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *b   = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *a2  = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *b2  = (double *)arr_calloc(nlon / 2 + 1, sizeof(double));
        double *am  = (double *)arr_calloc(nmax + 1, sizeof(double));
        double *bm  = (double *)arr_calloc(nmax, sizeof(double));

        double amp1, bmp1, a2mp1, b2mp1, cm, sm;
        double csatmp, csbtmp;
        double in0, inm0, inm1, inm2, imm0, imm1, imm2;


        #pragma omp for
        for (size_t i = 0; i < nlatdo; i++)
        {

            /* Lumped coefficients for the southern hemisphere (including the 
             * equator) */
            /* ------------------------------------------------------------- */
            for (size_t j = 0; j < nlon; j++)
            {
                ftmp_in[j] = f[i * nlon + j];
            }
            fftw_execute_dft_r2c(plan, ftmp_in, ftmp_out);

            for (ssize_t j = 0; j < (nlon / 2 + 1); j++)
            {
                a[j]  =  ftmp_out[j][0]; 
                b[j]  = -ftmp_out[j][1]; 
            }
            /* ------------------------------------------------------------- */


            /* Lumped coefficients for the northern hemisphere */
            /* ------------------------------------------------------------- */
            if (i < imax)
            {
                for (size_t j = 0; j < nlon; j++)
                {
                    ftmp_in[j] = f[(nlat - i - 1) * nlon + j];
                }
                fftw_execute_dft_r2c(plan, ftmp_in, ftmp_out);

                for (size_t j = 0; j < (nlon / 2 + 1); j++)
                {
                    a2[j]  =  ftmp_out[j][0]; 
                    b2[j]  = -ftmp_out[j][1]; 
                }
            }
            /* ------------------------------------------------------------- */


            /* Some pre-computations for Legendre functions */
            /* ------------------------------------------------------------- */
            /* lat1[i] */
            /* ............................................................. */
            lat1i = lat1[i];
            t1  = sin(lat1i);
            u1  = cos(lat1i);
            x1  = ROOT3 * u1;
            ix1 = 0;

             ps1[0] = x1;
            ips1[0] = ix1;


            for (unsigned int n = 1; n < nmax; n++)
            {
                x1 = (dn[n] * u1) * x1;
                y1 = fabs(x1);

                if (y1 >= BIGS)
                {
                     x1 *= BIGI;
                    ix1 += 1;
                }
                else if (y1 < BIGSI)
                {
                     x1 *= BIG;
                    ix1 -= 1;
                }

                 ps1[n] = x1;
                ips1[n] = ix1;
            }
            /* ............................................................. */


            /* lat2[i] */
            /* ............................................................. */
            lat2i = lat2[i];
            t2  = sin(lat2i);
            u2  = cos(lat2i);
            x2  = ROOT3 * u2;
            ix2 = 0;

             ps2[0] = x2;
            ips2[0] = ix2;


            for (unsigned int n = 1; n < nmax; n++)
            {
                x2 = (dn[n] * u2) * x2;
                y2 = fabs(x2);

                if (y2 >= BIGS)
                {
                     x2 *= BIGI;
                    ix2 += 1;
                }
                else if (y2 < BIGSI)
                {
                     x2 *= BIG;
                    ix2 -= 1;
                }

                 ps2[n] = x2;
                ips2[n] = ix2;
            }
            /* ............................................................. */
            /* ------------------------------------------------------------- */






            /* Loop over harmonic orders */
            /* ------------------------------------------------------------- */
            for (unsigned int m = 0; m <= nmax; m++)
            {
                

                /* Due to the use of the mean values, some additional terms 
                 * need to be taken into account when compared with the 
                 * harmonic analysis based on point values (see, e.g., Colombo, 
                 * 1981) */
                /* --------------------------------------------------------- */
                if (m == 0)
                {
                    amp1 = a[m] * dlon;

                    if (i < imax)
                    {
                        a2mp1 = a2[m] * dlon;
                    }
                }
                else
                {
                    /* Useful substitution */
                    cm = (cos((double)m * dlon) - 1.0) / (double)m;
                    sm = sin((double)m * dlon) / (double)m;

                    amp1 =  a[m] * sm + b[m] * cm;
                    bmp1 = -a[m] * cm + b[m] * sm;

                    if (i < imax)
                    {
                        a2mp1 =  a2[m] * sm + b2[m] * cm;
                        b2mp1 = -a2[m] * cm + b2[m] * sm;
                    }
                }
                /* --------------------------------------------------------- */

                
                /* Computation of "am" and "bm" coefficients for Legendre 
                 * recurrence relations */
                /* --------------------------------------------------------- */
                am[m] = r[2 * m + 3];
                for (unsigned int n = (m + 2); n <= nmax; n++)
                {
                    w         = r[2 * n + 1] * ri[n - m] * ri[n + m];
                    am[n - 1] = r[2 * n - 1] * w;
                    bm[n - 1] = r[n - m - 1] * r[n + m - 1] * ri[2 * n - 3] 
                                * w;
                }
                /* --------------------------------------------------------- */


                /* Computation of spherical harmonic coefficients */
                if (m == 0)
                {






                    /* Zonal Legendre functions and their integrals */
                    /* ----------------------------------------------------- */
                    /* P00 */
                    /* ..................................................... */
                    pnm0_lat1i = 1.0;
                    pnm0_lat2i = 1.0;
                    /* ..................................................... */


                    /* P10 */
                    /* ..................................................... */
                    pnm1_lat1i = t1;
                    pnm1_lat2i = t2;
                    /* ..................................................... */


                    /* I00 */
                    /* ..................................................... */
                    in0 = t2 - t1;
                    /* ..................................................... */


                    /* Spherical harmonic coefficients */
                    /* ..................................................... */
                    csatmp = in0 * amp1;
                    if (i < imax)
                    {
                        csatmp += in0 * a2mp1;
                    }
                    cnm_priv[0][0] += csatmp;
                    /* ..................................................... */


                    if ((nmax + 1) >= 2)
                    {
                        for (unsigned int n = 1; n <= nmax; n++)
                        {
                            /* P20, P30, ..., Pnmax+1,0
                             * Since we use locally the "n" variable to compute 
                             * Legendre polynomials of degree "n + 1", the "n + 
                             * 1"th elements have to be taken from the vectors 
                             * "en" and "fn" below. Once again, note that when 
                             * "m == 0", then "pnm0", "pnm1" and "pnm2" for 
                             * lat1i and lat2i represent un-normalized Legendre 
                             * polynomials. These are needed to get the 
                             * integrals of fully-normalized Legendre 
                             * polynomials */
                            /* ............................................. */
                            pnm2_lat1i = en[n + 1] * t1 * pnm1_lat1i
                                       - fn[n + 1] * pnm0_lat1i;
                            pnm2_lat2i = en[n + 1] * t2 * pnm1_lat2i
                                       - fn[n + 1] * pnm0_lat2i;
                            /* ............................................. */


                            /* I10, I20, ..., Inmax,0
                             * Computed from Pn+1,0 and Pn-1,0 */
                            /* ............................................. */
                            in0 = ri[2 * n + 1] * (pnm2_lat2i - pnm0_lat2i -
                                                   pnm2_lat1i + pnm0_lat1i);
                            /* ............................................. */


                            /* Spherical harmonic coefficients */
                            /* ............................................. */
                            csatmp = in0 * amp1;

                            if (i < imax)
                            {
                                if ((n % 2) == 0)
                                {
                                    csatmp += in0 * a2mp1;
                                }
                                else
                                {
                                    csatmp -= in0 * a2mp1;
                                }
                            }
                            cnm_priv[0][n] += csatmp; /* C10, C20, ...,
                                                       * Cnmax,0 */
                            /* ............................................. */


                            pnm0_lat1i = pnm1_lat1i;
                            pnm1_lat1i = pnm2_lat1i;


                            pnm0_lat2i = pnm1_lat2i;
                            pnm1_lat2i = pnm2_lat2i;

                        }
                    }
                    /* ----------------------------------------------------- */







                }
                else /* Non-zonal harmonics */
                {







                    /* Sectorial Legendre functions and their integrals */
                    /* ----------------------------------------------------- */

                    /* Pmm for lat1i */
                    /* ..................................................... */
                    x1  =  ps1[m - 1];
                    ix1 = ips1[m - 1];

                    if (ix1 == 0)
                    {
                        pnm0_lat1i = x1;
                    }
                    else if (ix1 < -1)
                    {
                        pnm0_lat1i = 0.0;
                    }
                    else if (ix1 < 0)
                    {
                        pnm0_lat1i = x1 * BIGI;
                    }
                    else
                    {
                        pnm0_lat1i = x1 * BIG;
                    }
                    /* ..................................................... */


                    /* Pmm for lat2i */
                    /* ..................................................... */
                    x2  =  ps2[m - 1];
                    ix2 = ips2[m - 1];

                    if (ix2 == 0)
                    {
                        pnm0_lat2i = x2;
                    }
                    else if (ix2 < -1)
                    {
                        pnm0_lat2i = 0.0;
                    }
                    else if (ix2 < 0)
                    {
                        pnm0_lat2i = x2 * BIGI;
                    }
                    else
                    {
                        pnm0_lat2i = x2 * BIG;
                    }
                    /* ..................................................... */


                    /* Imm */
                    /* ..................................................... */
                    if (m == 1) /* I11 */
                    {
                        imm0 = sqrt(3.0) / 2.0 *
                              ((t2 * u2 - (M_PI_2 - lat2i)) -
                               (t1 * u1 - (M_PI_2 - lat1i)));
                        inm0 = imm0;
                    }
                    else if (m == 2) /* I22 */
                    {
                        imm1 = sqrt(15.0) / 6.0 * (t2 * (3.0 - t2 * t2) -
                                                     t1 * (3.0 - t1 * t1));
                        inm0 = imm1;
                    }
                    else /* I33, I44, ..., Inmax,nmax */
                    {
                        imm2 = gn[m] * imm0 + 1.0 / (double)(m + 1) *
                               (t2 * pnm0_lat2i - t1 * pnm0_lat1i);
                        inm0 = imm2;

                        imm0 = imm1;
                        imm1 = imm2;
                    }
                    /* ..................................................... */


                    /* Spherical harmonic coefficients */
                    /* ..................................................... */
                    csatmp = inm0 * amp1;
                    csbtmp = inm0 * bmp1;

                    if (i < imax)
                    {
                        csatmp += inm0 * a2mp1;
                        csbtmp += inm0 * b2mp1;
                    }
                    cnm_priv[m][0] += csatmp;
                    snm_priv[m][0] += csbtmp;
                    /* ..................................................... */
                    /* ----------------------------------------------------- */






                    /* Tesseral harmonics */
                    /* ----------------------------------------------------- */
                    if (m < nmax)
                    {

                        /* Pm+1,m for lat1i */
                        /* ................................................. */
                         y1 =  x1;
                        iy1 = ix1;
                         x1 = (am[m] * t1) * y1;
                        ix1 = iy1;

                        w = fabs(x1);
                        if (w >= BIGS)
                        {
                             x1 *= BIGI;
                            ix1 += 1;
                        }
                        else if (w < BIGSI)
                        {
                             x1 *= BIG;
                            ix1 -= 1;
                        }

                        /* Pm+1,m */
                        if (ix1 == 0)
                        {
                            pnm1_lat1i = x1;
                        }
                        else if (ix1 < -1)
                        {
                            pnm1_lat1i = 0.0;
                        }
                        else if (ix1 < 0)
                        {
                            pnm1_lat1i = x1 * BIGI;
                        }
                        else
                        {
                            pnm1_lat1i = x1 * BIG;
                        }
                        /* ................................................. */


                        /* Pm+1,m for lat2i */
                        /* ................................................. */
                         y2 =  x2;
                        iy2 = ix2;
                         x2 = (am[m] * t2) * y2;
                        ix2 = iy2;

                        w = fabs(x2);
                        if (w >= BIGS)
                        {
                             x2 *= BIGI;
                            ix2 += 1;
                        }
                        else if (w < BIGSI)
                        {
                             x2 *= BIG;
                            ix2 -= 1;
                        }

                        /* Pm+1,m */
                        if (ix2 == 0)
                        {
                            pnm1_lat2i = x2;
                        }
                        else if (ix2 < -1)
                        {
                            pnm1_lat2i = 0.0;
                        }
                        else if (ix2 < 0)
                        {
                            pnm1_lat2i = x2 * BIGI;
                        }
                        else
                        {
                            pnm1_lat2i = x2 * BIG;
                        }
                        /* ................................................. */


                        /* Im+1,m */
                        /* ................................................. */
                        /* This is not a typo, "pnm0" are indeed required here 
                         * */
                        inm1 = -am[m] / (double)(m + 2) *
                                (u2 * u2 * pnm0_lat2i - u1 * u1 * pnm0_lat1i);
                        /* ................................................. */


                        /* Spherical harmonic coefficients */
                        /* ................................................. */
                        csatmp = inm1 * amp1;
                        csbtmp = inm1 * bmp1;

                        if (i < imax)
                        {
                            csatmp -= inm1 * a2mp1;
                            csbtmp -= inm1 * b2mp1;
                        }
                        cnm_priv[m][1] += csatmp;
                        snm_priv[m][1] += csbtmp;
                        /* ................................................. */


                        /* Pm+2,m, Pm+3,m, ..., Pnmax,m and their integrals */
                        /* ................................................. */
                        for (unsigned int n = (m + 2); n <= nmax; n++)
                        {
                            
                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m for lat1i */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            ixy1 = ix1 - iy1;

                            if (ixy1 == 0)
                            {
                                 z1 = (am[n - 1] * t1) * x1 - bm[n - 1] * y1;
                                iz1 = ix1;
                            }
                            else if (ixy1 == 1)
                            {
                                 z1 = (am[n - 1] * t1) * x1 - bm[n - 1] 
                                                            * (y1 * BIGI);
                                iz1 = ix1;
                            }
                            else if (ixy1 == -1)
                            {
                                 z1 = (am[n - 1] * t1) * (x1 * BIGI) \
                                     - bm[n - 1] * y1;
                                iz1 = iy1;
                            }
                            else if (ixy1 > 1)
                            {
                                 z1 = (am[n - 1] * t1) * x1;
                                iz1 = ix1;
                            }
                            else
                            {
                                 z1 = -bm[n - 1] * y1;
                                iz1 = iy1;
                            }

                            w = fabs(z1);
                            if (w >= BIGS)
                            {
                                 z1 *= BIGI;
                                iz1 += 1;
                            }
                            else if (w < BIGSI)
                            {
                                 z1 *= BIG;
                                iz1 -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz1 == 0)
                            {
                                pnm2_lat1i = z1;
                            }
                            else if (iz1 < -1)
                            {
                                pnm2_lat1i = 0.0;
                            }
                            else if (iz1 < 0)
                            {
                                pnm2_lat1i = z1 * BIGI;
                            }
                            else
                            {
                                pnm2_lat1i = z1 * BIG;
                            }

                             y1 =  x1;
                            iy1 = ix1;
                             x1 =  z1;
                            ix1 = iz1;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m for lat2i */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            ixy2 = ix2 - iy2;

                            if (ixy2 == 0)
                            {
                                 z2 = (am[n - 1] * t2) * x2 - bm[n - 1] * y2;
                                iz2 = ix2;
                            }
                            else if (ixy2 == 1)
                            {
                                 z2 = (am[n - 1] * t2) * x2 - bm[n - 1] 
                                                            * (y2 * BIGI);
                                iz2 = ix2;
                            }
                            else if (ixy2 == -1)
                            {
                                 z2 = (am[n - 1] * t2) * (x2 * BIGI) \
                                     - bm[n - 1] * y2;
                                iz2 = iy2;
                            }
                            else if (ixy2 > 1)
                            {
                                 z2 = (am[n - 1] * t2) * x2;
                                iz2 = ix2;
                            }
                            else
                            {
                                 z2 = -bm[n - 1] * y2;
                                iz2 = iy2;
                            }

                            w = fabs(z2);
                            if (w >= BIGS)
                            {
                                 z2 *= BIGI;
                                iz2 += 1;
                            }
                            else if (w < BIGSI)
                            {
                                 z2 *= BIG;
                                iz2 -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz2 == 0)
                            {
                                pnm2_lat2i = z2;
                            }
                            else if (iz2 < -1)
                            {
                                pnm2_lat2i = 0.0;
                            }
                            else if (iz2 < 0)
                            {
                                pnm2_lat2i = z2 * BIGI;
                            }
                            else
                            {
                                pnm2_lat2i = z2 * BIG;
                            }

                             y2 =  x2;
                            iy2 = ix2;
                             x2 =  z2;
                            ix2 = iz2;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Im+2,m, Im+3,m, ..., Inmax,m */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            /* This is not a typo, "pnm1" are indeed required 
                             * here */
                            inm2 = hn[n] * bm[n - 1] * inm0 -
                                   am[n - 1] / (double)(n + 1) *
                                   (u2 * u2 * pnm1_lat2i - 
                                    u1 * u1 * pnm1_lat1i);

                            inm0 = inm1;
                            inm1 = inm2;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Spherical harmonic coefficients */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            csatmp = inm2 * amp1;
                            csbtmp = inm2 * bmp1;

                            if (i < imax)
                            {
                                if (((n + m) % 2) == 0)
                                {
                                    csatmp += inm2 * a2mp1;
                                    csbtmp += inm2 * b2mp1;
                                }
                                else
                                {
                                    csatmp -= inm2 * a2mp1;
                                    csbtmp -= inm2 * b2mp1;
                                }
                            }

                            cnm_priv[m][n - m] += csatmp; /* Cm+2,m, Cm+3,m,
                                                           * ..., Cnmax,m */
                            snm_priv[m][n - m] += csbtmp; /* Sm+2,m, Sm+3,m,
                                                           * ..., Snmax,m */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            pnm1_lat1i = pnm2_lat1i;
                            pnm1_lat2i = pnm2_lat2i;

                        } /* End of the loop over harmonic degrees */
                        /* ------------------------------------------------- */


                    } /* End of computation of tesseral harmonics */
                    /* ----------------------------------------------------- */


                } /* End of computation of spherical harmonic coefficients */
                /* --------------------------------------------------------- */


            } /* End of the loop over harmonic orders */
            /* ------------------------------------------------------------- */


        } /* End of the loop over latitude parallels */
        /* ----------------------------------------------------------------- */


        fftw_free(ftmp_in); fftw_free(ftmp_out);
        free(ips1); free(ps1);
        free(ips2); free(ps2);
        free(am);   free(bm);
        free(a);    free(b);
        free(a2);   free(b2);


        /* Now let's add together the individual contributions to "cnm" and 
         * "snm" that are stored in each copy of "cnm_priv" and "snm_priv" in 
         * case of parallel computation via OpenMP */
        #pragma omp critical
        {
            for (unsigned int m = 0; m <= nmax; m++)
            {
                for (unsigned int n = m; n <= nmax; n++)
                {
                    cnm[m][n - m] += cnm_priv[m][n - m];
                    snm[m][n - m] += snm_priv[m][n - m];
                }
            }
        }


        sh_coeffs_free_dp(cnm_priv, snm_priv);
    } /* End of "#pragma omp parallel" */
    /* --------------------------------------------------------------------- */






    /* Freeing up the heap memory */
    /* --------------------------------------------------------------------- */
    free(r); free(ri); free(dn); free(en); free(fn); free(gn); free(hn);
    fftw_destroy_plan(plan);
    /* --------------------------------------------------------------------- */






    /* Multiplication of the "cnm" and "snm" arrays by the factor of "1 / (4 * 
     * pi)" */ 
    /* --------------------------------------------------------------------- */
    double c2 = 1.0 / (4.0 * M_PI);
    for (unsigned int m = 0; m <= nmax; m++)
    {
        for (unsigned int n = m; n <= nmax; n++)
        {
            cnm[m][n - m] *= c2;
            snm[m][n - m] *= c2;
        }
    }
    /* --------------------------------------------------------------------- */






    return;

}
