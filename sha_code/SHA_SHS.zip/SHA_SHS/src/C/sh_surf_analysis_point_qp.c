/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
#include <math.h>
#include <fftw3.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
void *arr_calloc(size_t, size_t);

void sh_coeffs_init_qp(__float128 ***, __float128 ***, unsigned int);
void sh_coeffs_free_qp(__float128 **, __float128 **);
/* ------------------------------------------------------------------------- */






void sh_surf_analysis_point_qp(__float128 *lat, size_t nlat, size_t nlon,
                               __float128 *w, __float128 *f, unsigned int nmax_signal,
                               unsigned int nmax_sha, __float128 **cnm,
                               __float128 **snm)
/*
 * ==========================================================================
 *
 * DESCRIPTION: This function computes spherical harmonic coefficients of a
 *              signal "f" via the exact FFT-based Gauss--Legendre quadrature
 *              (Sneeuw, 1994) up to degree "nmax_sha". The signal must be
 *              sampled at the nodes of the Gauss--Legendre quadrature (see the
 *              "gl_grd_qp.c" function) and possess harmonics up to degree
 *              "nmax_signal >= nmax_sha" (see below).
 *
 *              The function is written in quadruple precision.
 *
 *              Importantly, the function allows to compute spherical
 *              harmonic coefficients even for a smaller maximum degree than 
 *              that of the input signal, that is, for "nmax_sha <= 
 *              nmax_signal". In that case, however, the input signal must be 
 *              sampled correspondingly to its maximum harmonic degree 
 *              "nmax_signal", that is, at the grid obtained using the 
 *              "nmax_signal" value as the input to the "gl_grd_qp.c" 
 *              function. If this condition is met, the resulting coefficients 
 *              up to degree "nmax_sha" are computed exactly without any 
 *              approximation errors (neglecting numerical
 *              errors, etc.).
 *
 *              The loop over latitudes is parallelized using OpenMP.
 *
 *              The 4*pi fully-normalized associated Legendre functions
 *              (e.g., Heiskannen and Moritz, 1967) are evaluated by the
 *              numerically stable algorithm by Fukushima (2012). The algorithm
 *              can be used up to ultra-high harmonic degrees (say, tens of
 *              thousands or even well beyond).
 *
 *              As the main input, the signal to be analysed is represented
 *              by an array as one of the input variables (see the variable "f"
 *              below). Importantly, the whole array is stored in RAM during 
 *              the entire harmonic analysis. The same holds for the output 
 *              spherical harmonic coefficients. Ultra-high-degree analysis may 
 *              therefore require tens of GBs of RAM.
 *
 *              The function exploits the symmetry property of Legendre
 *              functions with respect to the equator, thereby improving its
 *              performance, especially for ultra-high-degree harmonic
 *              analysis. For further details on the symmetric grid, see
 *              "sh_surf_synthesis_point_qp.c". However, unlike 
 *              "sh_surf_synthesis_point_qp.c", this function always takes 
 *              advantage of the symmetry, as the Gauss--Legendre grid is 
 *              always symmetric and no other grid is currently supported in 
 *              this function.
 *
 *
 * INPUTS: "lat"         -- Pointer to an array of latitudes of the 
 *                          Gauss--Legendre grid in radians.
 *
 *                          A vector of the dimension (nmax_signal + 1), where
 *                          "nmax_signal" is the maximum degree present in the
 *                          signal (see above and the "gl_grd_qp.c"
 *                          function).
 *
 *         "nlat"        -- Number of latitudes in a single meridian
 *                          ("nlat = nmax_signal + 1").
 *
 *         "nlon"        -- Number of longitudes in a single latitude parallel
 *                          ("nlon = 2 * nmax_signal + 2").
 *
 *         "w"           -- Pointer to an array of weights due to the 
 *                          Gauss--Legendre quadrature.
 *
 *                          A vector of the dimension (nmax_signal + 1). See
 *                          above and the "gl_grd_qp.c" function.
 *
 *         "f"           -- Pointer to an array of the input signal i) given at 
 *                          the nodes of the Gauss--Legendre quadrature for 
 *                          "nmax_signal" and ii) containing harmonics up to 
 *                          degree "nmax_signal".
 *
 *                          Using the traditional row-major order of matrix 
 *                          elements in C, the array to which "f" points can be 
 *                          depicted as a matrix of the dimensions (nmax_signal 
 *                          + 1, 2 * nmax_signal + 2), sampled as follows:
 *
 *                 [(lat[0],lon[0])          ...         (lat[0],lon[nlon - 1]]
 *                 [      .                  .                  .             ]
 *                 [      .                   .                 .             ]
 *                 [      .                    .                .             ]
 *                 [(lat[nlat - 1],lon[0])   ...  (lat[nlat - 1],lon[nlon - 1]]
 *
 *                          where "lat" and "lon" are vectors generated by
 *                          the "gl_grd_qp.c" function.
 *
 *                          This means that, for instance, the value of "f" for 
 *                          "lat[i]" and "lon[j]" can be found as follows:
 *
 *                          "f[i * nlon + j]"
 *
 *                          See above and also the 
 *                          "sh_surf_synthesis_point_qp.c" function.
 *
 *         "nmax_signal" -- Maximum harmonic degree present in the signal
 *                          (here, the variable "f" above).
 *
 *         "nmax_sha"    -- Maximum harmonic degree of the output spherical
 *                          harmonic coefficients. This value cannot be larger
 *                          than "nmax_signal". Note that if
 *                          "nmax_sha < nmax_signal", the output coefficients
 *                          are still computed exactly, because the matrix
 *                          "f" is sampled correctly according to the
 *                          maximum degree that is present in the signal, here
 *                          "nmax_signal".
 *
 *
 * OUTPUTS: "cnm"       -- Double pointer to a 2D array with the output "Cnm" 
 *                         spherical harmonic coefficients. The first dimension 
 *                         is related to harmonic orders and the second one to 
 *                         harmonic degrees. Importantly, the number of columns 
 *                         varies for each row as follows:
 *
 *
 *                         Order 0: "cnm[0]" has "nmax + 1" columns for degrees 
 *                         "0, 1, ..., nmax" (respectively),
 *
 *                         Order 1: "cnm[1]" has "nmax" columns for degrees "1, 
 *                         2, ..., nmax" (respectively),
 *
 *                         Order 2: "cnm[2]" has "nmax - 1" columns for degrees 
 *                         "2, 3, ..., nmax" (respectively),
 *
 *                         .
 *                         .
 *                         .
 *
 *                         Order "nmax": "cnm[nmax]" has "1" column for degree 
 *                         "nmax".
 *
 *
 *                         This means that "cnm" is *not* a 2D rectangular 
 *                         array. It should be allocated by 
 *                         "sh_coeffs_init_qp.c" and deallocated by 
 *                         "sh_coeffs_free_qp.c".
 *
 *                         The harmonic coefficient "Cnm" of degree "n" and 
 *                         order "m" can therefore be accessed as follows:
 *
 *                         cnm[m][n - m]
 *
 *         "snm"       -- The same as "cnm" above, but with the "Snm" 
 *                        coefficients.
 *
 *
 * REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
 *                least-squares and numerical quadrature methods in historical
 *                perspective. Geophysical Journal International 118:707--716
 *
 *             Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
 *                Freeman and Company, San Francisco, 364 pp
 *
 *             Fukushima, T. (2012) Numerical computation of spherical
 *                harmonics of arbitrary degree and order by extending exponent
 *                of floating point numbers. Journal of Geodesy 86:271--285.
 *
 *
 * Contact: blazej.bucha@stuba.sk
 *
 *
 * Please use the following reference when using this function:
 *
 *          Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
 *             spectral gravity forward modelling up to the full gravity
 *             tensor. Journal of Geodesy 93:1707--1737
 *
 *
 * ========================================================================= */
{

    /* Some constants needed to compute Legendre functions */
    /* --------------------------------------------------------------------- */
    const int IND = 16000;
    const __float128 BIG = powq(2.0q, IND);
    const __float128 BIGI = powq(2.0q, -IND);
    const __float128 BIGS = powq(2.0q, IND / 2.0q);
    const __float128 BIGSI = powq(2.0q, -IND / 2.0q);
    const __float128 ROOT3 = 1.7320508075688772935274463415058723669428q;
    /* --------------------------------------------------------------------- */






    /* Check whether the number of latitudes is even or odd */
    /* --------------------------------------------------------------------- */
    int even;
    size_t nlatdo;
    if ((nlat % 2) == 0)
    {
        even = 1; /* The number of latitudes is an even number. The grid does
                   * not contain the zero latitude */
        nlatdo = nlat / 2;
    }
    else
    {
        even = 0; /* The number of latitudes is an odd number. The grid could
                   * possibly contain the zero latitude */
        nlatdo = (nlat + 1) / 2;
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute Legendre functions 
     * */
    /* --------------------------------------------------------------------- */
    __float128 wlf;
    __float128 *r = (__float128 *)arr_calloc(2 * nmax_sha + 4, sizeof(__float128));
    __float128 *ri = (__float128 *)arr_calloc(2 * nmax_sha + 4, sizeof(__float128));

    r[0]  = 0.0q;
    ri[0] = 0.0q;
    for (unsigned int m = 1; m <= (2 * nmax_sha + 3); m++)
    {
        wlf = sqrtq((__float128)m);
        r[m] = wlf;
        ri[m] = 1.0q / wlf;
    }


    /* Computation of the "dn" coefficients for Legendre recurrence relations 
     * */
    __float128 *dn = (__float128 *)arr_calloc(nmax_sha + 1, sizeof(__float128));

    dn[0] = 0.0q;
    for (unsigned int n = 1; n <= nmax_sha; n++)
    {
        dn[n] = r[2 * n + 3] * ri[2 * n + 2];
    }


    /* Computation of the "en" and "fn" coefficients for Legendre recurrence 
     * relations */
    __float128 *en = (__float128 *)arr_calloc(nmax_sha + 1, sizeof(__float128));
    __float128 *fn = (__float128 *)arr_calloc(nmax_sha + 1, sizeof(__float128));

    en[0] = 0.0q; en[1] = 0.0q;
    fn[0] = 0.0q; fn[1] = 0.0q;
    for (unsigned int n = 2; n <= nmax_sha; n++)
    {
        en[n] = r[2 * n + 1] * r[2 * n - 1] / (__float128)n;
        fn[n] = (__float128)(n - 1) * r[2 * n + 1] / ((__float128)n * r[2 * n - 3]); 
    }
    /* --------------------------------------------------------------------- */






    /* Auxiliary variable entering the computation of the lumped coefficients 
     * */
    /* --------------------------------------------------------------------- */
    __float128 c = M_PIq * 2.0q / (__float128)(2 * (nmax_signal + 1));
    /* --------------------------------------------------------------------- */






    /* Initialize all elements of the output coefficients to zero */
    /* --------------------------------------------------------------------- */
    for (unsigned int n = 0; n <= nmax_sha; n++)
    {
        for (unsigned int m = 0; m <= n; m++)
        {
            cnm[m][n - m] = 0.0q;
            snm[m][n - m] = 0.0q;
        }
    }
    /* --------------------------------------------------------------------- */






    /* Create a plan for FFT */
    /* --------------------------------------------------------------------- */
    __float128 *ftmp_in        = (__float128 *)fftwq_malloc(nlon * sizeof(__float128));
    fftwq_complex *ftmp_out = (fftwq_complex *)fftwq_malloc(sizeof(fftwq_complex) 
                                                         * (nlon / 2 + 1));

    fftwq_plan plan = fftwq_plan_dft_r2c_1d(nlon, ftmp_in, ftmp_out,
                                          FFTW_ESTIMATE);

    fftwq_free(ftmp_in); fftwq_free(ftmp_out);
    /* --------------------------------------------------------------------- */






    /* Loop over latitudes */
    /* --------------------------------------------------------------------- */
    size_t imax = nlatdo + even - 1;

    #pragma omp parallel default(none) \
    shared(cnm, snm, f, lat, nlat, nlon, w, nlatdo, imax, c, nmax_sha) \
    shared(dn, en, fn, r, ri, plan) private(wlf)
    {

        /* Initialization of the private copies of "cnm" and "snm" arrays that 
         * will store the individuals contributions computed by each CPU in 
         * case of parallel computation via OpenMP.
         * 
         * If parallel computation is not employed, "cnm_priv" and "snm_priv" 
         * are rather useless and increase RAM requirements. To fix this, one 
         * can 1) remove the declarations of "cnm_priv" and "snm_priv" that 
         * follow right after this comment, 2) delete the code block related to 
         * "#pragma omp critical" (see below), 3) delete the "free" commands 
         * related to "cnm_priv" and "snm_priv", and 4) rename all the 
         * remaining occurrences of "cnm_priv" and "snm_priv" by "cnm" and 
         * "snm", respectively. This, however, is possible only in case of 
         * serial computation without OpenMP. */
        /* ................................................................. */
        __float128 **cnm_priv, **snm_priv;
        sh_coeffs_init_qp(&cnm_priv, &snm_priv, nmax_sha);
        /* ................................................................. */


        __float128 *ftmp_in        = (__float128 *)fftwq_malloc(nlon * sizeof(__float128));
        fftwq_complex *ftmp_out = (fftwq_complex *)fftwq_malloc(
                                 sizeof(fftwq_complex) * (nlon / 2 + 1));

        __float128 pnm0, pnm1, pnm2;
        int ix, iy, iz, ixy;
        int   *ips = (int *)arr_calloc(nmax_sha + 1, sizeof(int));
        __float128 *ps = (__float128 *)arr_calloc(nmax_sha, sizeof(__float128));
        __float128 *am = (__float128 *)arr_calloc(nmax_sha + 1, sizeof(__float128));
        __float128 *bm = (__float128 *)arr_calloc(nmax_sha, sizeof(__float128));
        __float128 t, u, x, y, z;

        __float128 *a  = (__float128 *)arr_calloc(nlon / 2 + 1, sizeof(__float128));
        __float128 *b  = (__float128 *)arr_calloc(nlon / 2 + 1, sizeof(__float128));
        __float128 *a2 = (__float128 *)arr_calloc(nlon / 2 + 1, sizeof(__float128));
        __float128 *b2 = (__float128 *)arr_calloc(nlon / 2 + 1, sizeof(__float128));
        __float128 alcm, a2lcm, blcm, b2lcm;

        __float128 cw, csatmp, csbtmp;

        wlf = 0.0q;



        #pragma omp for
        for (size_t i = 0; i < nlatdo; i++)
        {

            /* Lumped coefficients for the southern hemisphere (including the 
             * equator) */
            /* ------------------------------------------------------------- */
            for (size_t j = 0; j < nlon; j++)
            {
                ftmp_in[j] = f[i * nlon + j];
            }
            fftwq_execute_dft_r2c(plan, ftmp_in, ftmp_out);

            cw = c * w[i];
            for (size_t j = 0; j < (nlon / 2 + 1); j++)
            {
                a[j]  =  cw * ftmp_out[j][0]; 
                b[j]  = -cw * ftmp_out[j][1]; 
            }
            /* ------------------------------------------------------------- */


            /* Lumped coefficients for the northern hemisphere */
            /* ------------------------------------------------------------- */
            if (i < imax)
            {
                for (size_t j = 0; j < nlon; j++)
                {
                    ftmp_in[j] = f[(nlat - i - 1) * nlon + j];
                }
                fftwq_execute_dft_r2c(plan, ftmp_in, ftmp_out);

                cw = c * w[nlat - i - 1];
                for (size_t j = 0; j < (nlon / 2 + 1); j++)
                {
                    a2[j]  =  cw * ftmp_out[j][0]; 
                    b2[j]  = -cw * ftmp_out[j][1]; 
                }
            }
            /* ------------------------------------------------------------- */


            /* Some pre-computations for Legendre functions */
            /* ------------------------------------------------------------- */
            t  = sinq(lat[i]);
            u  = cosq(lat[i]);
            x  = ROOT3 * u;
            ix = 0;

             ps[0] = x;
            ips[0] = ix;


            for (unsigned n = 1; n < nmax_sha; n++)
            {
                x = (dn[n] * u) * x;
                y = fabsq(x);

                if (y >= BIGS)
                {
                     x *= BIGI;
                    ix += 1;
                }
                else if (y < BIGSI)
                {
                     x *= BIG;
                    ix -= 1;
                }

                 ps[n] = x;
                ips[n] = ix;
            }
            /* ------------------------------------------------------------- */






            /* Loop over harmonic orders */
            /* ------------------------------------------------------------- */
            for (unsigned int m = 0; m <= nmax_sha; m++)
            {
                
                /* Computation of "am" and "bm" coefficients for Legendre 
                 * recurrence relations */
                /* --------------------------------------------------------- */
                am[m] = r[2 * m + 3];
                for (unsigned int n = (m + 2); n <= nmax_sha; n++)
                {
                    wlf       = r[2 * n + 1] * ri[n - m] * ri[n + m];
                    am[n - 1] = r[2 * n - 1] * wlf;
                    bm[n - 1] = r[n - m - 1] * r[n + m - 1] * ri[2 * n - 3] 
                                * wlf;
                }
                /* --------------------------------------------------------- */


                /* Some useful substitutions */
                /* --------------------------------------------------------- */
                alcm  =  a[m];
                a2lcm = a2[m];
                blcm  =  b[m];
                b2lcm = b2[m];
                /* --------------------------------------------------------- */


                /* Computation of spherical harmonic coefficients */
                if (m == 0)
                {
                    /* Zonal harmonics */
                    /* ----------------------------------------------------- */

                    /* P00 */
                    pnm0 = 1.0q;
                    csatmp = pnm0 * alcm;

                    if (i < imax)
                    {
                        csatmp += pnm0 * a2lcm;
                    }
                    cnm_priv[0][0] += csatmp; /* C00 */


                    /* P10 */
                    if (nmax_sha >= 1)
                    {
                        pnm1   = ROOT3 * t;
                        csatmp = pnm1 * alcm;

                        if (i < imax)
                        {
                            csatmp -= pnm1 * a2lcm;
                        }
                        cnm_priv[0][1] += csatmp; /* C10 */

                    }


                    /* P20, P30, ..., Pnmax,0 */
                    if (nmax_sha >= 2)
                    {
                        for (unsigned int n = 2; n <= nmax_sha; n++)
                        {
                            pnm2   = en[n] * t * pnm1 - fn[n] * pnm0;
                            csatmp = pnm2 * alcm;

                            if (i < imax)
                            {
                                if ((n % 2) == 0)
                                {
                                    csatmp += pnm2 * a2lcm;
                                }
                                else
                                {
                                    csatmp -= pnm2 * a2lcm;
                                }

                            }
                            cnm_priv[0][n] += csatmp; /* C20, C30, ...,
                                                       * Cnmax,0 */

                            pnm0 = pnm1;
                            pnm1 = pnm2;
                        }
                    }
                    /* ----------------------------------------------------- */
                }
                else /* Non-zonal harmonics */
                {

                    /* Sectorial harmonics */
                    /* ----------------------------------------------------- */
                     x =  ps[m - 1];
                    ix = ips[m - 1];

                    /* Pmm */
                    if (ix == 0)
                    {
                        pnm0 = x;
                    }
                    else if (ix < -1)
                    {
                        pnm0 = 0.0q;
                    }
                    else if (ix < 0)
                    {
                        pnm0 = x * BIGI;
                    }
                    else
                    {
                        pnm0 = x * BIG;
                    }

                    csatmp = pnm0 * alcm;
                    csbtmp = pnm0 * blcm;

                    if (i < imax)
                    {
                        csatmp += pnm0 * a2lcm;
                        csbtmp += pnm0 * b2lcm;
                    }

                    cnm_priv[m][0] += csatmp; /* Cmm */
                    snm_priv[m][0] += csbtmp; /* Smm */
                    /* ----------------------------------------------------- */


                    /* Tesseral harmonics */
                    /* ----------------------------------------------------- */
                    if (m < nmax_sha)
                    {
                         y =  x;
                        iy = ix;
                         x = (am[m] * t) * y;
                        ix = iy;

                        wlf = fabsq(x);
                        if (wlf >= BIGS)
                        {
                             x *= BIGI;
                            ix += 1;
                        }
                        else if (wlf < BIGSI)
                        {
                             x *= BIG;
                            ix -= 1;
                        }

                        /* Pm+1,m */
                        if (ix == 0)
                        {
                            pnm1 = x;
                        }
                        else if (ix < -1)
                        {
                            pnm1 = 0.0q;
                        }
                        else if (ix < 0)
                        {
                            pnm1 = x * BIGI;
                        }
                        else
                        {
                            pnm1 = x * BIG;
                        }

                        csatmp = pnm1 * alcm;
                        csbtmp = pnm1 * blcm;

                        if (i < imax)
                        {
                            csatmp -= pnm1 * a2lcm;
                            csbtmp -= pnm1 * b2lcm;
                        }

                        cnm_priv[m][1] += csatmp; /* Cm+1,m */
                        snm_priv[m][1] += csbtmp; /* Sm+1,m */


                        /* Loop over degrees */
                        /* ------------------------------------------------- */
                        for (unsigned int n = (m + 2); n <= nmax_sha; n++)
                        {
                            ixy = ix - iy;

                            if (ixy == 0)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] * y;
                                iz = ix;
                            }
                            else if (ixy == 1)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] 
                                                           * (y * BIGI);
                                iz = ix;
                            }
                            else if (ixy == -1)
                            {
                                 z = (am[n - 1] * t) * (x * BIGI) \
                                     - bm[n - 1] * y;
                                iz = iy;
                            }
                            else if (ixy > 1)
                            {
                                 z = (am[n - 1] * t) * x;
                                iz = ix;
                            }
                            else
                            {
                                 z = -bm[n - 1] * y;
                                iz = iy;
                            }

                            wlf = fabsq(z);
                            if (wlf >= BIGS)
                            {
                                 z *= BIGI;
                                iz += 1;
                            }
                            else if (wlf < BIGSI)
                            {
                                 z *= BIG;
                                iz -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz == 0)
                            {
                                pnm2 = z;
                            }
                            else if (iz < -1)
                            {
                                pnm2 = 0.0q;
                            }
                            else if (iz < 0)
                            {
                                pnm2 = z * BIGI;
                            }
                            else
                            {
                                pnm2 = z * BIG;
                            }

                            csatmp = pnm2 * alcm;
                            csbtmp = pnm2 * blcm;

                            if (i < imax)
                            {
                                if (((n + m) % 2) == 0)
                                {
                                    csatmp += pnm2 * a2lcm;
                                    csbtmp += pnm2 * b2lcm;
                                }
                                else
                                {
                                    csatmp -= pnm2 * a2lcm;
                                    csbtmp -= pnm2 * b2lcm;
                                }
                            }

                            cnm_priv[m][n - m] += csatmp; /* Cm+2,m, Cm+3,m,
                                                           * ..., Cnmax,m */
                            snm_priv[m][n - m] += csbtmp; /* Sm+2,m, Sm+3,m,
                                                           * ..., Snmax,m */

                             y =  x;
                            iy = ix;
                             x =  z;
                            ix = iz;

                        } /* End of the loop over harmonic degrees */
                        /* ------------------------------------------------- */


                    } /* End of computation of tesseral harmonics */
                    /* ----------------------------------------------------- */


                } /* End of computation of spherical harmonic coefficients */
                /* --------------------------------------------------------- */


            } /* End of the loop over harmonic orders */
            /* ------------------------------------------------------------- */


        } /* End of the loop over latitude parallels */
        /* ----------------------------------------------------------------- */


        fftwq_free(ftmp_in); fftwq_free(ftmp_out);
        free(ips); free(ps); free(am); free(bm); free(a); free(b);
        free(a2); free(b2);


        /* Now let's add together the individual contributions to "cnm" and 
         * "snm" that are stored in each copy of "cnm_priv" and "snm_priv" in 
         * case of parallel computation via OpenMP */
        #pragma omp critical
        {
            for (unsigned int m = 0; m <= nmax_sha; m++)
            {
                for (unsigned int n = m; n <= nmax_sha; n++)
                {
                    cnm[m][n - m] += cnm_priv[m][n - m];
                    snm[m][n - m] += snm_priv[m][n - m];
                }
            }
        }


        sh_coeffs_free_qp(cnm_priv, snm_priv);

    } /* End of "#pragma omp parallel" */
    /* --------------------------------------------------------------------- */






    /* Freeing up the heap memory */
    /* --------------------------------------------------------------------- */
    free(r); free(ri); free(dn); free(en); free(fn);
    fftwq_destroy_plan(plan);
    /* --------------------------------------------------------------------- */






    /* Multiplication of the "cnm" and "snm" arrays by the factor of "1 / (4 * 
     * pi)" */ 
    /* --------------------------------------------------------------------- */
    __float128 c2 = 1.0q / (4.0q * M_PIq);
    for (unsigned int m = 0; m <= nmax_sha; m++)
    {
        for (unsigned int n = m; n <= nmax_sha; n++)
        {
            cnm[m][n - m] *= c2;
            snm[m][n - m] *= c2;
        }
    }
    /* --------------------------------------------------------------------- */






    return;

}
