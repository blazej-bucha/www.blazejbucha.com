/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
__float128 arr_min_qp(__float128 *, size_t);
void *arr_calloc(size_t, size_t);
/* ------------------------------------------------------------------------- */






void sh_surf_synthesis_point_qp(__float128 *lat, size_t nlat, __float128 *lon,
                                size_t nlon, unsigned int nmax, __float128 **cnm,
                                __float128 **snm, __float128 *f)
/*
 * ============================================================================
 *
 * DESCRIPTION: This function performs surface spherical harmonic synthesis
 *              at a grid defined by the vectors of latitudes and longitudes
 *              via a FFT-based algorithm (Sneeuw, 1994).
 *
 *              The function is written in quadruple precision.
 *
 *              The loop over latitudes is parallelized using OpenMP.
 *
 *              The function automatically starts the synthesis from degree
 *              "nmin = 0". If you wish to use some other value of "nmin"
 *              (but satisfying "1 <= nmin <= nmax"), you can set (outside this
 *              function) the respective coefficients of the "cnm" and "snm" 
 *              arrays to zero and use the new matrices as the input to this 
 *              function. In that case, the synthesis still starts at degree 0, 
 *              but since the coefficients up to degree "nmin - 1" are zero, 
 *              they do not contribute to the output signal as required.
 *
 *              The 4*pi fully-normalized associated Legendre functions
 *              (e.g., Heiskannen and Moritz, 1967) are evaluated by the
 *              numerically stable algorithm by Fukushima (2012). The algorithm
 *              can be used up to ultra-high harmonic degrees (say, tens of
 *              thousands or even well beyond).
 *
 *              The function exploits the symmetry property of Legendre
 *              functions with respect to the equator, thereby improving its
 *              performance, especially for ultra-high-degree harmonic 
 *              synthesis. This computational acceleration is employed 
 *              automatically, provided that the grid is recognized as 
 *              symmetric with respect to the equator. Below, we provide some 
 *              examples of symmetric and non-symmetric grids. Note that while 
 *              these examples use the unit degrees for a more intuitive 
 *              understanding, the function requires radians as the input unit.
 *
 *              Examples of some symmetric grids (shown are only the
 *              latitudes):
 *              // Equator included
 *              lat = {-90, -60, -30, 0, 30, 60, 90};
 *              
 *              // Equator included
 *              lat = {-80, -60, -40, -20, 0, 20, 40, 60, 80};
 *
 *              // Equator excluded
 *              lat = {-35, -25, -15, -5, 5, 15, 25, 35};
 *              lat = {-90, -85, -80, 80, 85, 90};
 *
 *              // Varying spacing, equator excluded
 *              lat = {-90, -80, -75, -70, -69, 69, 70, 75, 80, 90};
 *
 *              Examples of some grids that are not considered as symmetric
 *              (shown are again only latitudes):
 *              lat = {-90, -60, -30, 0, 30, 60}; // The negative latitude of 
 *                                                // -90 deg does not have its 
 *                                                // positive
 *                                                // counterpart
 *              lat = {-35, -25, -15, -4.99q, 5, 15, 25, 35}; // The difference
 *                                                   // "abs(abs(-4.99q)-5)" is
 *                                                   // larger than the
 *                                                   // threshold
 *                                                   // "THRESHOLD" (see
 *                                                   // below).
 *
 *               In other words, the grid is symmetric, provided that all
 *               positive latitudes have their negative counterpart or vice 
 *               versa (up to a given threshold to suppress numerical 
 *               inaccuracies, see the "THRESHOLD" variable). The zero 
 *               latitude, i.e., the equator, may be included in the grid 
 *               (again, within specified numerical threshold "THRESHOLD").
 *
 *
 *               The longitudes of the grid must be sampled with equal spacing,
 *               that is, the difference between any two consecutive longitudes
 *               must be constant. The function performs a check on this.
 *               If the longitudes does not pass the test, a message is printed
 *               and the execution is stopped. If you know for sure that
 *               your longitudes share an equal spacing, but never pass
 *               the test, you may want to use a larger value of the 
 *               "THRESHOLD" variable (see below). This might happen due to the 
 *               rounding errors with a long vector of longitudes.
 *
 *
 *
 * INPUTS: "lat"       -- Pointer to an array defining latitudes of the grid in 
 *                        radians (latitudes over a single meridian).
 *
 *         "nlat"      -- Number of latitudes in the array to which "lat" 
 *                        points to.
 *
 *         "lon"       -- Pointer to an array defining longitudes of the grid 
 *                        in radians (longitudes over a single latitude
 *                        parallel).
 *
 *         "nlon"      -- Number of longitudes in the array to which "lon" 
 *                        points to.
 *
 *         "nmax"      -- Maximum spherical harmonic degree of the synthesis
 *
 *         "cnm"       -- Double pointer to a 2D array with the input "Cnm" 
 *                        spherical harmonic coefficients. The first dimension 
 *                        is related to harmonic orders and the second one to 
 *                        harmonic degrees. Importantly, the number of columns 
 *                        varies for each row as follows:
 *                        
 *                        
 *                        Order 0: "cnm[0]" has "nmax + 1" columns for degrees 
 *                        "0, 1, ..., nmax" (respectively),
 *
 *                        Order 1: "cnm[1]" has "nmax" columns for degrees "1, 
 *                        2, ..., nmax" (respectively),
 *
 *                        Order 2: "cnm[2]" has "nmax - 1" columns for degrees 
 *                        "2, 3, ..., nmax" (respectively),
 *
 *                        .
 *                        .
 *                        .
 *
 *                        Order "nmax": "cnm[nmax]" has "1" column for degree 
 *                        "nmax".
 *
 *
 *                        This means that "cnm" is *not* a 2D rectangular 
 *                        array. It should be allocated by 
 *                        "sh_coeffs_init_qp.c" and deallocated by 
 *                        "sh_coeffs_free_qp.c".
 *                        
 *                        The harmonic coefficient "Cnm" of degree "n" and 
 *                        order "m" can therefore be accessed as follows:
 *
 *                        cnm[m][n - m]
 *
 *         "snm"       -- The same as "cnm" above, but with the "Snm" 
 *                        coefficients.
 *
 *
 * OUTPUTS: "f" -- Pointer to an array of the synthesized signal (e.g., 
 *                 topographic heights) of dimensions (nlat * nlon).
 *
 *                 Using the traditional row-major order of matrix elements in 
 *                 C, the array to which "f" points can be depicted as a matrix 
 *                 of the dimensions (nlat, nlon), sampled as follows:
 *
 *                 [(lat[0],lon[0])          ...         (lat[0],lon[nlon - 1]]
 *                 [      .                  .                  .             ]
 *                 [      .                   .                 .             ]
 *                 [      .                    .                .             ]
 *                 [(lat[nlat - 1],lon[0])   ...  (lat[nlat - 1],lon[nlon - 1]]
 *
 *                 This means that, for instance, the value of "f" for "lat[i]" 
 *                 and "lon[j]" can be found as follows:
 *
 *                 "f[i * nlon + j]"
 *
 *
 * REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
 *                least-squares and numerical quadrature methods in historical
 *                perspective. Geophysical Journal International 118:707--716
 *
 *             Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
 *                Freeman and Company, San Francisco, 364 pp
 *
 *             Fukushima, T. (2012) Numerical computation of spherical
 *                harmonics of arbitrary degree and order by extending exponent
 *                of floating point numbers. Journal of Geodesy 86:271--285.
 *
 *             Balmino, Vales, Bonvalot, Briais, 2012. Spherical harmonic
 *                 modelling to ultra-high degree of Bouguer and isostatic
 *                 anomalies. Journal of Geodesy 86:499–520,
 *                 doi: 10.1007q/s00190-011-0533-4
 *
 *
 * Contact: blazej.bucha@stuba.sk
 *
 *
 * Please use the following reference when using this function:
 *
 *          Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
 *             spectral gravity forward modelling up to the full gravity
 *             tensor. Journal of Geodesy 93:1707--1737
 *
 *
 * ========================================================================= */
{

    /* Some useful constants */
    /* --------------------------------------------------------------------- */
    /* Threshold to judge whether two __float128 numbers are equal (can be changed 
     * as needed) */
    const __float128 THRESHOLD = 10000.0q * FLT128_EPSILON;


    /* Some constants to compute associated Legendre functions using the 
     * extended-range arithmetic approach */
    const int IND = 16000;
    const __float128 BIG = powq(2.0q, IND);
    const __float128 BIGI = powq(2.0q, -IND);
    const __float128 BIGS = powq(2.0q, IND / 2.0q);
    const __float128 BIGSI = powq(2.0q, -IND / 2.0q);
    const __float128 ROOT3 = 1.7320508075688772935274463415058723669428q;
    /* --------------------------------------------------------------------- */


   



    /* Check the latitudes of the computational grid */
    /* --------------------------------------------------------------------- */

    /* Check whether the number of latitudes is even or odd */
    /* ..................................................................... */
    int even; /* If the number of latitudes is even, then "even = 1", 
               * otherwise "even = 0" */
    if ((nlat % 2) == 0) 
    {
        even = 1;
    }
    else
    {
        even = 0;
    }
    /* ..................................................................... */






    /* Determine whether the latitudes are symmetric with respect to the
     * equator */
    /* ..................................................................... */
    int symm; /* If the grid is symmetric with respect to the equator, then
               * "symm = 1", otherwise "symm = 0". If "symm == 1", the function 
               * automatically exploits the symmetry property of Legendre 
               * functions in order to accelerate the computation */
    if (nlat == 1)
    {
        symm = 0; /* If there is only one latitude within the grid, the grid
                   * is automatically considered as not symmetric */
    }
    else
    {
        symm = 1; /* If there is more than one latitude in the grid, let's
                   * start by assuming that the grid is symmetric with respect 
                   * to the equator and check whether this is indeed true */

    }


    for (size_t i = 0; i < (nlat + even - 2) / 2; i++)
    {
        if (fabsq(lat[i] + lat[nlat - i - 1]) > THRESHOLD)
        {
            symm = 0; /* The grid is not symmetric */

            break; /* Exiting the loop with the final decision: the grid is not
                    * symmetric with respect to the equator ("symm = 0") */
        }
    }


    /* If the grid is symmetric, check whether the zero latitude is present 
     * right in the middle of the "lat" vector. If "even == 1", we already know 
     * that the grid does not contain the zero latitude */
    if ((symm == 1) && (even == 0))
    {
        if (fabsq(lat[nlat / 2]) > THRESHOLD) /* Note that "nlat / 2" is rounded 
                                              * to the nearest greatest integer 
                                              * as required */
        {
            symm = 0; /* The final decision: the grid is not symmetric with
                       * respect to the equator ("symm = 0") */
        }
    }


    /* Finally, if the grid is symmetric, we modify the number of latitudes 
     * "nlat" to be equal to the number of latitudes on one hemisphere only 
     * (including the equator if present). This is because the time-consuming     
     * "for loop" over evaluation points now needs to run for one hemisphere 
     * only, while the results for the other hemisphere are obtained by 
     * exploiting the symmetry property of Legendre functions. This reduces the 
     * number of Legendre functions that need to be evaluated by a factor of    
     * ~2, so saves some computational time */
    size_t nlatdo;
    if (symm == 1)
    {
        if (even == 1)
        {
            nlatdo = nlat / 2;
        }
        else
        {
            nlatdo = (nlat + 1) / 2;
        }
    }
    else
    {
        nlatdo = nlat;
    }
    /* ..................................................................... */
    /* --------------------------------------------------------------------- */
    





    /* Check the longitudes of the computational grid */
    /* --------------------------------------------------------------------- */
    /* Get the origin of the longitude "lon" vector (will be necessary later 
     * for the PSLR algorithm) */
    __float128 lon0 = lon[0];

    if (fabsq(lon0 - arr_min_qp(lon, nlon)) > THRESHOLD)
    {
        printf("\n[Surface_SHS says:] The first element of the longitude "
               "vector \"lon\" has to be the smallest one. Terminating "
               "the code.\n");
        exit(EXIT_FAILURE);
    }

    
    /* Get the lon step of the grid (will be necessary later for the PSLR 
     * algorithm) */
    __float128 dlon;
    if (nlon > 1)
    {
        dlon = lon[1] - lon[0];
    }
    else
    {
        dlon = 0.0q;
    }


    /* Check whether the longitude step is constant for the entire "lon" 
     * vector. Otherwise, the execution of the code is terminated. */
    __float128 dlonchck;
    for (size_t j = 1; j < nlon; j++)
    {
        dlonchck = lon[j] - lon[j - 1];

        if (fabsq(dlon - dlonchck) > THRESHOLD)
        {
            printf("\n[Surface_SHS says:] The longitudinal step of the grid "
                   "has to be constant. Terminating the code.\n");
            exit(EXIT_FAILURE);
        }
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute Legendre 
     * functions. */
    /* --------------------------------------------------------------------- */
    __float128 w;
    __float128 *r = (__float128 *)arr_calloc(2 * nmax + 4, sizeof(__float128));
    __float128 *ri = (__float128 *)arr_calloc(2 * nmax + 4, sizeof(__float128));

    r[0]  = 0.0q;
    ri[0] = 0.0q;
    for (unsigned int m = 1; m <= (2 * nmax + 3); m++)
    {
        w = sqrtq((__float128)m);
        r[m] = w;
        ri[m] = 1.0q / w;
    }


    /* Computation of the "dn" coefficients for Legendre recurrence relations 
     * */
    __float128 *dn = (__float128 *)arr_calloc(nmax + 1, sizeof(__float128));
    dn[0] = 0.0q;
    for (unsigned int n = 1; n <= nmax; n++)
    {
        dn[n] = r[2 * n + 3] * ri[2 * n + 2];
    }


    /* Computation of the "en" and "fn" coefficients for Legendre recurrence 
     * relations */
    __float128 *en = (__float128 *)arr_calloc(nmax + 1, sizeof(__float128));
    __float128 *fn = (__float128 *)arr_calloc(nmax + 1, sizeof(__float128));

    en[0] = 0.0q; en[1] = 0.0q;
    fn[0] = 0.0q; fn[1] = 0.0q;
    for (unsigned int n = 2; n <= nmax; n++)
    {
        en[n] = r[2 * n + 1] * r[2 * n - 1] / (__float128)n;
        fn[n] = (__float128)(n - 1) * r[2 * n + 1] / ((__float128)n * r[2 * n - 3]); 
    }
    /* --------------------------------------------------------------------- */






    /* Initialize the output signal matrix "f" with zeros */
    /* --------------------------------------------------------------------- */
    for (size_t i = 0; i < nlat; i++)
    {
        for (size_t j = 0; j < nlon; j++)
        {
            f[i * nlon + j] = 0.0q;
        }
    }
    /* --------------------------------------------------------------------- */






    /* Loop over grid latitudes */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel default(none) \
    shared(f, cnm, snm, nmax, lat, dn, en, fn, r, ri, nlat, nlon, nlatdo) \
    shared(lon0, dlon, even, symm, w)
    {

        int *ips = (int *)arr_calloc(nmax, sizeof(int));
        __float128 *ps = (__float128 *)arr_calloc(nmax, sizeof(__float128));
        __float128 *am = (__float128 *)arr_calloc(nmax + 1, sizeof(__float128));
        __float128 *bm = (__float128 *)arr_calloc(nmax, sizeof(__float128));
        __float128 *fi = (__float128 *)arr_calloc(nlon, sizeof(__float128));
        __float128 *fi2 = (__float128 *)arr_calloc(nlon, sizeof(__float128));

        __float128 pnm0, pnm1, pnm2;
        __float128 t, u, x, y, z;
        int ix, iy, iz, ixy;

        __float128 a, b, a2, b2;
        __float128 pnmcsa, pnmcsb;
        __float128 lontmp, clontmp, slontmp, dm0, dm1, dm2, dm02, dm12, dm22;
        __float128 cmdlon2;

        _Bool symmi;


        #pragma omp for
        for (size_t i = 0; i < nlatdo; i++)
        {

            /* Check whether the symmetry property of LFs needs to be exploited 
             * */
            /* ------------------------------------------------------------- */
            if (nlat == 1) /* There is only a single latitude parallel in the
                            * grid, so no symmetry property */
            {
                symmi = 0;
            }
            else if (symm == 0) /* The grid was already classified as
                                 * non-symmetric */
            {
                symmi = 0;
            }
            else if (symm == 1 && even == 0 && i == (nlatdo - 1))
            {
                symmi = 0; /* For a symmetric grid containing the equator, this
                            * ensures that the points on the equator will not 
                            * be processed twice */
            }
            else
            {
                symmi = 1; /* Exploit the symmetry property */
            }

            /* ------------------------------------------------------------- */


            /* Some pre-computations for Legendre functions */
            /* ------------------------------------------------------------- */
            t  = sinq(lat[i]);
            u  = cosq(lat[i]);
            x  = ROOT3 * u;
            ix = 0;

             ps[0] = x;
            ips[0] = ix;


            for (unsigned n = 1; n < nmax; n++)
            {
                x = (dn[n] * u) * x;
                y = fabsq(x);

                if (y >= BIGS)
                {
                     x *= BIGI;
                    ix += 1;
                }
                else if (y < BIGSI)
                {
                     x *= BIG;
                    ix -= 1;
                }

                 ps[n] = x;
                ips[n] = ix;
            }
            /* ------------------------------------------------------------- */


            /* The "fi" vector represents the synthesized quantity "f" for the 
             * ith latitude parallel. Therefore, it needs to be reinitialized 
             * to zero for each "ith" latitude. The same holds true for 
             * "fi2". */
            for (size_t j = 0; j < nlon; j++)
            {
                fi[j]  = 0.0q;
                fi2[j] = 0.0q;
            }


            /* Loop over harmonic orders */
            /* ------------------------------------------------------------- */
            for (unsigned int m = 0; m <= nmax; m++)
            {

                /* Computation of "am" and "bm" coefficients for Legendre 
                 * recurrence relations */
                /* --------------------------------------------------------- */
                am[m] = r[2 * m + 3];
                for (unsigned int n = (m + 2); n <= nmax; n++)
                {
                    w         = r[2 * n + 1] * ri[n - m] * ri[n + m];
                    am[n - 1] = r[2 * n - 1] * w;
                    bm[n - 1] = r[n - m - 1] * r[n + m - 1] * ri[2 * n - 3]
                                * w;
                }
                /* --------------------------------------------------------- */


                /* Computation of the lumped coefficients */
                if (m == 0)
                {
                    /* Zonal harmonics */
                    /* ----------------------------------------------------- */
                    /* P00 */
                    pnm0 = 1.0q;
                    a = pnm0 * cnm[0][0];
                    b = 0.0q;

                    if (symmi == 1)
                    {
                        a2 = a;
                        b2 = 0.0q;
                    }

                    /* P10 */
                    if (nmax >= 1)
                    {
                        pnm1   = ROOT3 * t;
                        pnmcsa = pnm1 * cnm[0][1];
                        a     += pnmcsa;

                        if (symmi == 1)
                        {
                            a2 -= pnmcsa;
                        }
                    }

                    /* P20, P30, ..., Pnmax,0 */
                    if (nmax >= 2)
                    {
                        for (unsigned int n = 2; n <= nmax; n++)
                        {
                            pnm2   = en[n] * t * pnm1 - fn[n] * pnm0;

                            pnmcsa = pnm2 * cnm[0][n];
                            a     += pnmcsa;

                            if (symmi == 1)
                            {
                                if ((n % 2) == 0)
                                {
                                    a2 += pnmcsa;
                                }
                                else
                                {
                                    a2 -= pnmcsa;
                                }
                            }

                            pnm0 = pnm1;
                            pnm1 = pnm2;
                        }
                    }
                    /* ----------------------------------------------------- */
                }
                else /* Non-zonal harmonics */
                {

                    /* Sectorial harmonics */
                    /* ----------------------------------------------------- */
                    x = ps[m - 1];
                    ix = ips[m - 1];

                    /* Pmm */
                    if (ix == 0)
                    {
                        pnm0 = x;
                    }
                    else if (ix < -1)
                    {
                        pnm0 = 0.0q;
                    }
                    else if (ix < 0)
                    {
                        pnm0 = x * BIGI;
                    }
                    else
                    {
                        pnm0 = x * BIG;
                    }

                    a = pnm0 * cnm[m][0];
                    b = pnm0 * snm[m][0];

                    if (symmi == 1)
                    {
                        a2 = a;
                        b2 = b;
                    }
                    /* ----------------------------------------------------- */


                    /* Tesseral harmonics */
                    /* ----------------------------------------------------- */
                    if (m < nmax)
                    {
                         y =  x;
                        iy = ix;
                         x = (am[m] * t) * y;
                        ix = iy;

                        w = fabsq(x);
                        if (w >= BIGS)
                        {
                             x *= BIGI;
                            ix += 1;
                        }
                        else if (w < BIGSI)
                        {
                             x *= BIG;
                            ix -= 1;
                        }

                        /* Pm+1,m */
                        if (ix == 0)
                        {
                            pnm1 = x;
                        }
                        else if (ix < -1)
                        {
                            pnm1 = 0.0q;
                        }
                        else if (ix < 0)
                        {
                            pnm1 = x * BIGI;
                        }
                        else
                        {
                            pnm1 = x * BIG;
                        }

                        pnmcsa = pnm1 * cnm[m][1];
                        pnmcsb = pnm1 * snm[m][1];

                        a += pnmcsa;
                        b += pnmcsb;

                        if (symmi == 1)
                        {
                            a2 -= pnmcsa;
                            b2 -= pnmcsb;
                        }


                        /* Loop over degrees */
                        /* ------------------------------------------------- */
                        for (unsigned int n = (m + 2); n <= nmax; n++)
                        {
                            ixy = ix - iy;

                            if (ixy == 0)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] * y;
                                iz = ix;
                            }
                            else if (ixy == 1)
                            {
                                 z = (am[n - 1] * t) * x - bm[n - 1] 
                                                           * (y * BIGI);
                                iz = ix;
                            }
                            else if (ixy == -1)
                            {
                                 z = (am[n - 1] * t) * (x * BIGI) \
                                     - bm[n - 1] * y;
                                iz = iy;
                            }
                            else if (ixy > 1)
                            {
                                 z = (am[n - 1] * t) * x;
                                iz = ix;
                            }
                            else
                            {
                                 z = -bm[n - 1] * y;
                                iz = iy;
                            }

                            w = fabsq(z);
                            if (w >= BIGS)
                            {
                                 z *= BIGI;
                                iz += 1;
                            }
                            else if (w < BIGSI)
                            {
                                 z *= BIG;
                                iz -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz == 0)
                            {
                                pnm2 = z;
                            }
                            else if (iz < -1)
                            {
                                pnm2 = 0.0q;
                            }
                            else if (iz < 0)
                            {
                                pnm2 = z * BIGI;
                            }
                            else
                            {
                                pnm2 = z * BIG;
                            }

                            pnmcsa = pnm2 * cnm[m][n - m];
                            pnmcsb = pnm2 * snm[m][n - m];

                            a += pnmcsa;
                            b += pnmcsb;

                            if (symmi == 1)
                            {
                                if (((n + m) % 2) == 0)
                                {
                                    a2 += pnmcsa;
                                    b2 += pnmcsb;
                                }
                                else
                                {
                                    a2 -= pnmcsa;
                                    b2 -= pnmcsb;
                                }
                            }

                             y =  x;
                            iy = ix;
                             x =  z;
                            ix = iz;

                        } /* End of the loop over harmonic degrees */
                        /* ------------------------------------------------- */

                    } /* End of computation of tesseral harmonics */
                    /* ----------------------------------------------------- */

                } /* End of computation of the lumped coefficients */
                /* --------------------------------------------------------- */


                /* The PSLR algorithm from Balmino et al. (2012) (see the 
                 * REFERENCES section at the beginning of this function) */
                /* --------------------------------------------------------- */

                /* The first longitude from the "lon" vector */
                /* ......................................................... */
                 lontmp = (__float128)m * lon0;
                clontmp = cosq(lontmp);
                slontmp = sinq(lontmp);
                dm0     = a * clontmp + b * slontmp;
                fi[0]  += dm0;
                 
                if (symmi == 1)
                {
                    dm02    = a2 * clontmp + b2 * slontmp;
                    fi2[0] += dm02;
                }
                /* ......................................................... */

               
                /* The second longitude from the "lon" vector */
                /* ......................................................... */
                if (nlon > 1)
                {
                     lontmp = (__float128)m * (lon0 + dlon);
                    clontmp = cosq(lontmp);
                    slontmp = sinq(lontmp);
                    dm1     = a * clontmp + b * slontmp;
                    fi[1]  += dm1;

                    if (symmi == 1)
                    {
                        dm12    = a2 * clontmp + b2 * slontmp;
                        fi2[1] += dm12;
                    }
                }
                /* ......................................................... */
                

                /* The third and all the remaining longitudes from the "lon" 
                 * vector */
                /* ......................................................... */
                cmdlon2 = 2.0q * cosq((__float128)m * dlon);
                for (size_t j = 2; j < nlon; j++)
                {
                    dm2    = cmdlon2 * dm1 - dm0;
                    fi[j] += dm2;
                    dm0    = dm1;
                    dm1    = dm2;

                    if (symmi == 1)
                    {
                        dm22    = cmdlon2 * dm12 - dm02;
                        fi2[j] += dm22;
                        dm02    = dm12;
                        dm12    = dm22;
                    }
                }
                /* ......................................................... */
                /* --------------------------------------------------------- */
                /* End of the PSLR algorithm */

            } /* End of the loop over harmonic orders */
            /* ------------------------------------------------------------- */


            /* Synthesis */
            /* ------------------------------------------------------------- */
            for (size_t j = 0; j < nlon; j++)
            {
                f[i * nlon + j] += fi[j];
            }

            if (symmi == 1) /* The other hemisphere computed using the symmetry
                             * property of Legendre functions with respect to 
                             * the equator */
            {
                for (size_t j = 0; j < nlon; j++)
                {
                    f[(nlat - i - 1) * nlon + j] += fi2[j];
                }
            }
            /* ------------------------------------------------------------- */


        } /* End of the loop over latitude parallels */
        /* ----------------------------------------------------------------- */

        free(ips); free(ps); free(am); free(bm); free(fi); free(fi2);

    } /* End of "#pragma omp parallel" */
    /* --------------------------------------------------------------------- */






    /* Freeing up the heap memory */
    /* --------------------------------------------------------------------- */
    free(r); free(ri); free(dn); free(en); free(fn);
    /* --------------------------------------------------------------------- */
    





    return;

}
