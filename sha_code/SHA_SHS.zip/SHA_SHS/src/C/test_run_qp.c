/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
#include <math.h>
/* ------------------------------------------------------------------------- */





/* Function prototypes */
/* ------------------------------------------------------------------------- */
void *arr_calloc(size_t, size_t);

void sh_coeffs_init_qp(__float128 ***, __float128 ***, unsigned int);
void sh_coeffs_free_qp(__float128 **, __float128 **);
void sh_coeffs_read_mtx_txt_qp(char *, __float128 **, __float128 **, unsigned int);
void sh_coeffs_write_mtx_txt_qp(char *, __float128 **, __float128 **, unsigned int,
                                char *);
void sh_coeffs_write_bin_qp(char *, __float128 **, __float128 **, unsigned int);
void sh_coeffs_read_bin_qp(char *, __float128 **, __float128 **, unsigned int);

void gl_grd_qp(unsigned int, __float128 *, __float128 *, __float128 *);

void sh_surf_synthesis_point_qp(__float128 *, size_t, __float128 *, size_t,
                                unsigned int, __float128 **, __float128 **, __float128 *);
void sh_surf_synthesis_mean_qp(__float128 *, __float128 *, size_t, __float128 *, __float128 *,
                               size_t, unsigned int, __float128 **, __float128 **,
                               __float128 *);
void sh_surf_analysis_point_qp(__float128 *, size_t, size_t, __float128 *, __float128 *,
                               unsigned int, unsigned int, __float128 **,
                               __float128 **);
void sh_surf_analysis_mean_qp(__float128 *, __float128 *, size_t,
                              __float128 *, __float128 *, size_t,
                              __float128 *, unsigned int, __float128 **, __float128 **);
/* ------------------------------------------------------------------------- */






/* The main function of the program */
/* ------------------------------------------------------------------------- */
int main(void)
/*
 * ==========================================================================
 *
 * DESCRIPTION:  This program tests the "SHA_SHS" package in C that is designed 
 * for ultra-high-degree (tens of thousands and beyond) surface spherical 
 * harmonic analysis and synthesis. The program consists of four examples.
 *
 * Functions for spherical harmonic analysis, synthesis and to compute the 
 * Gauss--Legendre grid are paralellized using OpenMP. By default, 
 * the "test_run_qp.c" program employs the number of threads available via the 
 * "OMP_NUM_THREADS" environment variable.
 *
 * For FFT, the FFTW package is employed (http://www.fftw.org/). It is assumed 
 * that FFTW is installed on your machine with OpenMP enabled. For info on the 
 * installation of FFTW, please visit the website.
 *
 * ========================================================================= */
{

    /* Maximum harmonic degree of the synthesis */
    const unsigned nmax = 360;

    /* Input file with spherical harmonic coefficients */
    char SHCs_file[256]= "./data/Earth2014.RET2014.degree360.txt";

    /* Output file with spherical harmonic coefficients from "EXAMPLE NO. 1".  
     * This is to test writing of the computed coefficients to a text file.  If 
     * the specified path does not exist, it will be created */
    char SHCs_out_txt_file[256]= "./output-data/example-no1.txt";

    /* Output file with spherical harmonic coefficients from "EXAMPLE NO. 1".  
     * This is to test writing of the computed coefficients to a binary file.  
     * If the specified path does not exist, it will be created */
    char SHCs_out_bin_file[256]= "./output-data/example-no1.shcs";






    printf("Starting the test computation...\n");






    /* Import spherical harmonic coefficients from "SHCs_file" */
    /* --------------------------------------------------------------------- */
    printf("Reading input spherical harmonic coefficients...\n");


    /* Initialize arrays to store spherical harmonic coefficients up to degree 
     * "nmax" */
    __float128 **cnm, **snm;
    sh_coeffs_init_qp(&cnm, &snm, nmax);


    /* Read the "SHCs_file" */
    sh_coeffs_read_mtx_txt_qp(SHCs_file, cnm, snm, nmax);
    /* --------------------------------------------------------------------- */






    /* Compute latitudes, longitudes and weights of the Gauss--Legendre grid 
     * associated with "nmax" */
    /* --------------------------------------------------------------------- */
    printf("Computing the grid nodes of the Gauss--Legendre quadrature for "
           "degree %u...\n", nmax);

    /* Number of latitudes in one meridian */
    size_t nlat = nmax + 1;

    /* Number of longitudes in one latitude parallel */
    size_t nlon = 2 * nmax + 2;


    /* Allocation of arrays "lat", "lon", "w" */
    /* ..................................................................... */
    __float128 *lat = (__float128 *)arr_calloc(nlat, sizeof(__float128));
    __float128 *lon = (__float128 *)arr_calloc(nlon, sizeof(__float128));
    __float128 *w   = (__float128 *)arr_calloc(nlat, sizeof(__float128));
    /* ..................................................................... */


    gl_grd_qp(nmax, lat, lon, w);
    /* --------------------------------------------------------------------- */






    /* Synthesis of the input coefficients "cnm" and "snm" at the nodes of the
     * Gauss--Legendre grid */
    /* --------------------------------------------------------------------- */
    printf("Spherical harmonic synthesis from the input coefficients "
           "up to degree %u...\n", nmax);


    /* Allocation of the "f" array to store the synthesized signal */
    __float128 *f = (__float128 *)arr_calloc(nlat * nlon, sizeof(__float128));


    /* The actual surface spherical harmonic synthesis */
    sh_surf_synthesis_point_qp(lat, nlat, lon, nlon, nmax, cnm, snm, f);
    /* --------------------------------------------------------------------- */






    /* EXAMPLE NO. 1 */
    /* --------------------------------------------------------------------- */
    /* Spherical harmonic analysis of the synthesized signal "f" */
    /* ..................................................................... */
    printf("\n\n==========================================\n\n\n");
    printf("EXAMPLE NO. 1\n\n");
    printf("Spherical harmonic analysis of the synthesized signal "
           "up to degree %u...\n", nmax);


    /* Allocation of the arrays to store the output spherical harmonic 
     * coefficients from the "sh_surf_analysis_point_qp" function */
    __float128 **cnm2, **snm2;
    sh_coeffs_init_qp(&cnm2, &snm2, nmax);


    /* The actual surface spherical harmonic analysis */
    sh_surf_analysis_point_qp(lat, nlat, nlon, w, f, nmax, nmax, cnm2, snm2);


    /* Write the computed "SHCs_file" to a text file */
    printf("Writing computed coefficients to a text file \"%s\"...\n",
            SHCs_out_txt_file);
    sh_coeffs_write_mtx_txt_qp(SHCs_out_txt_file, cnm2, snm2, nmax, " %0.34Qe");


    /* And now write the coefficients to a binary file */
    printf("Writing computed coefficients to a binary file \"%s\"...\n",
            SHCs_out_bin_file);
    sh_coeffs_write_bin_qp(SHCs_out_bin_file, cnm2, snm2, nmax);


    /* Now let's test reading the binary file.  To this end, we can free the 
     * "cnm2" and "snm2" arrays, reinitialize them to zero and then read the 
     * coefficients from the binary file.  This is rather a pointless exercise 
     * to test the binary reading. */
    sh_coeffs_free_qp(cnm2, snm2);
    sh_coeffs_init_qp(&cnm2, &snm2, nmax);
    printf("Reading computed coefficients from a binary file \"%s\"...\n",
            SHCs_out_bin_file);
    sh_coeffs_read_bin_qp(SHCs_out_bin_file, cnm2, snm2, nmax);
    /* ..................................................................... */


    /* Validate computed spherical harmonic coefficients with respect to the 
     * input coefficients */
    /* ..................................................................... */
    printf("\n\nValidation of the obtained spherical harmonic "
           "coefficients:\n\n");
    printf("Some sample original coefficients:\n");
    printf("C(n = 50, m = 20)   = %0.34Qe\n", cnm[20][50 - 20]);
    printf("S(n = 360, m = 360) = %0.34Qe\n\n", snm[360][0]);
    printf("Differences (Delta) between the computed and original sample "
           "coefficients:\n");
    printf("delta C(n = 50, m = 20) = %0.34Qe\n",
           cnm2[20][50 - 20] - cnm[20][50 - 20]);
    printf("delta S(n = 360, m = 360) = %0.34Qe\n",
           snm2[360][0] - snm[360][0]);
    printf("\n");


    /* Find the maximum of the absolute value of the discrepancies between the 
     * computed and original spherical harmonic coefficients */
    __float128 max_diff_cnm_snm = fabsq(cnm2[0][0] - cnm[0][0]);
    __float128 diff;
    for (unsigned int m = 0; m <= nmax; m++)
        for (unsigned int n = m; n <= nmax; n++)
        {
            diff = fabsq(cnm2[m][n - m] - cnm[m][n - m]);
            if (diff > max_diff_cnm_snm)
                max_diff_cnm_snm = diff;

            if (m > 0)
            {
                diff = fabsq(snm2[m][n - m] - snm[m][n - m]);
                if (diff > max_diff_cnm_snm)
                    max_diff_cnm_snm = diff;
            }
        }


    printf("max(abs(Delta)) value discrepancy for all coefficients:\n");
    printf("%0.34Qe\n", max_diff_cnm_snm);
    /* ..................................................................... */


    /* Deallocate arrays of spherical harmonic coefficients that are no longer 
     * needed */
    sh_coeffs_free_qp(cnm2, snm2);
    /* --------------------------------------------------------------------- */






    /* EXAMPLE NO. 2 */
    /* --------------------------------------------------------------------- */
    /* Now let's use the same input signal "f" that was synthesized up to 
     * degree "nmax = 360", but this time it is harmonically analysed up to 
     * degree "nmax2 = 50" (instead of 360 as done above). This example 
     * demonstrates that if a band-limited signal is sampled correctly, than 
     * spherical harmonic coefficients can be computed *exactly* for any degree 
     * "nmax2 = 0,... , nmax" (further details can be found in the 
     * "sh_surf_analysis_point_qp.c" function). */
    /* ..................................................................... */
    printf("\n\n==========================================\n");
    printf("\n\nEXAMPLE NO. 2\n\n");
    printf("Spherical harmonic analysis of the synthesized signal, "
           "but this time only up to degree 50, despite that the "
           "input signal possesses harmonics up to degree %u...\n", nmax);


    /* Allocation of the "cnm3" and "snm3" arrays to store the spherical 
     * harmonic coefficients */
    __float128 **cnm3, **snm3;
    sh_coeffs_init_qp(&cnm3, &snm3, 50);


    /* The actual surface spherical harmonic analysis */
    sh_surf_analysis_point_qp(lat, nlat, nlon, w, f, nmax, 50, cnm3, snm3);
    /* ..................................................................... */


    /* Validate computed spherical harmonic coefficients with respect to the 
     * input coefficients */
    /* ..................................................................... */
    printf("\n\nValidation of the obtained spherical harmonic "
           "coefficients:\n\n");
    printf("Some sample original coefficients:\n");
    printf("C(n = 30, m = 20) = %0.34Qe\n", cnm[20][30 - 20]);
    printf("S(n = 50, m = 50) = %0.34Qe\n\n", snm[50][0]);
    printf("Differences (Delta) between the computed and original sample "
           "coefficients:\n");
    printf("delta C(n = 30, m = 20) = %0.34Qe\n",
           cnm3[20][30 - 20] - cnm[20][30 - 20]);
    printf("delta S(n = 50, m = 50) = %0.34Qe\n\n",
           snm3[50][0] - snm[50][0]);


    /* Find the maximum of the absolute value of the discrepancies between the 
     * computed and original spherical harmonic coefficients */
    max_diff_cnm_snm = 0.0q;
    max_diff_cnm_snm = fabsq(cnm3[0][0] - cnm[0][0]);
    for (unsigned int m = 0; m <= 50; m++)
        for (unsigned int n = m; n <= 50; n++)
        {
            diff = fabsq(cnm3[m][n - m] - cnm[m][n - m]);
            if (diff > max_diff_cnm_snm)
                max_diff_cnm_snm = diff;

            if (m > 0)
            {
                diff = fabsq(snm3[m][n - m] - snm[m][n - m]);
                if (diff > max_diff_cnm_snm)
                    max_diff_cnm_snm = diff;
            }
        }


    printf("max(abs(Delta)) value discrepancy for all coefficients:\n");
    printf("%0.34Qe\n", max_diff_cnm_snm);
    /* ..................................................................... */


    /* Deallocate arrays that are no longer needed */
    sh_coeffs_free_qp(cnm3, snm3);
    free(f);
    free(lat); free(lon), free(w);
    /* --------------------------------------------------------------------- */






    /* EXAMPLE NO. 3 */
    /* --------------------------------------------------------------------- */
    /* Spherical harmonic synthesis of the mean values of "f" over specified 
     * grid cells */
    printf("\n\n==========================================\n\n\n");
    printf("EXAMPLE NO. 3\n\n");
    printf("Spherical harmonic synthesis of the mean values of the input "
           "signal over grid cells up to degree %u\n", nmax);


    /* Computational grid */
    /* ..................................................................... */
    /* Number of latitudes */
    nlat = nmax + 1;

    /* Number of longitudes */
    nlon = 2 * (nmax + 1);

    __float128 *lat1 = (__float128 *)arr_calloc(nlat, sizeof(__float128));
    __float128 *lat2 = (__float128 *)arr_calloc(nlat, sizeof(__float128));
    __float128 *lon1 = (__float128 *)arr_calloc(nlon, sizeof(__float128));
    __float128 *lon2 = (__float128 *)arr_calloc(nlon, sizeof(__float128));


    /* Create arrays "lat1" and "lat2" that specify the minimum and maximum 
     * latitudes of the grid cells, respectively */
    for (size_t i = 0; i < nlat; i++)
    {
        lat1[i] = -M_PI_2q + (__float128)i * M_PIq / (__float128)nlat;
        lat2[i] = -M_PI_2q + (__float128)(i + 1) * M_PIq / (__float128)nlat;
    }


    /* Create arrays "lon1" and "lon2" that specify the minimum and maximum 
     * longitudes of the grid cells, respectively */
    for (size_t i = 0; i < nlon; i++)
    {
        lon1[i] = (__float128)i * 2.0q * M_PIq / (__float128)nlon;
        lon2[i] = (__float128)(i + 1) * 2.0q * M_PIq / (__float128)nlon;
    }
    /* ..................................................................... */


    /* Harmonic synthesis of the mean values of "f" over the grid cells */
    /* ..................................................................... */
    /* Allocation of the "f" array to store the synthesized signal */
    f = (__float128 *)arr_calloc(nlat * nlon, sizeof(__float128));


    sh_surf_synthesis_mean_qp(lat1, lat2, nlat, lon1, lon2, nlon, nmax,
                              cnm, snm, f);
    /* ..................................................................... */


    /* Sample output from the synthesized mean values */
    /* ..................................................................... */
    printf("\n\nSample outputs for some of the grid cells\n");
    printf("lat_min (deg)            lat_max (deg)           "
           "lon_min (deg)           lon_max (deg)           f_mean\n");
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
            lat1[14] * 180.0q / M_PIq, lat2[14] * 180.0q / M_PIq,
            lon1[119] * 180.0q / M_PIq, lon2[119] * 180.0q / M_PIq,
            f[14 * nlon + 119]);
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
            lat1[129] * 180.0q / M_PIq, lat2[129] * 180.0q / M_PIq,
            lon1[399] * 180.0q / M_PIq, lon2[399] * 180.0q / M_PIq,
            f[129 * nlon + 399]);
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
            lat1[229] * 180.0q / M_PIq, lat2[229] * 180.0q / M_PIq,
            lon1[449] * 180.0q / M_PIq, lon2[449] * 180.0q / M_PIq,
            f[229 * nlon + 449]);
    /* ..................................................................... */


    /* Reference values */
    /* ..................................................................... */
    printf("\n\nReference values for the same grid cells\n");
    printf("lat_min (deg)            lat_max (deg)           "
           "lon_min (deg)           lon_max (deg)           f_mean\n");
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
           -8.3019390581717451523545706371191143e+01q,
           -8.2520775623268698060941828254847650e+01q,
            5.9335180055401662049861495844875353e+01q,
            5.9833795013850415512465373961218846e+01q,
            1.7043271535031928801487477855998438e+03q);
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
           -2.5678670360110803324099722991689748e+01q,
           -2.5180055401662049861495844875346255e+01q,
            1.9894736842105263157894736842105265e+02q,
            1.9944598337950138504155124653739614e+02q,
           -2.9397239537016446157449558921122953e+03q);
    printf("%0.34Qe %0.34Qe %0.34Qe %0.34Qe %0.34Qe\n",
             2.4182825484764542936288088642659281e+01q,
             2.4681440443213296398891966759002783e+01q,
             2.2387811634349030470914127423822716e+02q,
             2.2437673130193905817174515235457063e+02q,
            -2.8182238132112049645159110290115808e+03q);
    /* ..................................................................... */


    /* Deallocate arrays of spherical harmonic coefficients that are no longer 
     * needed */
    sh_coeffs_free_qp(cnm, snm);
    /* --------------------------------------------------------------------- */





    /* EXAMPLE NO. 4 */
    /* --------------------------------------------------------------------- */
    /* Spherical harmonic analysis of the mean values of "f" (taken from 
     * Example No. 3) */
    printf("\n\n==========================================\n\n\n");
    printf("EXAMPLE NO. 4\n\n");
    printf("Spherical harmonic analysis of the mean values of the input "
           "signal (taken from Example No. 3) up to degree %u\n", nmax);

    __float128 **cnm4, **snm4;
    sh_coeffs_init_qp(&cnm4, &snm4, nmax);


    /* The actual analysis */
    sh_surf_analysis_mean_qp(lat1, lat2, nlat, lon1, lon2, nlon, f, nmax,
                             cnm4, snm4);


    printf("\n");
    printf("Sample output spherical harmonic coefficients\n");
    unsigned int n = 10;
    unsigned int m = 5;
    printf("C%u,%u: %0.34Qe\n", n, m, cnm4[m][n - m]);
    printf("S%u,%u: %0.34Qe\n", n, m, snm4[m][n - m]);

    n = 100;
    m = 100;
    printf("C%u,%u: %0.34Qe\n", n, m, cnm4[m][n - m]);
    printf("S%u,%u: %0.34Qe\n", n, m, snm4[m][n - m]);

    n = 360;
    m = 360;
    printf("C%u,%u: %0.34Qe\n", n, m, cnm4[m][n - m]);
    printf("S%u,%u: %0.34Qe\n", n, m, snm4[m][n - m]);


    printf("\n");
    printf("Reference values of the same spherical harmonic coefficients\n");
    n = 10;
    m = 5;
    printf("C%u,%u: %0.34Qe\n", n, m, 1.8821659249835386960796407273004462e+01q);
    printf("S%u,%u: %0.34Qe\n", n, m, 1.5108705876492680977185189687310518e+01q);

    n = 100;
    m = 100;
    printf("C%u,%u: %0.34Qe\n", n, m, 2.2898358283054604868295941488773461e+00q);
    printf("S%u,%u: %0.34Qe\n", n, m, 2.7464435507090903488422192283940638e-01q);

    n = 360;
    m = 360;
    printf("C%u,%u: %0.34Qe\n", n, m, 2.8154677740267685564060723779906159e-02q);
    printf("S%u,%u: %0.34Qe\n", n, m, 
           -6.8915310673496287330539418369571050e-02q);
    printf("\n\n==========================================\n");


    /* Deallocate arrays that are no longer needed */
    sh_coeffs_free_qp(cnm4, snm4);
    free(lat1), free(lat2);
    free(lon1), free(lon2);
    /* --------------------------------------------------------------------- */



    printf("\n\nEnd of the test computation\n");
    return 0;

} /* End of the "main" function */
/* ------------------------------------------------------------------------- */
