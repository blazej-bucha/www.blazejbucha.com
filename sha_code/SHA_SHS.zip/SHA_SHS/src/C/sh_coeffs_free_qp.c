/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






void sh_coeffs_free_qp(__float128 **cnm, __float128 **snm)
/*
 * DESCRIPTION: Deallocates 2D arrays of spherical harmonic coefficients "cnm" 
 * and "snm" that were initialized via "sh_coeffs_init_qp.c".
 *
 * The function is written in quadruple precision.
 *
 *
 * EXAMPLE CALL: Assuming "cnm" and "snm" were initialized using 
 * "sh_coeffs_init_qp.c", the arrays can be deallocated as follows:
 *
 *      sh_coeffs_free_qp(cnm, snm);
 *
 *
 * NOTE: The usual deallocation
 *
 *      free(cnm), free(snm);
 *
 * will *not* deallocate the memory and will lead to memory leaks.
 *
 * */
{
    /* Deallocate the memory associated with the numerical values of spherical 
     * harmonic coefficients */
    free(cnm[0]), free(snm[0]);


    /* Deallocate the memory associated with the pointer arrays "cnm" and "snm" 
     * */
    free(cnm), free(snm);


    return;
}

