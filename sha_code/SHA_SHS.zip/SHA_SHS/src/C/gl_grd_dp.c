/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <math.h>
/* ------------------------------------------------------------------------- */






void gl_grd_dp(unsigned int nmax, double *lat, double *lon, double *w)
/*
 * ============================================================================
 *
 * DESCRIPTION: This function generates latitudes, longitudes and weights of
 *              the grid nodes required by the Gauss--Legendre quadrature
 *              (e.g., Sneeuw, 1994) for a specified maximum harmonic degree.
 *
 *              Note that the grid is non-equiangular in terms of latitudes.
 *              The step in the longitudinal direction is, however, constant.
 *
 *              The function is written in double precision.
 *
 *
 * INPUTS:   "nmax" -- Maximum spherical harmonic degree of the signal that
 *                     is to be harmonically analysed
 *
 *
 * OUTPUTS:  "lat" -- Pointer to an array of spherical latitudes in radians.
 *                    Dimension (nmax + 1).
 *
 *           "lon" -- Pointer to an array of longitudes in radians.
 *                    Dimension (2 * nmax + 2).
 *
 *           "w"   -- Pointer to an array of weights given by the 
 *                    Gauss--Legendre quadrature (dimensionless).
 *                    Dimension (nmax + 1).
 *
 *
 * This function is based on the MATLAB "legzo.m" function
 * (https://github.com/Pazus/Legendre-Gauss-Quadrature/blob/master/legzo.m)
 * published by Pazus (https://github.com/Pazus). Minor modifications were
 * introduced, such that it now yields spherical latitudes and longitudes
 * as the output coordinates.
 *
 *
 * REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
 *                least-squares and numerical quadrature methods in historical
 *                perspective. Geophysical Journal International 118:707--716
 *
 * ========================================================================= */
{

    unsigned int nmax1 = nmax + 1;

    /* Note that "m" is rounded to the greatest integer less than or equal to 
     * "(nmax1 + 1) / 2". */
    unsigned int m = (nmax1 + 1) / 2; 


    double c = (double)nmax1 + 0.5;

    
    /* Computation of the latitudes and weights */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel default(none) shared(lat, w, nmax1, m, c)
    {
    double z, z1, p1, p2, p3, pp;


    #pragma omp for
    for (unsigned int i = 0; i < m; i++) 
    {
        z = cos(M_PI * ((double)(i + 1) - 0.25) / c); 
        z1 = z + 1.0;


        while (fabs(z - z1) > __DBL_EPSILON__)
        {
            p1 = 1.0;
            p2 = 0.0;


            for (unsigned int j = 1; j <= nmax1; j++)
            {
                p3 = p2;
                p2 = p1;
                p1 = ((double)(2 * j - 1) * z * p2 - (double)(j - 1) * p3)
                     / (double)j;
            }


            pp = (double)nmax1 * (z * p1 - p2) / (z * z - 1.0);
            z1 = z;
            z  = z1 - p1 / pp;
        }


        lat[nmax1 - 1 - i] = asin(z);
        lat[i] = -lat[nmax1 - 1 - i];


        w[nmax1 - 1 - i] = 2.0 / ((1.0 - z * z) * pp * pp);
        w[i] = w[nmax1 - 1 - i];
    }
    }
    /* --------------------------------------------------------------------- */


    /* Computation of the longitudes */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel for default(none) shared(lon, nmax1)
    for (unsigned int i = 0; i < (2 * nmax1); i++)
        lon[i] = M_PI / (double)nmax1 * (double)(i);
    /* --------------------------------------------------------------------- */


    return;
}
