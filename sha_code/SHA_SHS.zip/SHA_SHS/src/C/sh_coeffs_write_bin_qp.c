/* This quadruple code variant was generated automatically from its double
 * version counterpart.  This was accomplished by a Linux Bash script. As a
 * consequence, the code may not be nicely aligned or it may exceed 79
 * characters in a line.  It may also happen that some comments in this 
 * file were modified and may no longer make sense.  If you are interested in 
 * the comments, please *always* refer to the double precision code variant!  
 * Sorry for that. */












/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <quadmath.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
FILE *fopen_create_path(char *, char *);
/* ------------------------------------------------------------------------- */






void sh_coeffs_write_bin_qp(char *file, __float128 **cnm, __float128 **snm,
                            unsigned int nmax)
/*
 * DESCRIPTION: Writes spherical harmonic coefficients up to degree "nmax" from 
 * __float128 precision arrays "cnm" and "snm" (created by "sh_coeffs_init_qp.c") 
 * to a binary "file".
 *
 * The output "file" is a binary representation of the spherical harmonic 
 * coefficients in the following order:
 *
 * C_{0,0} C_{1,0} C_{2,0} ... C_{nmax,0} C_{1,1} C_{2,1} ... C_{nmax,1} \
 * C_{2,2} C_{3,2} ... C_{nmax,nmax} S_{0,0} S_{1,0} S_{2,0} ... S_{nmax,0} \
 * S_{1,1} S_{2,1} ... S_{nmax,1} S_{2,2} S_{3,2}... S_{nmax,nmax}
 *
 * where "C_{n,m}" and "S_{n,m}" are spherical harmonic coefficients of degree 
 * "n" and order "m".  It must hold that the "cnm" and "snm" arrays store 
 * spherical harmonic coefficients up to degree "nmax2 >= nmax".  That is, from 
 * all coefficients in "cnm" and "snm" up to degree "nmax2", properly written
 * can be any subset up to degree "nmax <= nmax2".  For each coefficient, 
 * "sizeof(__float128)" bytes are reserved.
 *
 * The function is written in quadruple precision.
 *
 * */
{
    /* Open a buffer for the output "file".  If "file" does not exist, create 
     * it.  No check on whether "fptr" is null is needed, as this is done by 
     * "fopen_create_path.c". */
    FILE *fptr = fopen_create_path(file, "wb");


    /* Variable to check whether "fwrite" was successful */
    int err;


    /* Write the "cnm" coefficients */
    /* ===================================================================== */
    /* Loop over the harmonic orders */
    for(unsigned int m = 0; m <= nmax; m++)
    {
        err = fwrite(cnm[m], sizeof(__float128), nmax + 1 - m, fptr);
        if (err < 1)
        {
            printf("[sh_coeffs_write_bin_qp.c says:] Error "
                   "encountered when writing to \"%s\" (C coefficient of "
                   "harmonic order %u).  "
                   "Terminating the code execution.\n", file, m);
            exit(EXIT_FAILURE);
        }
    }
    /* ===================================================================== */


    /* Write the "snm" coefficients */
    /* ===================================================================== */
    /* Loop over the harmonic orders */
    for(unsigned int m = 0; m <= nmax; m++)
    {
        err = fwrite(snm[m], sizeof(__float128), nmax + 1 - m, fptr);
        if (err < 1)
        {
            printf("[sh_coeffs_write_bin_qp.c says:] Error "
                   "encountered when writing to \"%s\" (S coefficient of "
                   "harmonic order %u).  "
                   "Terminating the code execution.\n", file, m);
            exit(EXIT_FAILURE);
        }
    }
    /* ===================================================================== */



    err = fclose(fptr);
    if (err != 0)
    {
        printf("[sh_coeffs_write_bin_qp.c says:] Error encountered when "
               "closing the stream for \"%s\".  Terminating the code "
               "execution.\n", file);
        exit(EXIT_FAILURE);
    }


    return;
}
