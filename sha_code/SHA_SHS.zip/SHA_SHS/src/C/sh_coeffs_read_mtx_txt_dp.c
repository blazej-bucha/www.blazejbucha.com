/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
void *arr_malloc(size_t);
/* ------------------------------------------------------------------------- */






void sh_coeffs_read_mtx_txt_dp(char *file, double **cnm, double **snm,
                               unsigned int nmax)
/*
 * DESCRIPTION: Reads spherical harmonic coefficients up to degree "nmax" from 
 * a text "file" and stores them in double precision arrays "cnm" and "snm" 
 * that need to be initialized by "sh_coeffs_init_dp.c" before calling this 
 * function.
 *
 * "file" must contain a matrix with the following structure:
 *
 *    C_{00}       S_{11}       S_{21}       S_{31}      ...  S_{nmax2,1}
 *    C_{10}       C_{11}       S_{22}       S_{32}      ...  S_{nmax2,2}
 *    C_{20}       C_{21}       C_{22}       S_{33}      ...  S_{nmax2,3}
 *    C_{30}       C_{31}       C_{32}       C_{33}      ...  S_{nmax2,4}
 *    .                                                  .    .
 *    .                                                   .   .
 *    .                                                    .  .
 *    C_{nmax2,0}  C_{nmax2,1}  C_{nmax2,2}  C_{nmax2,3}  ... C_{nmax2,nmax2}
 *
 * where "C_{n,m}" and "S_{n,m}" are spherical harmonic coefficients of degree 
 * "n" and order "m".  It must hold that "nmax <= nmax2".  That is, from all 
 * coefficients in "file" up to degree "nmax2", properly loaded can be any 
 * subset up to degree "nmax <= nmax2".
 *
 * Any empty line (that is, containing only the new line character '\n') is 
 * ignored.
 *
 * The function is written in double precision.
 *
 * */
{
    /* Open a buffer for the input "file" */
    /* ===================================================================== */
    FILE *fptr = fopen(file, "r");
    if (fptr == NULL)
    {
        printf("[sh_coeffs_read_mtx_txt_dp.c says:] The \"%s\" file not "
               "found.  Terminating the code execution.\n", file);

        exit(EXIT_FAILURE);
    }
    /* ===================================================================== */






    /* Read the elements of the matrix in "file" */
    /* ===================================================================== */
    /* A single string loaded from the input file at a time */
    char *str = (char *)arr_malloc(256 * sizeof(char));


    /* Pointer to the character after the last character used in the conversion 
     * in "strtod" is stored in the location referenced by "end_ptr" */
    char *end_ptr;


    /* String to store the new line character */
    char nl[1] = "\0";


    /* The number of input items successfully matched and assigned from the 
     * "fscanf" function */
    int num_entries;


    /* Spherical harmonic coefficient from "str" converted to a numerical data 
     * type */
    double coeff;


    /* Loop over the rows of the matrix */
    for(unsigned int r = 0; r <= nmax; r++)
    {
        /* Loop over the columns of the matrix */
        for(unsigned int c = 0; c <= nmax; c++) 
        {
            /* Check the file stream for the end of file */
            /* ------------------------------------------------------------- */
            if (feof(fptr))
            {
                printf("[sh_coeffs_read_mtx_txt_dp.c says:] \"%s\" has too "
                       "few rows to read spherical harmonic "
                       "coefficients up to degree "
                       "%u.  Terminating the code execution.\n", file, nmax);
                exit(EXIT_FAILURE);
            }
            /* ------------------------------------------------------------- */


            /* Read an entry from the text file and store it as a string */
            /* ------------------------------------------------------------- */
            num_entries = fscanf(fptr, "%s", str);


            if (num_entries == 0)
            {
                printf("[sh_coeffs_read_mtx_txt_dp.c says:] Failed when "
                       "reading \"%s\" (row %u, column %u).\n",
                       file, r + 1, c + 1);
                exit(EXIT_FAILURE);
            }
            /* ------------------------------------------------------------- */


            /* Read the new line character if any */
            /* ------------------------------------------------------------- */
            num_entries = fscanf(fptr, "%1[\n]", nl);


            if ((num_entries == 1) && (nl[0] == '\n') && c < nmax)
            {
                printf("[sh_coeffs_read_mtx_txt_dp.c says:] \"%s\" has too "
                       "few columns to read spherical harmonic "
                       "coefficients up to degree "
                       "%u.  Terminating the code execution.\n", file, nmax);
                exit(EXIT_FAILURE);
            }
            /* ------------------------------------------------------------- */


            /* Convert the number in "str" from string to double and check the 
             * conversion */
            /* ------------------------------------------------------------- */
            coeff = strtod(str, &end_ptr);


            if (end_ptr == str)
            {
                printf("[sh_coeffs_read_mtx_txt_dp.c says:] Failed when "
                       "converting \"%s\" in \"%s\" (row %u, column %u) to "
                       "double data format.  Terminating the "
                       "code execution.\n", str, file, r + 1, c + 1);
                exit(EXIT_FAILURE);
            }
            /* ------------------------------------------------------------- */


            /* Save the value of "coeff" to the right place of either "cnm" or 
             * "snm" */
            /* ------------------------------------------------------------- */
            if (r >= c)
                cnm[c][r - c] = coeff;
            else
                snm[r + 1][c - r - 1] = coeff;
            /* ------------------------------------------------------------- */
        }


        /* If the input data file contains more than "nmax + 1" columns, 
         * continue with reading the next line, since all sought "nmax + 1" 
         * values from the "r"th line were read */
        if (nl[0] != '\n')
            fscanf(fptr, "%*[^\n]\n");


        /* Reset "nl" (it may contain the new line character found at the end 
         * of a line) */
        nl[0] = '\0';
    }


    fclose(fptr);
    /* ===================================================================== */






    return;
}
