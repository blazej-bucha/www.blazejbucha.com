/* Header files */
/* ------------------------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
/* ------------------------------------------------------------------------- */






/* Function prototypes */
/* ------------------------------------------------------------------------- */
double arr_min_dp(double *, size_t);
void *arr_calloc(size_t, size_t);
/* ------------------------------------------------------------------------- */






void sh_surf_synthesis_mean_dp(double *lat1, double *lat2, size_t nlat,
                               double *lon1, double *lon2, size_t nlon,
                               unsigned int nmax, double **cnm,
                               double **snm, double *f)
/*
 * ============================================================================
 *
 * DESCRIPTION: This function computes mean values of some function that is 
 *              expanded into surface spherical harmonics by computing its 
 *              integral on the unit sphere over grid cells specified by 
 *              minimum and maximum latitudes and longitudes. The function 
 *              employs a FFT-based algorithm (e.g., Colombo, 1981).
 *
 *              The function is written in double precision.
 *
 *              The loop over latitude cells is parallelized using OpenMP.
 *
 *              The function automatically starts the synthesis from degree
 *              "nmin = 0". If you wish to use some other value of "nmin"
 *              (but satisfying "1 <= nmin <= nmax"), you can set (outside this
 *              function) the respective coefficients of the "cnm" and "snm" 
 *              arrays to zero and use the new matrices as the input to this 
 *              function. In that case, the synthesis still starts at degree 0, 
 *              but since the coefficients up to degree "nmin - 1" are zero, 
 *              they do not contribute to the output signal as required.
 *
 *              The 4*pi fully-normalized associated Legendre functions
 *              (e.g., Heiskannen and Moritz, 1967) are evaluated by the
 *              numerically stable algorithm by Fukushima (2012). The algorithm
 *              can be used up to ultra-high harmonic degrees (say, tens of
 *              thousands or even well beyond).
 *
 *              The function exploits the symmetry property of Legendre
 *              functions and their integrals with respect to the equator, 
 *              thereby improving its performance, especially for 
 *              ultra-high-degree harmonic synthesis. This computational 
 *              acceleration is employed automatically, provided that the grid 
 *              is recognized as symmetric with respect to the equator. Below, 
 *              we provide some examples of symmetric and non-symmetric 
 *              grids. Note that while these examples use the unit degrees for 
 *              a more intuitive understanding, the function requires radians 
 *              as the input unit.
 *
 *              Examples of some symmetric grids (shown are only the minimum 
 *              and the maximum latitudes "lat1" and "lat2", respectively):
 *              lat1 = {-90, -60, -30,  0, 30, 60};
 *              lat2 = {-60, -30,   0, 30, 60, 90};
 *
 *              lat1 = {-35, -25, -15, -5,  5, 15, 25};
 *              lat2 = {-25, -15,  -5,  5, 15, 25, 35};
 *
 *              lat1 = {-90, -85, 80, 85};
 *              lat2 = {-85, -80, 85, 90};
 *
 *              lat1 = {-90, -80, -75, -70, 69, 70, 75, 80}; // Varying cell
 *                                                          // size
 *              lat2 = {-80, -75, -70, -69, 70, 75, 80, 90}; // Varying cell
 *                                                          // size
 *
 *              Examples of some grids that are not considered as symmetric
 *              (shown are again only latitudes):
 *              lat1 = {-90, -60, -30,  0, 30};
 *              lat2 = {-60, -30,   0, 30, 60}; // The negative latitude of -90
 *                                              // deg does not have its
 *                                              // positive counterpart
 *
 *              lat1 = {-35, -25, -15,     5, 15, 25};
 *              lat2 = {-25, -15,  -4.99, 15, 25, 35}; // The difference
 *                                                     // "abs(abs(-4.99)-5)"
 *                                                     // is larger than the
 *                                                     // threshold "THRESHOLD"
 *                                                     // (see below)
 *
 *               In other words, the grid is symmetric, provided that all
 *               positive latitudes have their negative counterpart or vice 
 *               versa (up to a given threshold to suppress numerical 
 *               inaccuracies, see the "THRESHOLD" variable).
 *
 *
 *               The longitudes of the grid must be sampled with equal spacing,
 *               that is, the difference between any two consecutive longitudes
 *               must be constant. The function performs a check on this.
 *               If the longitudes does not pass the test, a message is printed
 *               and the execution is stopped. If you know for sure that
 *               your longitudes share an equal spacing, but never pass
 *               the test, you may want to use a larger value of the 
 *               "THRESHOLD" variable (see below). This might happen due to the 
 *               rounding errors with a long vector of longitudes.
 *
 *
 *
 * INPUTS: "lat1"      -- Pointer to an array defining the minimum latitudes of 
 *                        the grid cells in radians (latitudes over a single 
 *                        meridian).
 *
 *         "lat2"      -- Pointer to an array defining the maximum latitudes of 
 *                        the grid cells in radians (latitudes over a single 
 *                        meridian).
 *
 *         "nlat"      -- Number of latitudes in the arrays to which "lat1" and 
 *                        "lat2" point to.
 *
 *         "lon1"      -- Pointer to an array defining the minimum longitudes 
 *                        of the grid in radians (longitudes over a single 
 *                        latitude parallel).
 *
 *         "lon2"      -- Pointer to an array defining the maximum longitudes 
 *                        of the grid in radians (longitudes over a single 
 *                        latitude parallel).
 *
 *         "nlon"      -- Number of longitudes in the arrays to which "lon1" 
 *                        and "lon2" point to.
 *
 *         "nmax"      -- Maximum spherical harmonic degree of the synthesis
 *
 *         "cnm"       -- Double pointer to a 2D array with the input "Cnm" 
 *                        spherical harmonic coefficients. The first dimension 
 *                        is related to harmonic orders and the second one to 
 *                        harmonic degrees. Importantly, the number of columns 
 *                        varies for each row as follows:
 *                        
 *                        
 *                        Order 0: "cnm[0]" has "nmax + 1" columns for degrees 
 *                        "0, 1, ..., nmax" (respectively),
 *
 *                        Order 1: "cnm[1]" has "nmax" columns for degrees "1, 
 *                        2, ..., nmax" (respectively),
 *
 *                        Order 2: "cnm[2]" has "nmax - 1" columns for degrees 
 *                        "2, 3, ..., nmax" (respectively),
 *
 *                        .
 *                        .
 *                        .
 *
 *                        Order "nmax": "cnm[nmax]" has "1" column for degree 
 *                        "nmax".
 *
 *
 *                        This means that "cnm" is *not* a 2D rectangular 
 *                        array. It should be allocated by 
 *                        "sh_coeffs_init_dp.c" and deallocated by 
 *                        "sh_coeffs_free_dp.c".
 *
 *                        The harmonic coefficient "Cnm" of degree "n" and 
 *                        order "m" can therefore be accessed as follows:
 *
 *                        cnm[m][n - m]
 *
 *         "snm"       -- The same as "cnm" above, but with the "Snm" 
 *                        coefficients.
 *
 *
 * OUTPUTS: "f" -- Pointer to an array of the synthesized mean values of the 
 *                 signal (e.g., topographic heights) of dimensions (nlat * 
 *                 nlon).
 *
 *                 Using the traditional row-major order of matrix elements in 
 *                 C, the array to which "f" points can be depicted as a matrix 
 *                 of the dimensions (nlat, nlon), sampled as follows:
 *
 *  [(lat[0,0],lon[0,0])           ...       (lat[0,0],lon[nlon - 1,nlon - 1]]
 *  [      .                       .                           .             ]
 *  [      .                        .                          .             ]
 *  [      .                         .                         .             ]
 *  [(lat[nlat-1,nlat-1],lon[0,0]) ... (lat[nlat-1,nlat-1],lon[nlon-1,nlon-1]]
 *
 *                 where "lat[i,i]" represents the cell with the minimum 
 *                 latitude "lat1[i]" and maximum latitude "lat2[i]", and 
 *                 "lon[j,j]" stands for the cell with the minimum longitude 
 *                 "lon1[j]" and maximum longitude "lon2[j]".
 *
 *                 This means that, for instance, the value of "f" for 
 *                 "lat1[i]", "lat2[i]", "lon1[j]" and "lon2[j]" can be found 
 *                 as follows:
 *
 *                 "f[i * nlon + j]"
 *
 *
 * REFERENCES: Colombo, O. L. (1981) Numerical methods for harmonic analysis on 
 *                the sphere. Reports of the Department of Geodetic Science, 
 *                Report No. 310, 140 pp
 *
 *             Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
 *                Freeman and Company, San Francisco, 364 pp
 *            
 *             Jekeli, C., Lee, J. K., Kwon, J. H. (2007) On the computation
 *                and approximation of ultra-high-degree spherical harmonic 
 *                series. Journal of Geodesy 81:603--615
 *
 *             Fukushima, T. (2012) Numerical computation of spherical
 *                harmonics of arbitrary degree and order by extending exponent
 *                of floating point numbers. Journal of Geodesy 86:271--285.
 *
 *             Balmino, Vales, Bonvalot, Briais, 2012. Spherical harmonic
 *                 modelling to ultra-high degree of Bouguer and isostatic
 *                 anomalies. Journal of Geodesy 86:499–520,
 *                 doi: 10.1007/s00190-011-0533-4
 *
 *            Fukushima, T. (2014) Numerical computation of spherical harmonics
 *                of arbitrary degree and order by extending exponent of
 *                floating point numbers: III integral. Computers & Geosciences
 *                63:17--21
 *
 *
 * Contact: blazej.bucha@stuba.sk
 *
 *
 * Please use the following reference when using this function:
 *
 *          Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
 *             spectral gravity forward modelling up to the full gravity
 *             tensor. Journal of Geodesy 93:1707--1737
 *
 *
 * ========================================================================= */
{

    /* Some useful constants */
    /* --------------------------------------------------------------------- */
    /* Threshold to judge whether two double numbers are equal (can be changed 
     * as needed) */
    const double THRESHOLD = 10000.0 * __DBL_EPSILON__;


    /* Some constants to compute associated Legendre functions using the 
     * extended-range arithmetic approach */
    const int IND = 960;
    const double BIG = pow(2.0, IND);
    const double BIGI = pow(2.0, -IND);
    const double BIGS = pow(2.0, IND / 2.0);
    const double BIGSI = pow(2.0, -IND / 2.0);
    const double ROOT3 = 1.7320508075688772935;
    /* --------------------------------------------------------------------- */


   



    /* Check the latitudes of the computational grid */
    /* --------------------------------------------------------------------- */

    /* Check whether the number of latitudes in "lat1" and "lat2" is even or 
     * odd */
    /* ..................................................................... */
    int even; /* If the number of latitudes is even, then "even = 1", 
               * otherwise "even = 0" */
    if ((nlat % 2) == 0) 
    {
        even = 1;
    }
    else
    {
        even = 0;
    }
    /* ..................................................................... */






    /* Determine whether the latitudes are symmetric with respect to the
     * equator */
    /* ..................................................................... */
    int symm; /* If the grid is symmetric with respect to the equator, then
               * "symm = 1", otherwise "symm = 0". If "symm == 1", the function 
               * automatically exploits the symmetry property of Legendre 
               * functions in order to accelerate the computation */
    if (nlat == 1)
    {
        symm = 0; /* If there is only one cell in the latitudinal direction 
                   * within the grid, the grid is automatically considered as 
                   * not symmetric */
    }
    else
    {
        symm = 1; /* If there is more than one cell in the latitudinal 
                   * direction in the grid, let's start by assuming that the 
                   * grid is symmetric with respect to the equator and check 
                   * whether this is indeed true */

    }


    for (size_t i = 0; i < nlat; i++)
    {
        if (fabs(lat1[i] + lat2[nlat - i - 1]) > THRESHOLD)
        {
            symm = 0; /* The grid is not symmetric */

            break; /* Exiting the loop with the final decision: the grid is not
                    * symmetric with respect to the equator ("symm = 0") */
        }
    }
    /* ..................................................................... */


    /* Finally, if the grid is symmetric, we modify the number of latitudes 
     * "nlat" to be equal to the number of latitudes on one hemisphere only 
     * (including the equator if present). This is because the time-consuming     
     * "for loop" over evaluation points now needs to run for one hemisphere 
     * only, while the results for the other hemisphere are obtained by 
     * exploiting the symmetry property of Legendre functions. This reduces the 
     * number of Legendre functions that need to be evaluated by a factor of    
     * ~2, so saves some computational time */
    /* ..................................................................... */
    size_t nlatdo;
    if (symm == 1)
    {
        if (even == 1)
        {
            nlatdo = nlat / 2;
        }
        else
        {
            nlatdo = (nlat + 1) / 2;
        }
    }
    else
    {
        nlatdo = nlat;
    }
    /* ..................................................................... */
    /* --------------------------------------------------------------------- */
    





    /* Check the longitudes of the computational grid */
    /* --------------------------------------------------------------------- */
    /* Check whether the first elements of "lon1" and "lon2" are the smallest 
     * one. Otherwise, the execution of the code is terminated. */
    double lon0 = lon1[0];
    if (fabs(lon0 - arr_min_dp(lon1, nlon)) > THRESHOLD)
    {
        printf("\n[sh_surf_synthesis_mean_dp.c says:] The first element of the "
               "longitude vector \"lon1\" has to be the smallest one. "
               "Terminating the code.\n");
        exit(EXIT_FAILURE);
    }
    lon0 = lon2[0];
    if (fabs(lon0 - arr_min_dp(lon2, nlon)) > THRESHOLD)
    {
        printf("\n[sh_surf_synthesis_mean_dp.c says:] The first element of the "
               "longitude vector \"lon2\" has to be the smallest one. "
               "Terminating the code.\n");
        exit(EXIT_FAILURE);
    }


    /* Useful substitution */
    double *lon = (double *)arr_calloc(nlon, sizeof(double));
    for (size_t j = 0; j < nlon; j++)
    {
        lon[j] =(lon1[j] + lon2[j]) / 2.0; 
    }


    /* Get the origin of the longitude "lon" array (will be necessary later for 
     * the PSLR algorithm) */
    lon0 = lon[0];

    
    /* Get the lon step of the grid (will be necessary later for the PSLR 
     * algorithm) */
    double dlon;
    if (nlon > 1)
    {
        if (fabs((lon1[1] - lon1[0]) - (lon2[1] - lon2[0])) > THRESHOLD)
        {
             printf("\n[sh_surf_synthesis_mean_dp.c says:] The difference "
                    "\"lon1[1] - lon1[0]\" has to be equal to "
                    "\"lon2[1] - lon2[0]\". Terminating the code.\n");
             exit(EXIT_FAILURE);
        }
        dlon = lon1[1] - lon1[0];
    }
    else
    {
        dlon = 0.0;
    }


    /* Check whether the longitude step is constant for the entire "lon1" and 
     * "lon2" vectors. Otherwise, the execution of the code is terminated. */
    double dlonchck;
    for (size_t j = 1; j < nlon; j++)
    {
        dlonchck = lon1[j] - lon1[j - 1];
        if (fabs(dlon - dlonchck) > THRESHOLD)
        {
            printf("\n[sh_surf_synthesis_mean_dp.c says:] The longitudinal "
                   "step of \"lon1\" has to be constant. "
                   "Terminating the code.\n");
            exit(EXIT_FAILURE);
        }


        dlonchck = lon2[j] - lon2[j - 1];
        if (fabs(dlon - dlonchck) > THRESHOLD)
        {
            printf("\n[sh_surf_synthesis_mean_dp.c says:] The longitudinal "
                   "step of \"lon2\" has to be constant. "
                   "Terminating the code.\n");
            exit(EXIT_FAILURE);
        }
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute Legendre 
     * functions. */
    /* --------------------------------------------------------------------- */
    double w;
    double *r = (double *)arr_calloc(2 * nmax + 4, sizeof(double));
    double *ri = (double *)arr_calloc(2 * nmax + 4, sizeof(double));

    r[0]  = 0.0;
    ri[0] = 0.0;
    for (unsigned int m = 1; m <= (2 * nmax + 3); m++)
    {
        w = sqrt((double)m);
        r[m] = w;
        ri[m] = 1.0 / w;
    }


    /* Coefficients "dn" for recurrence relations to compute fully-normalized 
     * Legendre functions */
    double *dn = (double *)arr_calloc(nmax + 1, sizeof(double));
    dn[0] = 0.0;
    for (unsigned int n = 1; n <= nmax; n++)
    {
        dn[n] = r[2 * n + 3] * ri[2 * n + 2];
    }


    /* Coefficients "en" and "fn" for recurrence relations to compute 
     * *un-normalized* Legendre polynomials. (Note that to compute integrals of 
     * fully-normalized Legendre polynomials, we need un-normalized Legendre 
     * polynomials; see, e.g., Eq. B.24 of Jekeli et al. 2007) */
    double *en = (double *)arr_calloc(nmax + 2, sizeof(double));
    double *fn = (double *)arr_calloc(nmax + 2, sizeof(double));

    for (unsigned int n = 2; n < nmax + 2; n++)
    {
        en[n] = (double)(2 * n - 1) / (double)n;
        fn[n] = (double)(n - 1) / (double)n;
    }
    /* --------------------------------------------------------------------- */






    /* Initializations for recurrence relations to compute integrals of 
     * fully-normalized Legendre functions */
    /* --------------------------------------------------------------------- */
    /* Computation of "gn" coefficients */
    double *gn = (double *)arr_calloc(nmax + 1, sizeof(double));
    for (unsigned int n = 3; n < (nmax + 1); n++)
    {
        gn[n] = 1.0 / (double)(2 * n + 2) * r[n] * r[2 * n + 1]
              * r[2 * n - 1] * ri[n - 1];
    }


    /* Computation of "hn" coefficients */
    double *hn = (double *)arr_calloc(nmax + 1, sizeof(double));
    for (unsigned int n = 0; n < (nmax + 1); n++)
    {
        hn[n] = (double)(n - 2) / (double)(n + 1);
    }
    /* --------------------------------------------------------------------- */






    /* Initialize the output signal matrix "f" with zeros */
    /* --------------------------------------------------------------------- */
    for (size_t i = 0; i < nlat; i++)
    {
        for (size_t j = 0; j < nlon; j++)
        {
            f[i * nlon + j] = 0.0;
        }
    }
    /* --------------------------------------------------------------------- */






    /* Loop over grid latitudes */
    /* --------------------------------------------------------------------- */
    #pragma omp parallel default(none) \
    shared(f, cnm, snm, nmax, lat1, lat2, dn, en, fn, gn, hn, r, ri) \
    shared(nlatdo, nlat, nlon, lon0, dlon, even, symm, w)
    {

        int *ips1   = (int *)arr_calloc(nmax, sizeof(int));
        int *ips2   = (int *)arr_calloc(nmax, sizeof(int));
        double *ps1 = (double *)arr_calloc(nmax, sizeof(double));
        double *ps2 = (double *)arr_calloc(nmax, sizeof(double));
        double *am  = (double *)arr_calloc(nmax + 1, sizeof(double));
        double *bm  = (double *)arr_calloc(nmax, sizeof(double));
        double *fi  = (double *)arr_calloc(nlon, sizeof(double));
        double *fi2 = (double *)arr_calloc(nlon, sizeof(double));

        double lat1i, lat2i;
        double t1, u1, x1, y1, z1;
        double t2, u2, x2, y2, z2;
        int ix1, iy1, iz1, ixy1;
        int ix2, iy2, iz2, ixy2;
        double pnm0_lat1i, pnm1_lat1i, pnm2_lat1i;
        double pnm0_lat2i, pnm1_lat2i, pnm2_lat2i;

        double a, b, a2, b2;
        double inmcsa, inmcsb, in0, inm0, inm1, inm2, imm0, imm1, imm2;
        double lontmp, clontmp, slontmp, dm0, dm1, dm2, dm02, dm12, dm22;
        double m2, m2sm2dl, cmdlon2;
        double dsigma;

        _Bool symmi;


        #pragma omp for
        for (size_t i = 0; i < nlatdo; i++)
        {

            /* Check whether the symmetry property of LFs needs to be exploited 
             * */
            /* ------------------------------------------------------------- */
            if (nlat == 1) /* There is only a single latitude parallel in the
                            * grid, so no symmetry property */
            {
                symmi = 0;
            }
            else if (symm == 0) /* The grid was already classified as
                                 * non-symmetric */
            {
                symmi = 0;
            }
            else if (symm == 1 && even == 0 && i == (nlatdo - 1))
            {
                symmi = 0; /* For a symmetric grid containing the equator, this
                            * ensures that the points on the equator will not 
                            * be processed twice */
            }
            else
            {
                symmi = 1; /* Exploit the symmetry property */
            }

            /* ------------------------------------------------------------- */


            /* Some pre-computations for Legendre functions */
            /* ------------------------------------------------------------- */
            /* lat1[i] */
            /* ............................................................. */
            lat1i = lat1[i];
            t1  = sin(lat1i);
            u1  = cos(lat1i);
            x1  = ROOT3 * u1;
            ix1 = 0;

             ps1[0] = x1;
            ips1[0] = ix1;


            for (unsigned n = 1; n < nmax; n++)
            {
                x1 = (dn[n] * u1) * x1;
                y1 = fabs(x1);

                if (y1 >= BIGS)
                {
                     x1 *= BIGI;
                    ix1 += 1;
                }
                else if (y1 < BIGSI)
                {
                     x1 *= BIG;
                    ix1 -= 1;
                }

                 ps1[n] = x1;
                ips1[n] = ix1;
            }
            /* ............................................................. */


            /* lat2[i] */
            /* ............................................................. */
            lat2i = lat2[i];
            t2  = sin(lat2i);
            u2  = cos(lat2i);
            x2  = ROOT3 * u2;
            ix2 = 0;

             ps2[0] = x2;
            ips2[0] = ix2;


            for (unsigned int n = 1; n < nmax; n++)
            {
                x2 = (dn[n] * u2) * x2;
                y2 = fabs(x2);

                if (y2 >= BIGS)
                {
                     x2 *= BIGI;
                    ix2 += 1;
                }
                else if (y2 < BIGSI)
                {
                     x2 *= BIG;
                    ix2 -= 1;
                }

                 ps2[n] = x2;
                ips2[n] = ix2;
            }
            /* ............................................................. */
            /* ------------------------------------------------------------- */


            /* The "fi" vector represents the synthesized quantity "f" for the 
             * ith latitude parallel. Therefore, it needs to be reinitialized 
             * to zero for each "ith" latitude. The same holds true for 
             * "fi2". */
            for (size_t j = 0; j < nlon; j++)
            {
                fi[j]  = 0.0;
                fi2[j] = 0.0;
            }


            /* Loop over harmonic orders */
            /* ------------------------------------------------------------- */
            for (unsigned int m = 0; m <= nmax; m++)
            {

                /* Computation of "am" and "bm" coefficients for Legendre 
                 * recurrence relations */
                /* --------------------------------------------------------- */
                am[m] = r[2 * m + 3];
                for (unsigned int n = (m + 2); n <= nmax; n++)
                {
                    w         = r[2 * n + 1] * ri[n - m] * ri[n + m];
                    am[n - 1] = r[2 * n - 1] * w;
                    bm[n - 1] = r[n - m - 1] * r[n + m - 1] * ri[2 * n - 3]
                                * w;
                }
                /* --------------------------------------------------------- */


                /* Computation of the lumped coefficients */
                if (m == 0)
                {






                    /* Zonal Legendre functions and their integrals */
                    /* ----------------------------------------------------- */
                    /* P00 */
                    /* ..................................................... */
                    pnm0_lat1i = 1.0;
                    pnm0_lat2i = 1.0;
                    /* ..................................................... */


                    /* P10 */
                    /* ..................................................... */
                    pnm1_lat1i = t1;
                    pnm1_lat2i = t2;
                    /* ..................................................... */


                    /* I00 */
                    /* ..................................................... */
                    in0 = t2 - t1;
                    /* ..................................................... */


                    /* Lumped coefficients */
                    /* ..................................................... */
                    a = in0 * cnm[0][0];
                    b = 0.0;

                    if (symmi == 1)
                    {
                        a2 = a;
                        b2 = 0.0;
                    }
                    /* ..................................................... */



                    if ((nmax + 1) >= 2)
                    {
                        for (unsigned int n = 1; n <= nmax; n++)
                        {
                            /* P20, P30, ..., Pnmax+1,0
                             * Since we use locally the "n" variable to compute  
                             * Legendre polynomials of degree "n + 1", the "n + 
                             * 1"th elements have to be taken from the vectors 
                             * "en" and "fn" below. Once again, note that when 
                             * "m == 0", then "pnm0", "pnm1" and "pnm2" for 
                             * lat1i and lat2i represent un-normalized Legendre 
                             * polynomials. These are needed to get the 
                             * integrals of fully-normalized Legendre 
                             * polynomials */
                            /* ............................................. */
                            pnm2_lat1i = en[n + 1] * t1 * pnm1_lat1i
                                       - fn[n + 1] * pnm0_lat1i;
                            pnm2_lat2i = en[n + 1] * t2 * pnm1_lat2i
                                       - fn[n + 1] * pnm0_lat2i;
                            /* ............................................. */


                            /* I10, I20, ..., Inmax,0
                             * Computed from Pn+1,0 and Pn-1,0 */
                            /* ............................................. */
                            in0 = ri[2 * n + 1] * (pnm2_lat2i - pnm0_lat2i -
                                                   pnm2_lat1i + pnm0_lat1i);
                            /* ............................................. */


                            /* Lumped coefficients */
                            /* ............................................. */
                            inmcsa = in0 * cnm[0][n];
                            a     += inmcsa;

                            if (symmi == 1)
                            {
                                if ((n % 2) == 0)
                                {
                                    a2 += inmcsa;
                                }
                                else
                                {
                                    a2 -= inmcsa;
                                }
                            }
                            /* ............................................. */


                            pnm0_lat1i = pnm1_lat1i;
                            pnm1_lat1i = pnm2_lat1i;


                            pnm0_lat2i = pnm1_lat2i;
                            pnm1_lat2i = pnm2_lat2i;

                        }
                    }
                    /* ----------------------------------------------------- */







                }
                else /* Non-zonal harmonics */
                {







                    /* Sectorial Legendre functions and their integrals */
                    /* ----------------------------------------------------- */

                    /* Pmm for lat1i */
                    /* ..................................................... */
                    x1 = ps1[m - 1];
                    ix1 = ips1[m - 1];

                    if (ix1 == 0)
                    {
                        pnm0_lat1i = x1;
                    }
                    else if (ix1 < -1)
                    {
                        pnm0_lat1i = 0.0;
                    }
                    else if (ix1 < 0)
                    {
                        pnm0_lat1i = x1 * BIGI;
                    }
                    else
                    {
                        pnm0_lat1i = x1 * BIG;
                    }
                    /* ..................................................... */


                    /* Pmm for lat2i */
                    /* ..................................................... */
                    x2 = ps2[m - 1];
                    ix2 = ips2[m - 1];

                    if (ix2 == 0)
                    {
                        pnm0_lat2i = x2;
                    }
                    else if (ix2 < -1)
                    {
                        pnm0_lat2i = 0.0;
                    }
                    else if (ix2 < 0)
                    {
                        pnm0_lat2i = x2 * BIGI;
                    }
                    else
                    {
                        pnm0_lat2i = x2 * BIG;
                    }
                    /* ..................................................... */


                    /* Imm */
                    /* ..................................................... */
                    if (m == 1) /* I11 */
                    {
                        imm0 = sqrt(3.0) / 2.0 *
                              ((t2 * u2 - (M_PI_2 - lat2i)) -
                               (t1 * u1 - (M_PI_2 - lat1i)));
                        inm0 = imm0;
                    }
                    else if (m == 2) /* I22 */
                    {
                        imm1 = sqrt(15.0) / 6.0 * (t2 * (3.0 - t2 * t2) -
                                                     t1 * (3.0 - t1 * t1));
                        inm0 = imm1;
                    }
                    else /* I33, I44, ..., Inmax,nmax */
                    {
                        imm2 = gn[m] * imm0 + 1.0 / (double)(m + 1) *
                               (t2 * pnm0_lat2i - t1 * pnm0_lat1i);
                        inm0 = imm2;

                        imm0 = imm1;
                        imm1 = imm2;
                    }
                    /* ..................................................... */


                    /* Lumped coefficients */
                    /* ..................................................... */
                    a = inm0 * cnm[m][0];
                    b = inm0 * snm[m][0];

                    if (symmi == 1)
                    {
                        a2 = a;
                        b2 = b;
                    }
                    /* ..................................................... */
                    /* ----------------------------------------------------- */






                    /* Tesseral harmonics */
                    /* ----------------------------------------------------- */
                    if (m < nmax)
                    {

                        /* Pm+1,m for lat1i */
                        /* ................................................. */
                         y1 =  x1;
                        iy1 = ix1;
                         x1 = (am[m] * t1) * y1;
                        ix1 = iy1;

                        w = fabs(x1);
                        if (w >= BIGS)
                        {
                             x1 *= BIGI;
                            ix1 += 1;
                        }
                        else if (w < BIGSI)
                        {
                             x1 *= BIG;
                            ix1 -= 1;
                        }

                        /* Pm+1,m */
                        if (ix1 == 0)
                        {
                            pnm1_lat1i = x1;
                        }
                        else if (ix1 < -1)
                        {
                            pnm1_lat1i = 0.0;
                        }
                        else if (ix1 < 0)
                        {
                            pnm1_lat1i = x1 * BIGI;
                        }
                        else
                        {
                            pnm1_lat1i = x1 * BIG;
                        }
                        /* ................................................. */


                        /* Pm+1,m for lat2i */
                        /* ................................................. */
                         y2 =  x2;
                        iy2 = ix2;
                         x2 = (am[m] * t2) * y2;
                        ix2 = iy2;

                        w = fabs(x2);
                        if (w >= BIGS)
                        {
                             x2 *= BIGI;
                            ix2 += 1;
                        }
                        else if (w < BIGSI)
                        {
                             x2 *= BIG;
                            ix2 -= 1;
                        }

                        /* Pm+1,m */
                        if (ix2 == 0)
                        {
                            pnm1_lat2i = x2;
                        }
                        else if (ix2 < -1)
                        {
                            pnm1_lat2i = 0.0;
                        }
                        else if (ix2 < 0)
                        {
                            pnm1_lat2i = x2 * BIGI;
                        }
                        else
                        {
                            pnm1_lat2i = x2 * BIG;
                        }
                        /* ................................................. */


                        /* Im+1,m */
                        /* ................................................. */
                        /* This is not a typo, "pnm0" are indeed required here 
                         * */
                        inm1 = -am[m] / (double)(m + 2) *
                                (u2 * u2 * pnm0_lat2i - u1 * u1 * pnm0_lat1i);
                        /* ................................................. */


                        /* Lumped coefficients */
                        /* ................................................. */
                        inmcsa = inm1 * cnm[m][1];
                        inmcsb = inm1 * snm[m][1];

                        a += inmcsa;
                        b += inmcsb;

                        if (symmi == 1)
                        {
                            a2 -= inmcsa;
                            b2 -= inmcsb;
                        }
                        /* ................................................. */


                        /* Pm+2,m, Pm+3,m, ..., Pnmax,m and their integrals */
                        /* ................................................. */
                        for (unsigned int n = (m + 2); n <= nmax; n++)
                        {
                            
                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m for lat1i */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            ixy1 = ix1 - iy1;

                            if (ixy1 == 0)
                            {
                                 z1 = (am[n - 1] * t1) * x1 - bm[n - 1] * y1;
                                iz1 = ix1;
                            }
                            else if (ixy1 == 1)
                            {
                                 z1 = (am[n - 1] * t1) * x1 - bm[n - 1] 
                                                            * (y1 * BIGI);
                                iz1 = ix1;
                            }
                            else if (ixy1 == -1)
                            {
                                 z1 = (am[n - 1] * t1) * (x1 * BIGI) \
                                     - bm[n - 1] * y1;
                                iz1 = iy1;
                            }
                            else if (ixy1 > 1)
                            {
                                 z1 = (am[n - 1] * t1) * x1;
                                iz1 = ix1;
                            }
                            else
                            {
                                 z1 = -bm[n - 1] * y1;
                                iz1 = iy1;
                            }

                            w = fabs(z1);
                            if (w >= BIGS)
                            {
                                 z1 *= BIGI;
                                iz1 += 1;
                            }
                            else if (w < BIGSI)
                            {
                                 z1 *= BIG;
                                iz1 -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz1 == 0)
                            {
                                pnm2_lat1i = z1;
                            }
                            else if (iz1 < -1)
                            {
                                pnm2_lat1i = 0.0;
                            }
                            else if (iz1 < 0)
                            {
                                pnm2_lat1i = z1 * BIGI;
                            }
                            else
                            {
                                pnm2_lat1i = z1 * BIG;
                            }

                             y1 =  x1;
                            iy1 = ix1;
                             x1 =  z1;
                            ix1 = iz1;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m for lat2i */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            ixy2 = ix2 - iy2;

                            if (ixy2 == 0)
                            {
                                 z2 = (am[n - 1] * t2) * x2 - bm[n - 1] * y2;
                                iz2 = ix2;
                            }
                            else if (ixy2 == 1)
                            {
                                 z2 = (am[n - 1] * t2) * x2 - bm[n - 1] 
                                                            * (y2 * BIGI);
                                iz2 = ix2;
                            }
                            else if (ixy2 == -1)
                            {
                                 z2 = (am[n - 1] * t2) * (x2 * BIGI) \
                                     - bm[n - 1] * y2;
                                iz2 = iy2;
                            }
                            else if (ixy2 > 1)
                            {
                                 z2 = (am[n - 1] * t2) * x2;
                                iz2 = ix2;
                            }
                            else
                            {
                                 z2 = -bm[n - 1] * y2;
                                iz2 = iy2;
                            }

                            w = fabs(z2);
                            if (w >= BIGS)
                            {
                                 z2 *= BIGI;
                                iz2 += 1;
                            }
                            else if (w < BIGSI)
                            {
                                 z2 *= BIG;
                                iz2 -= 1;
                            }

                            /* Pm+2,m, Pm+3,m, ..., Pnmax,m */
                            if (iz2 == 0)
                            {
                                pnm2_lat2i = z2;
                            }
                            else if (iz2 < -1)
                            {
                                pnm2_lat2i = 0.0;
                            }
                            else if (iz2 < 0)
                            {
                                pnm2_lat2i = z2 * BIGI;
                            }
                            else
                            {
                                pnm2_lat2i = z2 * BIG;
                            }

                             y2 =  x2;
                            iy2 = ix2;
                             x2 =  z2;
                            ix2 = iz2;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Im+2,m, Im+3,m, ..., Inmax,m */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            /* This is not a typo, "pnm1" are indeed required 
                             * here */
                            inm2 = hn[n] * bm[n - 1] * inm0 -
                                   am[n - 1] / (double)(n + 1) *
                                   (u2 * u2 * pnm1_lat2i - 
                                    u1 * u1 * pnm1_lat1i);

                            inm0 = inm1;
                            inm1 = inm2;
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            /* Lumped coefficients */
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */
                            inmcsa = inm2 * cnm[m][n - m];
                            inmcsb = inm2 * snm[m][n - m];

                            a += inmcsa;
                            b += inmcsb;

                            if (symmi == 1)
                            {
                                if (((n + m) % 2) == 0)
                                {
                                    a2 += inmcsa;
                                    b2 += inmcsb;
                                }
                                else
                                {
                                    a2 -= inmcsa;
                                    b2 -= inmcsb;
                                }
                            }
                            /* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


                            pnm1_lat1i = pnm2_lat1i;
                            pnm1_lat2i = pnm2_lat2i;

                        } /* End of the loop over harmonic degrees */
                        /* ................................................. */

                    } /* End of computation of tesseral harmonics */
                    /* ----------------------------------------------------- */

                } /* End of computation of the lumped coefficients */
                /* --------------------------------------------------------- */

            
                /* Before applying the PSLR algorithm from Balmino et 
                 * al. (2012), * the lumped coefficients need to be multiplied 
                 * by additional terms, which stem from the integration in the 
                 * longitudinal direction */
                /* --------------------------------------------------------- */
                if (m == 0)
                {
                    m2sm2dl = dlon;
                }
                else
                {
                    m2 = 2.0 / (double)m;
                    m2sm2dl = m2 * sin(dlon / m2);
                }

                a *= m2sm2dl;
                b *= m2sm2dl; /* Remember that "b = 0.0" for "m == 0", so it
                               * can safely be multiplied by "m2sm2dl = dlon" 
                               * */

                if (symmi == 1)
                {
                    a2 *= m2sm2dl;
                    b2 *= m2sm2dl;  /* Remember that "b = 0.0" for "m == 0",
                                     * so it can safely be multiplied by 
                                     * "m2sm2dl = dlon" */
                }
                /* --------------------------------------------------------- */



                /* The PSLR algorithm from Balmino et al. (2012) (see the 
                 * REFERENCES section at the beginning of this function) */
                /* --------------------------------------------------------- */

                /* The first longitude from the "lon" vector */
                /* ......................................................... */
                 lontmp = (double)m * lon0;
                clontmp = cos(lontmp);
                slontmp = sin(lontmp);
                dm0     = a * clontmp + b * slontmp;
                fi[0]  += dm0;
                 
                if (symmi == 1)
                {
                    dm02    = a2 * clontmp + b2 * slontmp;
                    fi2[0] += dm02;
                }
                /* ......................................................... */

               
                /* The second longitude from the "lon" vector */
                /* ......................................................... */
                if (nlon > 1)
                {
                     lontmp = (double)m * (lon0 + dlon);
                    clontmp = cos(lontmp);
                    slontmp = sin(lontmp);
                    dm1     = a * clontmp + b * slontmp;
                    fi[1]  += dm1;

                    if (symmi == 1)
                    {
                        dm12    = a2 * clontmp + b2 * slontmp;
                        fi2[1] += dm12;
                    }
                }
                /* ......................................................... */
                

                /* The third and all the remaining longitudes from the "lon" 
                 * vector */
                /* ......................................................... */
                cmdlon2 = 2.0 * cos((double)m * dlon);
                for (size_t j = 2; j < nlon; j++)
                {
                    dm2    = cmdlon2 * dm1 - dm0;
                    fi[j] += dm2;
                    dm0    = dm1;
                    dm1    = dm2;

                    if (symmi == 1)
                    {
                        dm22    = cmdlon2 * dm12 - dm02;
                        fi2[j] += dm22;
                        dm02    = dm12;
                        dm12    = dm22;
                    }
                }
                /* ......................................................... */
                /* --------------------------------------------------------- */
                /* End of the PSLR algorithm */

            } /* End of the loop over harmonic orders */
            /* ------------------------------------------------------------- */


            /* Synthesis */
            /* ------------------------------------------------------------- */
            /* Area of the cell on the unit sphere */
            dsigma = (sin(lat2i) - sin(lat1i)) * dlon;

            for (size_t j = 0; j < nlon; j++)
            {
                f[i * nlon + j] += fi[j] / dsigma;
            }

            if (symmi == 1) /* The other hemisphere computed using the symmetry
                             * property of Legendre functions with respect to 
                             * the equator */
            {
                for (size_t j = 0; j < nlon; j++)
                {
                    f[(nlat - i - 1) * nlon + j] += fi2[j] / dsigma;
                }
            }
            /* ------------------------------------------------------------- */


        } /* End of the loop over latitude parallels */
        /* ----------------------------------------------------------------- */

        free(ips1); free(ps1);
        free(ips2); free(ps2);
        free(am); free(bm); free(fi); free(fi2);

    } /* End of "#pragma omp parallel" */
    /* --------------------------------------------------------------------- */






    /* Freeing up the heap memory */
    /* --------------------------------------------------------------------- */
    free(r); free(ri); free(dn); free(en); free(fn); free(gn); free(hn);
    /* --------------------------------------------------------------------- */
    





    return;

}
