%This script tests the "Surface_SHS" function (non-parallel computation).

clear
clc

%Input parameters
%==========================================================================
SHCs_path='../../data/Earth2014.RET2014.degree360.mat'; %Path to the file 
                                                        %with the input
                                                        %spherical harmonic
                                                        %coefficients

nmax_signal=360; %Maximum degree of the used input signal from the "SHCs_path" file
nmax_SHA=360; %Maximum degree of the recovered coefficients
%========================================================================== 


%Spherical harmonic analysis via the "Surface_SHS" function
%========================================================================== 
fprintf('Starting the computation... (%s)\n',datestr(clock))

%Computation of the Gauss--Legendre grid nodes
fprintf('Computing Gauss--Legendre grid nodes... (%s)\n',datestr(clock))
[lat,lon,w]=GL_grid(nmax_signal);

%Surface spherical harmonic synthesis using the input SHCs (the "SHCs_path" variable)
%It generates grid that will later be harmonically analyzed.
fprintf('Surface spherical harmonic synthesis... (%s)\n',datestr(clock))
H=Surface_SHS(lat,lon,nmax_signal,SHCs_path);

%Surface spherical harmonic analysis of the grid
fprintf('Spherical harmonic analysis... (%s)\n',datestr(clock))
[degree,order,Cnm,Snm]=Surface_SHA(lat,w,H,nmax_signal,nmax_SHA);

%Compare some output coefficients with the original ones
load(SHCs_path)
SHCs=sortrows(SHCs,2);

fprintf('\n')
fprintf('Some randomly selected coefficients from the original set of coefficients [Cnm Snm]...\n')
[SHCs(365,3) SHCs(365,4)]
[SHCs(end,3) SHCs(end,4)]

fprintf('The recovered coefficients of the same degrees and orders [Cnm Snm]...\n')
[Cnm(365) Snm(365)]
[Cnm(end) Snm(end)]
fprintf('\n')

fprintf('Testing the "Surface_SHA" function succesfully finished... (%s)\n',datestr(clock))
%========================================================================== 
