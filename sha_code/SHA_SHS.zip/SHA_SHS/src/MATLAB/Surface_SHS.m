function H=Surface_SHS(lat,lon,nmax,SHCs_path)
%==========================================================================
%DESCRIPTION: This function performs surface spherical harmonic synthesis
%             at a grid defined by the vectors of latitudes and longitudes via
%             a FFT-based algorithm (Sneeuw, 1994).
%
%             The 4*pi fully-normalized associated Legendre functions
%             (e.g., Heiskannen and Moritz, 1967) are evaluated by the 
%             numerically stable algorithm by Fukushima (2012). The algorithm 
%             can be used up to ultra-high harmonic degrees (say, tens of
%             thousands or even well beyond). Unlike "Surface_SHA.m" and
%             "Surface_SHA_sliced.m", this function does not take advantage of
%             of the symmetry property of Legendre functions with respect
%             to the equator. As a result, the synthesis with this package
%             is slower than the analysis when using the same maximum
%             degree. For a more efficient implementation of the synthesis
%             in MATLAB, GrafLab (Bucha and Janak, 2013) can be employed, 
%             as it exploits the symmetry property of Legendre functions.
%
%INPUTS: "lat"       -- Column vector defining latitudes of the grid
%                       in radians (latitudes over a single meridian).
%        "lon"       -- Column vector defining longitudes of the grid
%                       in radians (longitudes over a single latitude parallel).
%        "nmax"      -- Maximum spherical harmonic degree of the synthesis 
%                       (Non-negative integer).
%        "SHCs_path" -- Absolute or relative path to a mat-file with the
%                       spherical harmonic coefficients.
%                       The file must have the structure as defined either by
%                       Table 1 or by Table 2:
%
%                       Table 1: Structure of the input GGM file - spherical harmonic 
%                       coefficients sorted primarily according to degrees.
%                       ----------------------------------------
%                         n   m       C_nm           S_nm
%                       ----------------------------------------
%                         0   0    1.00000E+00    0.00000E+00
%                         1   0    0.00000E+00    0.00000E+00
%                         1   1    0.00000E+00    0.00000E+00
%                         2   0   -0.48417E-03    0.00000E+00
%                         2   1   -0.20662E-09    0.13844E-08
%                         2   2    0.24394E-05   -0.14003E-05
%                         3   0    0.95716E-06    0.00000E+00
%                         .   .         .              .
%                         .   .         .              .
%                         .   .         .              .
%                       ----------------------------------------
%
%                       Table 2: Structure of the input GGM file - spherical harmonic 
%                       coefficients sorted primarily according to orders.
%                       ----------------------------------------
%                         n   m       C_nm           S_nm
%                       ----------------------------------------
%                         0   0    1.00000E+00    0.00000E+00
%                         1   0    0.00000E+00    0.00000E+00
%                         2   0   -0.48417E-03    0.00000E+00
%                         3   0    0.95712E-06    0.00000E+00
%                         .   .         .              .
%                         .   .         .              .
%                         .   .         .              .
%                         1   1    0.00000E+00    0.00000E+00
%                         2   1   -0.20662E-09    0.13844E-08
%                         .   .         .              .
%                         .   .         .              .
%                         .   .         .              .
%                         2   2    0.24394E-05   -0.14003E-05
%                         .   .         .              .
%                         .   .         .              .
%                         .   .         .              .
%                       ----------------------------------------
%
%OUTPUTS: "H" -- Matrix of the synthesized signal (e.g., topographic heights)
%                Dimension (length(lat),length(lon)).
%
%REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
%               least-squares and numerical quadrature methods in historical perspective.
%               Geophysical Journal International 118:707--716
%
%            Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
%               Freeman and Company, San Francisco, 364 pp
%
%            Fukushima, T. (2012) Numerical computation of spherical
%               harmonics of arbitrary degree and order by extending exponent
%               of floating point numbers. Journal of Geodesy 86:271--285.
%
%            Bucha, B., Janak, J. (2013) A MATLAB-based graphical user
%               interface program for computing functionals of the
%               geopotential up to ultra-high degrees and orders.
%               Computers and Geosciences 56:186--196.
%
%Contact: blazej.bucha@stuba.sk
%
%
%Please use the following reference when using this function:
%
%         Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
%            spectral gravity forward modelling up to the full gravity
%            tensor. Journal of Geodesy 93:1707--1737
%
%==========================================================================


%Import of spherical harmonic coefficients from the mat-file
%==========================================================================
SHCs=load(SHCs_path);
SHCs=struct2cell(SHCs);
SHCs=cell2mat(SHCs);

SHCs=sortrows(SHCs,1);
HC=SHCs(:,3); %C coefficients
HS=SHCs(:,4); %S coefficients
clear SHCs
%==========================================================================


%Initializations
%==========================================================================
length_lat=length(lat); %Total number of latitudes over a single parallel of the grid

A=zeros(length_lat,nmax+1); %Lumped coefficients
B=A;                        %Lumped coefficients

Pnm=zeros(length_lat,nmax+1); %Legendre functions
%==========================================================================


%Indices for spherical harmonic coefficients
%==========================================================================
index=zeros(nmax+1,1);
index(1)=1;
for i=1:nmax
    index(i+1)=index(i)+i;
end
%==========================================================================


%Initialization for the computation of Legendre functions
%==========================================================================
u=cos(lat);
t=sin(lat);

nmax23=nmax*2+3;
rr=zeros(nmax23,1); ri=rr;
dd=zeros(nmax,1); am=dd; bm=am;

m1=1:nmax23;
rr(m1)=sqrt(m1);
ri(m1)=1./rr;
m2=(1:nmax);
dd(m2)=rr(2*m2+3).*ri(2*m2+2);

IND=960;
BIG=2^IND;
BIGI=2^(-IND);
BIGS=2^(IND/2);
BIGSI=2^(-IND/2);
ROOT3=1.732050807568877;

temp1=zeros(length_lat,1);
temp2=ones(length_lat,1);
temp3=temp2;
temp4=temp1;
temp5=temp1+BIGI;
ps1b=zeros(length_lat,nmax); 
ips1b=ps1b;
xb=ROOT3*u;
ixb=zeros(size(xb));
ps1b(:,1)=xb;
ips1b(:,1)=ixb;
for m3=2:nmax
    xb=(dd(m3-1)*u).*xb;
    yb=abs(xb);
    iyb=yb>=BIGS;
    if any(iyb)
        xb(iyb)=xb(iyb)*BIGI;
        ixb(iyb)=ixb(iyb)+1;
    end
    iyb=yb<BIGSI;
    if any(iyb)
        xb(iyb)=xb(iyb)*BIG;
        ixb(iyb)=ixb(iyb)-1;
    end
    ps1b(:,m3)=xb;
    ips1b(:,m3)=ixb;
end
%==========================================================================


%Spherical harmonic synthesis
%==========================================================================
for m=nmax:-1:0

    HCm=HC(index((m+1):end)+m);
    HSm=HS(index((m+1):end)+m);
    
    am(m+1)=rr(2*m+3);
    for n=m+2:nmax
        ww=rr(2*n+1)*ri(n-m)*ri(n+m);
        am(n)=rr(2*n-1)*ww;
        bm(n)=rr(n-m-1)*rr(n+m-1)*ri(2*n-3)*ww;
    end

    if m==0 %Zonal Legendre functions
        Pnm(:,1)=1;
        if nmax>0
            Pnm(:,2)=ROOT3*t;

            for i=2:nmax
                Pnm(:,i+1)=Pnm(:,i).*sqrt((2*i+1)*(2*i-1))./i.*t-Pnm(:,i-1).*(i-1).*sqrt(2.*i+1)./(i.*sqrt(2.*i-3));
            end
        end

        clear rr ri am bm ps1b ips1b m1 m2 dd ...
            ixb xb yb iyb wb izb zzb pmxb pm0b pmxBIGIb ...
            pmxBIGb wb wBIGSb wBIGSIb pm1xb pm10b ...
            pm1xBIGIb pm1xBIGb idb id0b id1b id_1b ...
            idv1b idm1b iz0b izm_1b izm0b izv0b tq temp1...
            temp2 temp3 temp4 temp5

    elseif m~=0 %Non-zonal Legendre functions                                
        xb=ps1b(:,m);
        ixb=ips1b(:,m);
                                           
        temp5(ixb==0)=1;
        temp5(ixb<-1)=0;
        %temp5(izb>=-1 & izb<0)=BIGI;
        %The condition "izb>=-1 & izb<0"
        %is useless, as "izb" is already
        %initialized as "izb=BIGI".
        temp5(ixb>0)=BIG;
               
        Pnm(:,1)=xb.*temp5; %Sectorial Legendre functions
        temp5=temp5.*0+BIGI; 
                                          
        if m<nmax
           yb=xb;
           iyb=ixb;

           xb=(am(m+1).*t).*yb;
           ixb=iyb;
           wb=abs(xb);

           wBIGSb=wb>=BIGS;
           wBIGSIb=wb<BIGSI;
           temp3(wBIGSb)=BIGI;
           temp3(wBIGSIb)=BIG;
           temp4(wBIGSb)=1;
           temp4(wBIGSIb)=-1;

           xb=xb.*temp3;
           ixb=ixb+temp4;
           temp3=temp2;
           temp4=temp4.*0;
           
           temp5(ixb==0)=1;
           temp5(ixb<-1)=0;
           %temp5(izb>=-1 & izb<0)=BIGI;
           %The condition "izb>=-1 & izb<0"
           %is useless, as "izb" is already
           %initialized as "izb=BIGI".
           temp5(ixb>0)=BIG;
               
           Pnm(:,2)=xb.*temp5; %Tesseral Legendre functions
           temp5=temp5.*0+BIGI; 

           for n=m+2:nmax
               idb=ixb-iyb;

               id0b=idb==0;
               id1b=idb==1;
               id_1b=idb==-1;
               idv1b=idb>1;
               
               temp1(id0b)=1;
               temp1(id1b)=1;
               temp2(id1b)=BIGI;
               temp1(id_1b)=BIGI;
               temp1(idv1b)=1;
               temp2(idv1b)=0;
               
               zzb=(am(n).*t).*(xb.*temp1)-bm(n).*((yb).*temp2);
               izb=iyb;
               id0b_id1b_idv1b=id0b | id1b | idv1b;
               izb(id0b_id1b_idv1b)=ixb(id0b_id1b_idv1b);
               temp1=temp1.*0;
               temp2=temp1+1;

               wb=abs(zzb);

               wBIGSb=wb>=BIGS;
               wBIGSIb=wb<BIGSI;
               temp3(wBIGSb)=BIGI;
               temp3(wBIGSIb)=BIG;
               temp4(wBIGSb)=1;
               temp4(wBIGSIb)=-1;

               zzb=zzb.*temp3;
               izb=izb+temp4;
               temp3=temp2;
               temp4=temp4.*0;

               temp5(izb==0)=1;
               temp5(izb<-1)=0;
               %temp5(izb>=-1 & izb<0)=BIGI;
               %The condition "izb>=-1 & izb<0"
               %is useless, as "izb" is already
               %initialized as "izb=BIGI".
               temp5(izb>0)=BIG;
               
               Pnm(:,n-m+1)=zzb.*temp5; %Tesseral Legendre functions
               temp5=temp1+BIGI;   
    
               yb=xb;
               iyb=ixb;
               xb=zzb;
               ixb=izb;
           end   
        end
    end
    
    %Lumped coefficients
    A(:,m+1)=Pnm(:,1:(nmax-m+1))*HCm;
    B(:,m+1)=Pnm(:,1:(nmax-m+1))*HSm;
end

clear rr ri am bm ps1b ips1b m1 m2 dd ixb xb yb iyb wb izb zzb pmxb pm0b pmxBIGIb...
    pmxBIGb wb wBIGSb wBIGSIb pm1xb pm10b pm1xBIGIb pm1xBIGb idb id0b id1b id_1b...
    idv1b idm1b iz0b izm_1b izm0b izv0b tq temp1 temp2 temp3 temp4 temp5
clear HCm HSm HC HS Pnm

temp=([0:nmax]')*lon'; %#ok<NBRAK>
H=A*cos(temp); clear A
H=H+B*sin(temp);
%==========================================================================
