function Surface_SHA_sliced_save(Cnm,Snm,m,output_path)
%==========================================================================
%DESCRIPTION: This function is designed to allow saving files inside the spmd
%             environment
%
%INPUTS: "Cnm", "Snm"  -- Spherical harmonic coefficients of order "m" (see 
%                         below) evaluated inside the "Surface_SHA_sliced" function
%                         See the OUTPUTS section from the "Surface_SHA_sliced"
%                         function for further details.
%        "m"           -- Order of the computed coefficients
%        "output_path" -- Absolute or relative path to the directory, in
%                         which the coefficients are saved
%
%OUTPUTS: This function does not have any output variables
%
%Contact: blazej.bucha@stuba.sk
%
%==========================================================================

save(sprintf('%s/Cnm_Snm_m%d.mat',output_path,m),'Cnm','Snm','-mat','-v6') 
