function [Cnm,Snm]=Surface_SHA_sliced_load(m,output_path) %#ok<STOUT>
%==========================================================================
%DESCRIPTION: This function is designed to allow loading files inside the spmd
%             environment
%
%INPUTS: "m"           -- Order of the computed coefficients
%        "output_path" -- Absolute or relative path to the directory, in
%                         which the coefficients are stored
%
%OUTPUTS: "Cnm", "Snm" -- Spherical harmonic coefficients of order "m".
%                         See the OUTPUTS section from the "Surface_SHA_sliced"
%                         function for further details.
%
%Contact: blazej.bucha@stuba.sk
%
%==========================================================================

load(sprintf('%s/Cnm_Snm_m%d.mat',output_path,m))
