%This script tests the "Surface_SHS_sliced" function (parallel computation).

clear
clc

%Input parameters
%==========================================================================
SHCs_path='../../data/Earth2014.RET2014.degree360.mat'; %Path to the file 
                                                        %with the input
                                                        %spherical harmonic
                                                        %coefficients
nmax_signal=360; %Maximum degree of the used input signal from the "SHCs_path" file
p=1; %Power of the input signal that is to be computed
nmax_SHA=360; %Maximum degree of the recovered coefficients (non-zero coefficients
              %may occur only up to degree "p*nmax_signal")
R=1; %In case of spectral gravity forward modelling, set this variable to the
     %radius of the reference sphere. Otherwise, set "R" to 1.
nlats_max=1000; %Maximum number of latitudes for one hemisphere that will be processed
                %simultaneously.
parallel=1; %0 - serial (non-parallel) computation
            %1 - parallel computation (the parpool session must already be running)
nworkers=4; %If "parallel==1", number of Matlab workers of the current parpool
            %session
            %If "parallel==0", this variable is automatically set to 1.
output_path='Output_SHCs';
%==========================================================================         


%Spherical harmonic analysis via the "Surface_SHS_sliced" function
%==========================================================================
fprintf('Starting the computation... (%s)\n',datestr(clock))

fprintf('Spherical harmonic analysis... (%s)\n',datestr(clock))
Surface_SHA_sliced(SHCs_path,nmax_signal*p,nmax_SHA,p,R,nlats_max,output_path,parallel,nworkers);

%Compare some output coefficients with the original ones
load(SHCs_path)
SHCs=sortrows(SHCs,2);

fprintf('\n')
fprintf('Some randomly selected coefficients from the original set of coefficients [Cnm Snm]...\n')
[SHCs(365,3) SHCs(365,4)]
[SHCs(end,3) SHCs(end,4)]

fprintf('The recovered coefficients of the same degrees and orders [Cnm Snm]...\n')
load(sprintf('%s/Cnm_Snm_m1.mat',output_path))
[Cnm(4) Snm(4)]
load(sprintf('%s/Cnm_Snm_m360.mat',output_path))
[Cnm(end) Snm(end)]
fprintf('\n')

fprintf('Testing the "Surface_SHA_sliced" function succesfully finished... (%s)\n',datestr(clock))
%==========================================================================
