function [lat,lon,w]=GL_grid(nmax)
%==========================================================================
%DESCRIPTION: This function generates latitudes, longitudes and weights of 
%             the grid nodes required by the Gauss--Legendre quadrature 
%             (e.g., Sneeuw, 1994). Note that the grid is non-equiangular 
%             in terms of latitudes. The step in the longitudinal direction
%             is, however, constant.
%
%INPUTS:   "nmax" -- Maximum spherical harmonic degree of the signal that
%                    is to be harmonically analyzed
%
%OUTPUTS:  "lat" -- Vector of spherical latitudes in radians.
%                   Dimension (nmax+1,1).

%          "lon" -- Vector of longitudes in radians.
%                   Dimmension (2*nmax+2,1).

%          "w"   -- Weights given by the Gauss--Legendre quadrature
%                   (dimensionless).
%                   Dimension (nmax+1,1).
%
%The function is based on the "legzo.m" function 
%(https://github.com/Pazus/Legendre-Gauss-Quadrature/blob/master/legzo.m)
%pubslished by Pazus (https://github.com/Pazus). Minor modifications were
%introduced, such that it now yields spherical latitudes and longitude 
%as the output coordinates.
%
%REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
%               least-squares and numerical quadrature methods in historical perspective.
%               Geophysical Journal International 118:707--716
%
%==========================================================================

nmax=nmax+1;

a = -1;
b =  1;

lat = zeros(1, nmax);
w = zeros(1, nmax);
m = (nmax+1)/2;
h = b-a;

for ii=1:m
    z = cos(pi*(ii-.25)/(nmax+.5));
    z1 = z+1;
    while abs(z-z1)>eps
        p1 = 1;
        p2 = 0;
        for jj = 1:nmax
            p3 = p2;
            p2 = p1;
            p1 = ((2*jj-1)*z*p2-(jj-1)*p3)/jj;
        end
        pp = nmax*(z*p1-p2)/(z^2-1);
        z1 = z;
        z = z1-p1/pp;
    end
    lat(ii) = z;
    lat(nmax+1-ii) = -z;
    w(ii) = h/((1-z^2)*(pp^2));
    w(nmax+1-ii) = w(ii);
end

if a ~= -1 || b ~= 1
    lat = (lat+1)*(h/2) + a;
end

lat=asin(lat);
lat=lat(:);
lat=flipud(lat);

lon=(pi*[0:1:(2*nmax-1)]'/nmax);
w=w(:);
