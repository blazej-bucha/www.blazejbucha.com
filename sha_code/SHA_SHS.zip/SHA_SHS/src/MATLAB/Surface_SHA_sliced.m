function Surface_SHA_sliced(signal_path,nmax_signal,nmax_SHA,p,R,nlats_max,output_SHCs_path,parallel,nworkers)
%==========================================================================
%DESCRIPTION: This function computes spherical harmonic coefficients of the
%             pth power of the input signal via the exact FFT-based 
%             Gauss--Legendre quadrature (Sneeuw, 1994). The function is
%             specifically designed to harmonically analyze the pth power of
%             a function that is expressed as a surface spherical harmonic
%             expansion over the sphere. The maximum degree of the original 
%             function ("nmax_signal/p", see below) is not limited, but is 
%             intended to be, say, 2160 (or a few thousands above, depending 
%             on the available RAM). However, the maximum degree of the
%             recovered coefficients ("nmax_SHA", see below) may be as large as 54,000
%             in case of HPC clusters.
%
%             The 4*pi fully-normalized associated Legendre functions
%             (e.g., Heiskannen and Moritz, 1967) are evaluated by the 
%             numerically stable algorithm by Fukushima (2012). The algorithm 
%             can be used up to ultra-high harmonic degrees (say, tens of
%             thousands or even well beyond).
%
%             The signal to be analyzed is here represented in the spectral
%             domain by its spherical harmonic coefficients, as
%             opposed to the "Surface_SHA" function, which relies on the input
%             signal represented in the spatial domain over the sphere. As
%             its main benefit, this function significanly lowers the RAM
%             requirements, because neither the entire input signal nor the
%             entire output spherical harmonic coefficients are stored in RAM
%             during the computation. The same holds true for Legendre
%             functions. However, because of this, the computation is
%             noticeably slower. The function is designed for
%             ultra-high-degree harmonic analysis that can be performed
%             without the need for tens or even more GBs of RAM.
%             It can be used for computations on clusters, where
%             a limited amount of RAM is usually available for each CPU, say,
%             4 GB or so.
%             The function exploits the symmetry propery of Legendre functions 
%             with respect to the equator, thereby improving its performance,
%             especially for ultra-high-degree harmonic analysis.
%
%INPUTS: "signal_path" -- Absolute or relative path to a mat-file with the
%                         spherical harmonic coefficients of the input signal.
%                         The file must have the structure as defined either by
%                         Table 1 or by Table 2:
%
%                         Table 1: Structure of the input GGM file - spherical harmonic 
%                         coefficients sorted primarily according to degrees.
%                         ----------------------------------------
%                           n   m       C_nm           S_nm
%                         ----------------------------------------
%                           0   0    1.00000E+00    0.00000E+00
%                           1   0    0.00000E+00    0.00000E+00
%                           1   1    0.00000E+00    0.00000E+00
%                           2   0   -0.48417E-03    0.00000E+00
%                           2   1   -0.20662E-09    0.13844E-08
%                           2   2    0.24394E-05   -0.14003E-05
%                           3   0    0.95716E-06    0.00000E+00
%                           .   .         .              .
%                           .   .         .              .
%                           .   .         .              .
%                         ----------------------------------------
%
%                         Table 2: Structure of the input GGM file - spherical harmonic 
%                         coefficients sorted primarily according to orders.
%                         ----------------------------------------
%                           n   m       C_nm           S_nm
%                         ----------------------------------------
%                           0   0    1.00000E+00    0.00000E+00
%                           1   0    0.00000E+00    0.00000E+00
%                           2   0   -0.48417E-03    0.00000E+00
%                           3   0    0.95712E-06    0.00000E+00
%                           .   .         .              .
%                           .   .         .              .
%                           .   .         .              .
%                           1   1    0.00000E+00    0.00000E+00
%                           2   1   -0.20662E-09    0.13844E-08
%                           .   .         .              .
%                           .   .         .              .
%                           .   .         .              .
%                           2   2    0.24394E-05   -0.14003E-05
%                           .   .         .              .
%                           .   .         .              .
%                           .   .         .              .
%                         ----------------------------------------
%
%        "nmax_signal" -- Maximum harmonic degree that is present in the
%                         harmonically analyzed signal.
%
%        "nmax_SHA"    -- Maximum harmonic degree of the output spherical
%                         harmonic coefficients. This value cannot be larger
%                         that "nmax_signal". Note that if
%                         "nmax_SHA<nmax_signal", the output coefficients
%                         are still computed exactly, because the matrix
%                         "signal" is sampled correctly according to the
%                         maximum degree that is present in the signal, here
%                         "nmax_signal".
%
%        "p"           -- Power of the input signal. Positive integer.
%
%        "R"           -- In case of spectral gravity forward modelling,
%                         this variable represents the radius of the
%                         reference topography to which the topography
%                         refers.
%                         For other cases, set this variable to 1.
%
%        "nlats_max"   -- The maximum number of latitudes in the
%                         latitudinal band over one hemisphere. This
%                         variable can be used to control the amount of RAM
%                         that is necessary for the computation. For
%                         instance, in case of ultra-high-degree harmonic
%                         analysis, tens or even more GBs of RAM may be
%                         needed. Setting this variable to, say, 100
%                         significantly lowers the required amount of RAM,
%                         even down to hundreds of MBs or so. Naturally, the
%                         smaller the number, the larger the computation time
%                         is observed. However, after some trial-and-error, a
%                         good compromise can usually be found, such that
%                         the computation is fast enough and at the same time
%                         it can be accomplished within the limits of one's
%                         available amount of RAM.
%                         Note that this variable denotes the maximum
%                         number of latitudes per latitudinal band over one
%                         hemisphere only (say, the negative latitudes). 
%                         Employing the symmetry propery of Legendre functions, the
%                         computation is automatically done also for the
%                         other hemisphere which improves the performance
%                         of the function.
%
%        "output_SHCs_path" -- Absolute or relative path to the directory,
%                              where outputs are saved. If the directory
%                              does not exist, the code will create it.
%                              If it exists and contains files from
%                              previous computations, they will automatically
%                              be overwritten.
%
%        "parallel"    -- 0 - serial (non-parallel) computation
%                      -- 1 - parallel computation via "spmd"
%
%        "nworkers"    -- For parallel computations (if "parallel==1", see
%                         above), this variable represents the number of
%                         workers of the current parpool session.
%
%                         For serial computations (if "parallel==0", see
%                         above), this variable is automatically set to "1".
%                         Other positive integer values could be used to
%                         control the total number of latitudes in one
%                         latitudinal band, but for serial computations,
%                         this can be done via the variable "nlats_max".
%
%OUTPUTS: In case of ultra-high-degree analysis, the total number of coefficients
%         may easily achieve such a value that all coeffcients are impossible
%         (or at least impractical) to store at RAM simultaneously. Therefore,
%         the outputs of this function are many mat-files saved in the specified
%         "output_SHCs_path" directory. The names of the mat-files are "Cnm_Snm_mX.mat", 
%         where "X" stands for the spherical harmonic order. In the files, the
%         coefficients are stored in the vectors "Cnm" and "Snm", the dimensions of
%         which are (nmax_SHA+1-X,1). Within the vectors, all computed harmonic
%         degrees are listed, starting from degree "X" up to degree "nmax_SHA".
%         For instance, the file "Cnm_Snm_m10.mat" contains two vectors,
%         "Cnm" and "Snm". The elements of these vectors then represent spherical
%         harmonic coefficients as follows:
%
%         Cnm=[C(10,10)
%              C(11,10)
%              C(12,10)
%                 .
%                 .
%                 .
%              C(nmax_SHA,10)];
%
%        Snm=[S(10,10)
%             S(11,10)
%             S(12,10)
%                .
%                .
%                .
%             S(nmax_SHA,10)];
%
%REFERENCES: Sneeuw, N. (1994) Global spherical harmonic analysis by
%               least-squares and numerical quadrature methods in historical perspective.
%               Geophysical Journal International 118:707--716
%
%            Heiskannen, W. A., Moritz, H. (1967) Physical Geodesy. W. H.
%               Freeman and Company, San Francisco, 364 pp
%
%            Freeden, W., Schneider, F. (1998) Wavelet approximations on
%               closed surfaces and their application to boundary-value
%               problems of potential theory. Mathematical Methods in the 
%               Applied Sciences 21:129--163.
%
%            Bucha, B., Hirt, C., Kuhn, M. (2019) Cap integration in
%               spectral gravity forward modelling: near- and far-zone gravity
%               effects via Molodensky's truncation coefficients. Journal
%               of Geodesy
%
%            Fukushima, T. (2012) Numerical computation of spherical
%               harmonics of arbitrary degree and order by extending exponent
%               of floating point numbers. Journal of Geodesy 86:271--285.
%
%Contact: blazej.bucha@stuba.sk
%
%
%Please use the following reference when using this function:
%
%         Bucha, B., Hirt, C., Kuhn, M., 2019. Cap integration in
%            spectral gravity forward modelling up to the full gravity
%            tensor. Journal of Geodesy 93:1707--1737
%
%==========================================================================

if parallel==0
    if nworkers>1
        warning('For serial computation (if "parallel==0"), the variable "nworkers" is automatically set to zero. Setting the variable "nworkers" to 1 and continuing in the computation...')
        nworkers=1;
    end
elseif parallel==1
    if isempty(gcp('nocreate'))
        error('A parpool session must be running with the poolsize being equal to "nworkers".')
    end
end

%Create the "output_SHCs_path" directory if it does not exist
%--------------------------------------------------------------------------
if ~exist(output_SHCs_path,'dir')
    mkdir(output_SHCs_path);
end
%--------------------------------------------------------------------------


%Computation of the Gauss--Legendre grid nodes
%--------------------------------------------------------------------------
[lat,lon,w]=GL_grid(nmax_signal); %Gauss--Legendre grid nodes and the associated
                                  %weights
length_lat=length(lat); %The total number of latitudes in the grid
floor_length_lat2=floor(length_lat/2);
if rem(nmax_signal,2)==0 %If the Gauss--Legendre grid contains the zero latitude
    lat=lat(1:floor_length_lat2+1); %Latitudes from the interval (-90 deg, 0 deg],
                                    %(including the zero latitude)
    even=1;
else
    lat=lat(1:floor_length_lat2); %Latitudes from the interval (-90 deg, 0 deg),
                                  %(the grid does not contain the zero
                                  %latitude)
    even=0;
end
length_lat=length(lat); %The length of the NEW vector "lat" with the 
                        %non-positive latitudes
%--------------------------------------------------------------------------


%Division of the individual latitudes into latitude bands
%--------------------------------------------------------------------------
%Defining the number of latitudes to be processed per worker
%..........................................................................
worker_lats_fixed=ceil(length_lat/(nworkers));
worker_lats=zeros(nworkers,1)+worker_lats_fixed;
if sum(worker_lats)~=length_lat
    lats_diffs=sum(worker_lats)-length_lat;
    worker_lats(1:lats_diffs)=worker_lats(1:lats_diffs)-1;
end
if sum(worker_lats)~=length_lat
    error('The latitudes were not assigned correctly for individual workers.');
end
%..........................................................................

%Assigining particular latitudes to each worker
%..........................................................................
length_nlats=length(worker_lats);
idx_lats=zeros(length_nlats,2);
for i=1:length_nlats
    idx_lats(i,:)=[((sum(worker_lats(1:i))-worker_lats(i))+1) min([sum(worker_lats(1:i)) length_lat])];
end
clear i

for i=1:nworkers
    worker_idx{i}=idx_lats(i,1):nlats_max:idx_lats(i,2); %#ok<AGROW>
    worker_idx{i}=[worker_idx{i}' worker_idx{i}'+nlats_max-1]; %#ok<AGROW>

    worker_idx{i}(worker_idx{i}(:,1)>idx_lats(i,2),:)=[]; %#ok<AGROW>
    worker_idx{i}(worker_idx{i}(:,2)>idx_lats(i,2),2)=idx_lats(i,2); %#ok<AGROW>
    
    if i==1
        [rows1,~]=size(worker_idx{1});
    else
        [rowsi,~]=size(worker_idx{i});
        if rowsi>rows1
            worker_idx{i}(end-1,2)=worker_idx{i}(end,2); %#ok<AGROW>
            worker_idx{i}(end,:)=[]; %#ok<AGROW>
        end
    end
    
    if worker_idx{i}(1,1)~=idx_lats(i,1) || worker_idx{i}(end,end)~=idx_lats(i,2)
        error('The latitudes were not assigned correctly for individual workers.');
    end
    
    length_worker_idx{i}=length(worker_idx{i}(:,1)); %#ok<AGROW>
end
clear i

if worker_idx{end}(end,2)~=length_lat
    error('The latitudes were not assigned correctly for individual workers.');
end

%Check
[rows_worker_idx,~]=size(worker_idx{1});
if length(worker_idx)>1
    for i=2:nworkers
        [rows_worker_idx_temp,~]=size(worker_idx{i});
        if rows_worker_idx_temp~=rows_worker_idx
            error('The latitudes were not assigned correctly for individual workers.');
        end
    end
end
%..........................................................................
%--------------------------------------------------------------------------

ROOT3=1.732050807568877;


if parallel==1 %Parallel computation
    
    spmd
        for o=1:length_worker_idx{labindex} 
        
            
            %Spherical harmonic synthesis of the pth power of the signal
            %--------------------------------------------------------------------------
            lat_temp=lat(worker_idx{labindex}(o,1):worker_idx{labindex}(o,2));
            length_lat_temp=length(lat_temp);
            w_temp=w(worker_idx{labindex}(o,1):worker_idx{labindex}(o,2));
            
            if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                signal=Surface_SHS_sliced([lat_temp;-lat_temp(1:end-1)],lon,nmax_signal/p,signal_path);
                %If you wish to avoid the computation of the input signal via
                %harmonic synthesis but want to, for instance, import your
                %own signal instead, you can comment the line above and import your
                %signal. Note, however, that the imported signal must be given
                %at the same grid points as here via the "Surface_SHS_sliced.m" function.
                ww_temp=[w_temp;w_temp(1:end-1)];
            else
                signal=Surface_SHS_sliced([lat_temp;-lat_temp],lon,nmax_signal/p,signal_path);
                %If you wish to avoid the computation of the input signal via
                %harmonic synthesis but want to, for instance, import your
                %own signal instead, you can comment the line above and import your
                %signal. Note, however, that the imported signal must be given
                %at the same grid points as here via the "Surface_SHS_sliced.m" function.
                ww_temp=[w_temp;w_temp];
            end
            w_temp=[]; %#ok<NASGU>
            signal=(signal./R).^p;
            %--------------------------------------------------------------------------
            
    
            %Lumped coeffcients
            %--------------------------------------------------------------------------
            FFT=fft(signal,[],2);
            signal=[]; %#ok<NASGU>
            A=bsxfun(@times,real(FFT(:,1:(nmax_signal+1))),2*ww_temp*pi/(2*(nmax_signal+1)));
            B=bsxfun(@times,-imag(FFT(:,1:(nmax_signal+1))),2*ww_temp*pi/(2*(nmax_signal+1)));
            FFT=[]; %#ok<NASGU>
            ww_temp=[]; %#ok<NASGU>
            %--------------------------------------------------------------------------
            
            
            %Initialization for the computation of Legendre functions
            %--------------------------------------------------------------------------
            nmax23=nmax_SHA*2+3;
            rr=zeros(nmax23,1); ri=rr;
            dd=zeros(nmax_SHA,1); am=dd; bm=am;
    
            m1=1:nmax23;
            rr(m1)=sqrt(m1);
            ri(m1)=1./rr;
            m2=1:nmax_SHA;
            dd(m2)=rr(2*m2+3).*ri(2*m2+2);
    
            IND=960;
            BIG=2^IND;
            BIGI=2^(-IND);
            BIGS=2^(IND/2);
            BIGSI=2^(-IND/2);
    
            u(1:length_lat_temp)=cos(lat_temp);
            t(1:length_lat_temp)=sin(lat_temp);
            temp1=zeros(1,length_lat_temp);
            temp2=ones(1,length_lat_temp);
            temp3=temp2;
            temp4=temp1;
            temp5=temp1+BIGI;
            ps1b=zeros(nmax_SHA,length_lat_temp); 
            ips1b=ps1b;
            xb=ROOT3*u;
            ixb=zeros(size(xb));
            ps1b(1,:)=xb;
            ips1b(1,:)=ixb;
            for m3=2:nmax_SHA
                xb=(dd(m3-1)*u).*xb;
                yb=abs(xb);
                iyb=yb>=BIGS;
                if any(iyb)
                    xb(iyb)=xb(iyb)*BIGI;
                    ixb(iyb)=ixb(iyb)+1;
                end
                iyb=yb<BIGSI;
                if any(iyb)
                    xb(iyb)=xb(iyb)*BIG;
                    ixb(iyb)=ixb(iyb)-1;
                end
                ps1b(m3,:)=xb;
                ips1b(m3,:)=ixb;
            end
            %--------------------------------------------------------------------------
    
    
            %Spherical harmonic analysis
            %--------------------------------------------------------------------------
            for m=0:nmax_SHA
                
                Cnm=zeros(nmax_SHA+1-m,1);
                Snm=Cnm;
    
                am(m+1)=rr(2*m+3);
                for n=m+2:nmax_SHA
                    ww=rr(2*n+1)*ri(n-m)*ri(n+m);
                    am(n)=rr(2*n-1)*ww;
                    bm(n)=rr(n-m-1)*rr(n+m-1)*ri(2*n-3)*ww;
                end
    
                if m==0 %Zonal spherical harmonic coefficients
    
                    Pnm0=ones(1,length_lat_temp);
                    Cnm_temp=Pnm0*A(1:length_lat_temp,m+1);
                    
                    if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                        Pnm02=Pnm0(1,1:(end-1));
                    else
                        Pnm02=Pnm0;
                    end
                    Cnm_temp=Cnm_temp+Pnm02*A(length_lat_temp+1:end,m+1);
                    Cnm(1,1)=Cnm(1,1)+Cnm_temp;
                    
                    if nmax_SHA>0
                        Pnm1=ROOT3*t;
                        Cnm_temp=Pnm1*A(1:length_lat_temp,m+1);
                    
                        if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                            Pnm12=-Pnm1(1,1:(end-1));
                        else
                            Pnm12=-Pnm1;
                        end
                        Cnm_temp=Cnm_temp+Pnm12*A(length_lat_temp+1:end,m+1);
                        Cnm(2,1)=Cnm(2,1)+Cnm_temp;
                    end
    
                    
                    if nmax_SHA>1              
                        for i=2:nmax_SHA
                            
                            if rem(i,2)==0
                                sign=1;
                            elseif rem(i,2)==1
                                sign=-1;
                            end
                            
                            Pnm2=Pnm1.*sqrt((2*i+1)*(2*i-1))./i.*t-Pnm0.*(i-1).*sqrt(2.*i+1)./(i.*sqrt(2.*i-3));
                            Cnm_temp=Pnm2*A(1:length_lat_temp,m+1);
                        
                            if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                                Pnm22=sign*Pnm2(1,1:(end-1));
                            else
                                Pnm22=sign*Pnm2;
                            end
                            Cnm_temp=Cnm_temp+Pnm22*A(length_lat_temp+1:end,m+1);
                            Cnm(i+1,1)=Cnm(i+1,1)+Cnm_temp;
                            
                            Pnm0=Pnm1;
                            Pnm1=Pnm2;
                        end
                    end
                    
                elseif m~=0 %Non-zonal spherical harmonic coefficients
                    xb=ps1b(m,:);
                    ixb=ips1b(m,:);
    
                    temp5(ixb==0)=1;
                    temp5(ixb<-1)=0;
                    %temp5(izb>=-1 & izb<0)=BIGI;
                    %The condition "izb>=-1 & izb<0"
                    %is useless, as "izb" is already
                    %initialized as "izb=BIGI".
                    temp5(ixb>0)=BIG;
                    
                    Pnm0=xb.*temp5;
                    Cnm_temp=Pnm0*A(1:length_lat_temp,m+1);
                    Snm_temp=Pnm0*B(1:length_lat_temp,m+1);
                    if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                        Pnm02=Pnm0(1,1:(end-1));
                    else
                        Pnm02=Pnm0;
                    end
                    Cnm_temp=Cnm_temp+Pnm02*A(length_lat_temp+1:end,m+1);
                    Snm_temp=Snm_temp+Pnm02*B(length_lat_temp+1:end,m+1);
                    temp5=temp5.*0+BIGI;                 
                    Cnm(1,1)=Cnm(1,1)+Cnm_temp; %Sectorial spherical harmonic coefficients C
                    Snm(1,1)=Snm(1,1)+Snm_temp; %Sectorial spherical harmonic coefficients S
                    
                    if m<nmax_SHA         
                        yb=xb;
                        iyb=ixb;
    
                        xb=(am(m+1).*t).*yb;
                        ixb=iyb;
                        wb=abs(xb);
    
                        wBIGSb=wb>=BIGS;
                        wBIGSIb=wb<BIGSI;
                        temp3(wBIGSb)=BIGI;
                        temp3(wBIGSIb)=BIG;
                        temp4(wBIGSb)=1;
                        temp4(wBIGSIb)=-1;
    
                        xb=xb.*temp3;
                        ixb=ixb+temp4;
                        temp3=temp2;
                        temp4=temp4.*0;
    
                        temp5(ixb==0)=1;
                        temp5(ixb<-1)=0;
                        %temp5(izb>=-1 & izb<0)=BIGI;
                        %The condition "izb>=-1 & izb<0"
                        %is useless, as "izb" is already
                        %initialized as "izb=BIGI".
                        temp5(ixb>0)=BIG;
    
                        Pnm1=xb.*temp5;
                        Cnm_temp=Pnm1*A(1:length_lat_temp,m+1);
                        Snm_temp=Pnm1*B(1:length_lat_temp,m+1);
                        if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                            Pnm12=-Pnm1(1,1:(end-1));
                        else
                            Pnm12=-Pnm1;
                        end
                        Cnm_temp=Cnm_temp+Pnm12*A(length_lat_temp+1:end,m+1);
                        Snm_temp=Snm_temp+Pnm12*B(length_lat_temp+1:end,m+1);
                        temp5=temp5.*0+BIGI; 
                        Cnm(2,1)=Cnm(2,1)+Cnm_temp; %Tesseral spherical harmonic coefficients
                        Snm(2,1)=Snm(2,1)+Snm_temp; %Tesseral spherical harmonic coefficients
                        
                        i=2;
                        if m<nmax_SHA-1
                            for n=m+2:nmax_SHA
                                idb=ixb-iyb;
    
                                id0b=idb==0;
                                id1b=idb==1;
                                id_1b=idb==-1;
                                idv1b=idb>1;
    
                                temp1(id0b)=1;
                                temp1(id1b)=1;
                                temp2(id1b)=BIGI;
                                temp1(id_1b)=BIGI;
                                temp1(idv1b)=1;
                                temp2(idv1b)=0;
    
                                zzb=(am(n).*t).*(xb.*temp1)-bm(n).*(yb.*temp2);
                                izb=iyb;
                                id0b_id1b_idv1b=id0b | id1b | idv1b;
                                izb(id0b_id1b_idv1b)=ixb(id0b_id1b_idv1b);
                                temp1=temp1.*0;
                                temp2=temp1+1;
    
                                wb=abs(zzb);
    
                                wBIGSb=wb>=BIGS;
                                wBIGSIb=wb<BIGSI;
                                temp3(wBIGSb)=BIGI;
                                temp3(wBIGSIb)=BIG;
                                temp4(wBIGSb)=1;
                                temp4(wBIGSIb)=-1;
    
                                zzb=zzb.*temp3;
                                izb=izb+temp4;
                                temp3=temp2;
                                temp4=temp4.*0;
    
                                temp5(izb==0)=1;
                                temp5(izb<-1)=0;
                                %temp5(izb>=-1 & izb<0)=BIGI;
                                %The condition "izb>=-1 & izb<0"
                                %is useless, as "izb" is already
                                %initialized as "izb=BIGI".
                                temp5(izb>0)=BIG;
    
                                Pnm=zzb.*temp5;
                                Cnm_temp=Pnm*A(1:length_lat_temp,m+1);
                                Snm_temp=Pnm*B(1:length_lat_temp,m+1);
                                if rem(n+m,2)==0
                                    sign=1;
                                elseif rem(n+m,2)==1
                                    sign=-1;
                                end
    
                                if labindex==nworkers && o==length_worker_idx{nworkers} && even==1
                                    Pnm2=sign*Pnm(1,1:(end-1));
                                else
                                    Pnm2=sign*Pnm;
                                end
                                Cnm_temp=Cnm_temp+Pnm2*A(length_lat_temp+1:end,m+1);
                                Snm_temp=Snm_temp+Pnm2*B(length_lat_temp+1:end,m+1);
                                Cnm(i+1,1)=Cnm(i+1,1)+Cnm_temp; %Tesseral spherical harmonic coefficients
                                Snm(i+1,1)=Snm(i+1,1)+Snm_temp; %Tesseral spherical harmonic coefficients
                                
                                temp5=temp1+BIGI;   
    
                                yb=xb;
                                iyb=ixb;
                                xb=zzb;
                                ixb=izb;
                                
                                i=i+1;
                            end
                        end
                    end
                end

                Cnm=gop(@plus,Cnm);
                Snm=gop(@plus,Snm);
    
                if labindex==1
                    
                    Cnm=Cnm./(4*pi);
                    Snm=Snm./(4*pi);
                    
                    if o>1
                        [Cnm_temp,Snm_temp]=Surface_SHA_sliced_load(m,output_SHCs_path);
                        Cnm=Cnm+Cnm_temp;
                        Snm=Snm+Snm_temp;
                        Cnm_temp=[]; %#ok<NASGU>
                        Snm_temp=[]; %#ok<NASGU>
                    end
                    Surface_SHA_sliced_save(Cnm,Snm,m,output_SHCs_path)
                end
            end
            %--------------------------------------------------------------------------
            
            u=[];
            t=[];        
        end
    
    end
    
    clear T1 T2 A B Pnm Pnm0 Pnm1 Pnm2 am bm dd fi id0b id0b_id1b_idv1b id1b idb idv1b id_1b id_1b...
        idb1b ips1b ixb iyb izb m1 m2 ps1b ri rr t temp1 temp2 temp3 temp4 temp5...
        u wBIGSIb wBIGSb wb xb yb zzb w
elseif parallel==0 %Serial computation
    
    for j=1:nworkers
        for o=1:length_worker_idx{j}
        
            
            %Spherical harmonic synthesis of the pth power of the signal
            %--------------------------------------------------------------------------
            lat_temp=lat(worker_idx{j}(o,1):worker_idx{j}(o,2));
            length_lat_temp=length(lat_temp);
            w_temp=w(worker_idx{j}(o,1):worker_idx{j}(o,2));
            
            if j==nworkers && o==length_worker_idx{nworkers} && even==1
                signal=Surface_SHS_sliced([lat_temp;-lat_temp(1:end-1)],lon,nmax_signal/p,signal_path);
                %If you wish to avoid the computation of the input signal via
                %harmonic synthesis but want to, for instance, import your
                %own signal instead, you can comment the line above and import your
                %signal. Note however, that it must be provided at the same
                %grid points as here via the "Surface_SHS_sliced.m" function.
                ww_temp=[w_temp;w_temp(1:end-1)];
            else
                signal=Surface_SHS_sliced([lat_temp;-lat_temp],lon,nmax_signal/p,signal_path);
                %If you wish to avoid the computation of the input signal via
                %harmonic synthesis but want to, for instance, import your
                %own signal instead, you can comment the line above and import your
                %signal. Note however, that it must be provided at the same
                %grid points as here via the "Surface_SHS_sliced.m" function.
                ww_temp=[w_temp;w_temp];
            end
            w_temp=[]; %#ok<NASGU>
            signal=(signal./R).^p;
            %--------------------------------------------------------------------------
            
    
            %Lumped coeffcients
            %--------------------------------------------------------------------------
            FFT=fft(signal,[],2);
            signal=[]; %#ok<NASGU>
            A=bsxfun(@times,real(FFT(:,1:(nmax_signal+1))),2*ww_temp*pi/(2*(nmax_signal+1)));
            B=bsxfun(@times,-imag(FFT(:,1:(nmax_signal+1))),2*ww_temp*pi/(2*(nmax_signal+1)));
            FFT=[]; %#ok<NASGU>
            ww_temp=[]; %#ok<NASGU>
            %--------------------------------------------------------------------------
            
            
            %Initialization for the computation of Legendre functions
            %--------------------------------------------------------------------------
            nmax23=nmax_SHA*2+3;
            rr=zeros(nmax23,1); ri=rr;
            dd=zeros(nmax_SHA,1); am=dd; bm=am;
    
            m1=1:nmax23;
            rr(m1)=sqrt(m1);
            ri(m1)=1./rr;
            m2=1:nmax_SHA;
            dd(m2)=rr(2*m2+3).*ri(2*m2+2);
    
            IND=960;
            BIG=2^IND;
            BIGI=2^(-IND);
            BIGS=2^(IND/2);
            BIGSI=2^(-IND/2);
    
            u(1:length_lat_temp)=cos(lat_temp);
            t(1:length_lat_temp)=sin(lat_temp);
            temp1=zeros(1,length_lat_temp);
            temp2=ones(1,length_lat_temp);
            temp3=temp2;
            temp4=temp1;
            temp5=temp1+BIGI;
            ps1b=zeros(nmax_SHA,length_lat_temp); 
            ips1b=ps1b;
            xb=ROOT3*u;
            ixb=zeros(size(xb));
            ps1b(1,:)=xb;
            ips1b(1,:)=ixb;
            for m3=2:nmax_SHA
                xb=(dd(m3-1)*u).*xb;
                yb=abs(xb);
                iyb=yb>=BIGS;
                if any(iyb)
                    xb(iyb)=xb(iyb)*BIGI;
                    ixb(iyb)=ixb(iyb)+1;
                end
                iyb=yb<BIGSI;
                if any(iyb)
                    xb(iyb)=xb(iyb)*BIG;
                    ixb(iyb)=ixb(iyb)-1;
                end
                ps1b(m3,:)=xb;
                ips1b(m3,:)=ixb;
            end
            %--------------------------------------------------------------------------
    
    
            %Spherical harmonic analysis
            %--------------------------------------------------------------------------
            for m=0:nmax_SHA
                
                Cnm=zeros(nmax_SHA+1-m,1);
                Snm=Cnm;
    
                am(m+1)=rr(2*m+3);
                for n=m+2:nmax_SHA
                    ww=rr(2*n+1)*ri(n-m)*ri(n+m);
                    am(n)=rr(2*n-1)*ww;
                    bm(n)=rr(n-m-1)*rr(n+m-1)*ri(2*n-3)*ww;
                end
    
                if m==0 %Zonal spherical harmonic coefficients
    
                    Pnm0=ones(1,length_lat_temp);
                    Cnm_temp=Pnm0*A(1:length_lat_temp,m+1);
                    
                    if j==nworkers && o==length_worker_idx{nworkers} && even==1
                    Pnm02=Pnm0(1,1:(end-1));
                    else
                        Pnm02=Pnm0;
                    end
                    Cnm_temp=Cnm_temp+Pnm02*A(length_lat_temp+1:end,m+1);
                    Cnm(1,1)=Cnm(1,1)+Cnm_temp;
                    
                    if nmax_SHA>0
                        Pnm1=ROOT3*t;
                        Cnm_temp=Pnm1*A(1:length_lat_temp,m+1);
                    
                    if j==nworkers && o==length_worker_idx{nworkers} && even==1
                        Pnm12=-Pnm1(1,1:(end-1));
                    else
                            Pnm12=-Pnm1;
                    end
                        Cnm_temp=Cnm_temp+Pnm12*A(length_lat_temp+1:end,m+1);
                        Cnm(2,1)=Cnm(2,1)+Cnm_temp;
                    end
    
                    
                    if nmax_SHA>1              
                        for i=2:nmax_SHA
                            
                            if rem(i,2)==0
                                sign=1;
                            elseif rem(i,2)==1
                                sign=-1;
                            end
                            
                            Pnm2=Pnm1.*sqrt((2*i+1)*(2*i-1))./i.*t-Pnm0.*(i-1).*sqrt(2.*i+1)./(i.*sqrt(2.*i-3));
                            Cnm_temp=Pnm2*A(1:length_lat_temp,m+1);
                        
                        if j==nworkers && o==length_worker_idx{nworkers} && even==1
                            Pnm22=sign*Pnm2(1,1:(end-1));
                        else
                                Pnm22=sign*Pnm2;
                        end
                            Cnm_temp=Cnm_temp+Pnm22*A(length_lat_temp+1:end,m+1);
                            Cnm(i+1,1)=Cnm(i+1,1)+Cnm_temp;
                            
                            Pnm0=Pnm1;
                            Pnm1=Pnm2;
                        end
                    end
                    
                elseif m~=0 %Non-zonal spherical harmonic coefficients
                    xb=ps1b(m,:);
                    ixb=ips1b(m,:);
    
                    temp5(ixb==0)=1;
                    temp5(ixb<-1)=0;
                    %temp5(izb>=-1 & izb<0)=BIGI;
                    %The condition "izb>=-1 & izb<0"
                    %is useless, as "izb" is already
                    %initialized as "izb=BIGI".
                    temp5(ixb>0)=BIG;
                    
                    Pnm0=xb.*temp5;
                    Cnm_temp=Pnm0*A(1:length_lat_temp,m+1);
                    Snm_temp=Pnm0*B(1:length_lat_temp,m+1);
                    if j==nworkers && o==length_worker_idx{nworkers} && even==1
                        Pnm02=Pnm0(1,1:(end-1));
                    else
                        Pnm02=Pnm0;
                    end
                    Cnm_temp=Cnm_temp+Pnm02*A(length_lat_temp+1:end,m+1);
                    Snm_temp=Snm_temp+Pnm02*B(length_lat_temp+1:end,m+1);
                    temp5=temp5.*0+BIGI;                 
                    Cnm(1,1)=Cnm(1,1)+Cnm_temp; %Sectorial spherical harmonic coefficients C
                    Snm(1,1)=Snm(1,1)+Snm_temp; %Sectorial spherical harmonic coefficients S
                    
                    if m<nmax_SHA         
                        yb=xb;
                        iyb=ixb;
    
                        xb=(am(m+1).*t).*yb;
                        ixb=iyb;
                        wb=abs(xb);
    
                        wBIGSb=wb>=BIGS;
                        wBIGSIb=wb<BIGSI;
                        temp3(wBIGSb)=BIGI;
                        temp3(wBIGSIb)=BIG;
                        temp4(wBIGSb)=1;
                        temp4(wBIGSIb)=-1;
    
                        xb=xb.*temp3;
                        ixb=ixb+temp4;
                        temp3=temp2;
                        temp4=temp4.*0;
    
                        temp5(ixb==0)=1;
                        temp5(ixb<-1)=0;
                        %temp5(izb>=-1 & izb<0)=BIGI;
                        %The condition "izb>=-1 & izb<0"
                        %is useless, as "izb" is already
                        %initialized as "izb=BIGI".
                        temp5(ixb>0)=BIG;
    
                        Pnm1=xb.*temp5;
                        Cnm_temp=Pnm1*A(1:length_lat_temp,m+1);
                        Snm_temp=Pnm1*B(1:length_lat_temp,m+1);
                        if j==nworkers && o==length_worker_idx{nworkers} && even==1
                            Pnm12=-Pnm1(1,1:(end-1));
                        else
                            Pnm12=-Pnm1;
                        end
                        Cnm_temp=Cnm_temp+Pnm12*A(length_lat_temp+1:end,m+1);
                        Snm_temp=Snm_temp+Pnm12*B(length_lat_temp+1:end,m+1);
                        temp5=temp5.*0+BIGI; 
                        Cnm(2,1)=Cnm(2,1)+Cnm_temp; %Tesseral spherical harmonic coefficients
                        Snm(2,1)=Snm(2,1)+Snm_temp; %Tesseral spherical harmonic coefficients
                        
                        i=2;
                        if m<nmax_SHA-1
                            for n=m+2:nmax_SHA
                                idb=ixb-iyb;
    
                                id0b=idb==0;
                                id1b=idb==1;
                                id_1b=idb==-1;
                                idv1b=idb>1;
    
                                temp1(id0b)=1;
                                temp1(id1b)=1;
                                temp2(id1b)=BIGI;
                                temp1(id_1b)=BIGI;
                                temp1(idv1b)=1;
                                temp2(idv1b)=0;
    
                                zzb=(am(n).*t).*(xb.*temp1)-bm(n).*(yb.*temp2);
                                izb=iyb;
                                id0b_id1b_idv1b=id0b | id1b | idv1b;
                                izb(id0b_id1b_idv1b)=ixb(id0b_id1b_idv1b);
                                temp1=temp1.*0;
                                temp2=temp1+1;
    
                                wb=abs(zzb);
    
                                wBIGSb=wb>=BIGS;
                                wBIGSIb=wb<BIGSI;
                                temp3(wBIGSb)=BIGI;
                                temp3(wBIGSIb)=BIG;
                                temp4(wBIGSb)=1;
                                temp4(wBIGSIb)=-1;
    
                                zzb=zzb.*temp3;
                                izb=izb+temp4;
                                temp3=temp2;
                                temp4=temp4.*0;
    
                                temp5(izb==0)=1;
                                temp5(izb<-1)=0;
                                %temp5(izb>=-1 & izb<0)=BIGI;
                                %The condition "izb>=-1 & izb<0"
                                %is useless, as "izb" is already
                                %initialized as "izb=BIGI".
                                temp5(izb>0)=BIG;
    
                                Pnm=zzb.*temp5;
                                Cnm_temp=Pnm*A(1:length_lat_temp,m+1);
                                Snm_temp=Pnm*B(1:length_lat_temp,m+1);
                                if rem(n+m,2)==0
                                    sign=1;
                                elseif rem(n+m,2)==1
                                    sign=-1;
                                end
    
                                if j==nworkers && o==length_worker_idx{nworkers} && even==1
                                    Pnm2=sign*Pnm(1,1:(end-1));
                                else
                                    Pnm2=sign*Pnm;
                                end
                                Cnm_temp=Cnm_temp+Pnm2*A(length_lat_temp+1:end,m+1);
                                Snm_temp=Snm_temp+Pnm2*B(length_lat_temp+1:end,m+1);
                                Cnm(i+1,1)=Cnm(i+1,1)+Cnm_temp; %Tesseral spherical harmonic coefficients
                                Snm(i+1,1)=Snm(i+1,1)+Snm_temp; %Tesseral spherical harmonic coefficients
                                
                                temp5=temp1+BIGI;   
    
                                yb=xb;
                                iyb=ixb;
                                xb=zzb;
                                ixb=izb;
                                
                                i=i+1;
                            end
                        end
                    end
                end
    

                Cnm=Cnm./(4*pi);
                Snm=Snm./(4*pi);
                    
                if j>1 || o>1
                    [Cnm_temp,Snm_temp]=Surface_SHA_sliced_load(m,output_SHCs_path);
                    Cnm=Cnm+Cnm_temp;
                    Snm=Snm+Snm_temp;
                    Cnm_temp=[]; %#ok<NASGU>
                    Snm_temp=[]; %#ok<NASGU>
                end
                Surface_SHA_sliced_save(Cnm,Snm,m,output_SHCs_path)
            end
            %--------------------------------------------------------------------------
            
            u=[];
            t=[];        
        end
    
    end
    
    clear T1 T2 A B Pnm Pnm0 Pnm1 Pnm2 am bm dd fi id0b id0b_id1b_idv1b id1b idb idv1b id_1b id_1b...
        idb1b ips1b ixb iyb izb m1 m2 ps1b ri rr t temp1 temp2 temp3 temp4 temp5...
        u wBIGSIb wBIGSb wb xb yb zzb w
    
end
